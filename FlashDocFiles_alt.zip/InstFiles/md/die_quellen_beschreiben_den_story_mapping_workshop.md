Die Quellen beschreiben den Story Mapping Workshop als den zentralen, kollaborativen Prozess zur Erstellung einer User Story Map (USM)1. Der wahre Wert der Methode liegt nicht im fertigen Artefakt, sondern in der "kuratierten Konversation" und dem daraus resultierenden "Shared Understanding" (gemeinsamen Verständnis) im Team1....
Die Durchführung eines Story Mapping Workshops folgt einem strukturierten Vorgehen, das grob in Vorbereitung, vier Hauptschritte zur Kartenerstellung und den abschließenden Slicing-Prozess unterteilt ist1....

--------------------------------------------------------------------------------
A. Phase 1: Vorbereitung (Das Fundament legen)
Eine sorgfältige Vorbereitung (manchmal als Schritt 0 oder Frame nach Patton bezeichnet1...) ist entscheidend für den Erfolg des Workshops1:
1. Framing und Ziele definieren: Das Team muss ein gemeinsames Verständnis für das Ziel des Produkts oder Features entwickeln1. Die Kernfragen, die beantwortet werden müssen, lauten: "Welches Problem lösen wir?", "Für wen?" und "Welchen Nutzen stiftet das Produkt?"18.
2. Persona-Definition: Die Map wird aus der Perspektive des Benutzers erstellt910. Daher ist die Definition der Ziel-Personas unerlässlich9.... Als Best Practice gilt, den ersten Workshop auf eine primäre Persona zu fokussieren, um die Komplexität zu reduzieren9.
3. Teilnehmer (Das "Who"): Die Teamzusammenstellung ist ein kritischer Erfolgsfaktor und muss funktionsübergreifend besetzt sein9....
    ◦ Die ideale Größe liegt bei etwa 7–10 Personen (oder 5–8)9....
    ◦ Moderator (Facilitator): Leitet den Prozess (oft PO oder Scrum Master)917.
    ◦ Stakeholder/Business Owner: Liefern Antworten auf "Warum"-Fragen und verstehen die Geschäftsziele1718.
    ◦ Entwicklungsteam: Muss anwesend sein, um die technische Machbarkeit zu beurteilen, die richtigen Fragen zu stellen und technische Stories hinzuzufügen17.... Ohne ihre Teilnahme riskiert die Map, eine unrealistische "Wunschliste" oder "Fantasy Map" zu werden1920.
4. Logistik/Format: Es muss entschieden werden, ob der Workshop physisch (Whiteboard, Haftnotizen – fördert Kollaboration und Dynamik) oder digital (Miro, Mural, dedizierte Tools – notwendig für Remote-Teams und Persistenz) stattfindet5....
B. Phase 2: Die Story Map erstellen (Die vier Schritte)
Die eigentliche Erstellung der Map erfolgt in vier iterativen Schritten1...:
Schritt 1: Der "Elevator Pitch" und das Backbone (Die horizontale Achse)
Der Workshop beginnt mit dem vorbereiteten "Elevator Pitch" der Produktvision17. Anschließend wird das Backbone erstellt17:
• Brainstorming: Die Teilnehmer brainstormen zunächst schweigend alle Hauptaktivitäten (User Activities), die die Persona zur Erreichung ihres übergeordneten Ziels durchführen muss2430.
• Anordnung: Diese Aktivitäten werden gesammelt und kollaborativ in die richtige chronologische Reihenfolge von links nach rechts gebracht2430. Diese Kette von Aktivitäten bildet das initiale Backbone (Rückgrat) und stellt die vereinfachte, aber vollständige Darstellung der User Journey dar30.
• Patton bezeichnet diesen Schritt als Map the Big Picture, wobei man "mile-wide, inch-deep" arbeiten soll4....
Schritt 2: Detaillierung der Stories (Die vertikale Achse)
Sobald das Backbone steht, folgt der sogenannte "Brain Dump"24:
• Sammeln: Für jede Aktivität im Backbone (jede Spalte) sammelt das Team nun alle detaillierten Teilschritte, Aufgaben und User Stories2425.
• Vollständigkeit: Diese Stories werden unter die jeweilige Backbone-Aktivität gehängt, wobei in dieser Phase Vollständigkeit wichtiger ist als Priorisierung1725. Das Team soll Ideen und Alternativen ohne Einschränkung notieren17.
• Die vertikale Anordnung repräsentiert Alternativen, die man liest, indem man mental das Wort "oder" zwischen die Karten einfügt31.
Schritt 3: Strukturierung und Priorisierung
Die Story Map wird nun vertikal strukturiert25:
• Priorisierung: Die gesammelten User Stories werden innerhalb ihrer jeweiligen vertikalen Spalte (unterhalb des Backbone-Schritts) priorisiert25.
• "Must-haves" nach oben: Die wichtigsten Stories, die für eine minimale Funktionsfähigkeit unverzichtbar sind ("Must-haves"), werden nach oben verschoben, direkt unter das Backbone25....
• Niedrigere Priorität: Weniger wichtige Stories ("Nice-to-haves") oder alternative Implementierungen wandern nach unten2532.
Schritt 4: Lücken und Abhängigkeiten identifizieren
Dieser Schritt gilt als der kritischste Schritt des Workshops, da hier der eigentliche Wert des Story Mappings entsteht2:
• Storytelling: Das Team "wandert" die Map als Gruppe narrativ ab (vom ersten Schritt links bis zum letzten rechts)2....
• Wissenskollektivierung: Durch das Erzählen der Geschichte entlang der Map deckt das Team unweigerlich Lücken (gaps), Engpässe, fehlende Informationen und Abhängigkeiten zwischen den Spalten auf238.
• Technische Einbindung: Die aktive Rolle des Entwicklungsteams wird hier offensichtlich, da sie technische Abhängigkeiten und "unsichtbare" technische Stories (z.B. "Datenbank-Schema anlegen") an den richtigen Stellen in die Map einfügen müssen19.
C. Phase 3: Abschluss und Release-Planung (Slicing)
Der letzte formale Schritt des Workshops wandelt die priorisierte Map in einen konkreten Umsetzungsplan um1939:
• Slicing: Nachdem die Map vertikal priorisiert wurde, wird sie horizontal "geschnitten" (Slicing oder Cut-Lines)27.... Der Moderator zieht horizontale Linien über die gesamte Breite der Map4041.
• Releases definieren: Jede dieser horizontalen "Scheiben" repräsentiert ein geplantes Release, MVP, Sprint oder eine Iteration4042.
• MVP als "Walking Skeleton": Die oberste Scheibe definiert das Minimum Viable Product (MVP)4043. Das MVP ist nicht nur eine Liste wichtiger Features, sondern der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt43....
• Um dies zu gewährleisten, muss der MVP-Slice mindestens eine Story aus jedem kritischen Backbone-Schritt enthalten4344.
• Der Workshop gilt erst dann als beendet, wenn der erste Slice (das MVP) klar definiert, visualisiert und vom Team committet ist3946.
D. Best Practices und Vermeidung von Fallstricken
Die Quellen betonen, dass der Erfolg des Workshops von der Einhaltung bestimmter Regeln abhängt3...:
• Fokus auf Konversation: Das kollaborative Erstellen (die Konversation) ist wichtiger als das Artefakt selbst2....
• Lebendige Map: Ein häufiger Fehler ist die "Wegwerf-Map"46. Die Map sollte nicht nach dem Workshop vergessen, sondern als "lebendiges Dokument" (living, breathing thing) in das kontinuierliche Backlog Grooming integriert werden5051.
• Disziplin beim Backbone: Das Backbone muss strikt chronologisch sein und darf keine vermischten Abstraktionsebenen enthalten48. Es soll nur aus Benutzer-Aktivitäten bestehen14....

--------------------------------------------------------------------------------
Analogie: Man könnte sich den Story Mapping Workshop als das gemeinsame Planen einer großen, funktionsübergreifenden Wandertour vorstellen.
• Die Vorbereitung ist die Entscheidung, wer mit wem wohin (Persona und Ziel) wandert.
• Schritt 1 (Backbone) ist das Festlegen der Hauptetappen in chronologischer Reihenfolge (z.B. "Startpunkt erreichen" → "Gipfel erklimmen" → "Abstieg"). Dies ist der "große Plan".
• Schritt 2 (Detaillierung) ist das Brainstorming aller möglichen Aktivitäten für jede Etappe (z.B. "Rucksack packen", "Wasser nachfüllen", "Alternative Route finden").
• Schritt 3 (Priorisierung) ist die Entscheidung, welche Aktivitäten für den Kern-Erfolg (das Erreichen des Gipfels) am wichtigsten sind (z.B. "Schuhe binden" vs. "Gipfelfoto machen").
• Schritt 4 (Lücken/Abhängigkeiten) ist die gemeinsame mentale Durchwanderung der Route, um zu prüfen, ob alle technischen Voraussetzungen (z.B. "Haben wir genug Wasser?") bedacht wurden.
• Slicing ist das Ziehen horizontaler Linien für die Reiseetappen (Releases), wobei der erste Schnitt (MVP) sicherstellt, dass die Gruppe zumindest einen vollständigen, minimalen Weg (den "Walking Skeleton") bis zum ersten Lager erreicht.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Story Mapping Workshop (Vorgehen)“ über „Vorbereitung (Framing)“ aussagen.

Die Vorbereitung, oft als "Schritt 0" oder "Framing" bezeichnet, wird in den Quellen als ein entscheidendes Fundament für den Erfolg des gesamten Story Mapping Workshops angesehen1. Der wahre Wert der Story Map entsteht nicht nur durch das fertige Artefakt, sondern durch den kollaborativen Prozess ihrer Erstellung – die Vorbereitung stellt sicher, dass diese kuratierte Konversation zielgerichtet stattfindet12.
Im Rahmen des Story Mapping Workshop-Vorgehens1 umfasst die Vorbereitungsphase (Framing) drei zentrale Bereiche: die inhaltliche Rahmensetzung, die Personenzentrierung und die logistische Organisation1....

--------------------------------------------------------------------------------
I. Inhaltliches Framing und Zieldefinition
Die wichtigste intellektuelle Aufgabe der Vorbereitung ist die Problemformulierung (Framing)1. Sie zielt darauf ab, dass das Team ein gemeinsames Verständnis für das Ziel des Produkts oder Features entwickelt1. Jeff Patton beschreibt diesen Schritt in seinem fünfstufigen Prozess ebenfalls als "Frame"78.
Die Kernfragen, die in dieser Phase beantwortet werden müssen, sind fundamental für die spätere Priorisierung und Entscheidungsfindung19:
1. Welches Problem lösen wir?19
2. Für wen?19
3. Welchen Nutzen stiftet das Produkt?1....
Das Framing beinhaltet auch die Erstellung eines kurzen Feature-Briefs und die Festlegung des "Big Story"-Rahmens (des großen Ganzen)78. Durch die Definition dieser hohen Aktivitäten wird die Grundlage für das spätere Backbone (Rückgrat) der Map gelegt78.
II. Persona-Definition und Nutzerfokus
Die Story Map ist eine benutzerzentrierte Technik1213, weshalb die Definition der Ziel-Personas ein unerlässlicher Bestandteil der Vorbereitung ist313.
• Perspektive der Erstellung: Die gesamte Map wird aus der Perspektive des Benutzers erstellt113.
• Best Practice: Es wird als etablierte Best Practice empfohlen, den ersten Workshop auf eine primäre Persona zu fokussieren, um die Komplexität zu reduzieren3.
• Platzierung: Fiktive Nutzerprofile (Personas) mit ihren Zielen und Problemen werden über der Map platziert, um die Aktivitäten zuzuordnen14.... Der Prozess muss mit einem tiefen Verständnis des Benutzers und seines Ziels beginnen17.
Ein weiteres Schlüsselelement der inhaltlichen Vorbereitung ist der Elevator Pitch3. Der Product Owner (PO) oder Business Owner bereitet eine kurze, prägnante Präsentation der Produktvision oder des zu planenden Epics vor3. Dieser Pitch wird direkt zu Beginn des Workshops präsentiert und dient als Initialzündung, bevor das Team mit der Erstellung des Backbones beginnt18.
III. Zusammenstellung des Teams ("Das Who")
Die Zusammenstellung der Teilnehmer gilt als der kritischste Erfolgsfaktor für den Workshop3.
• Funktionsübergreifende Besetzung: Der Workshop muss funktionsübergreifend (cross-functional) besetzt sein3.... Eine diverse Gruppe erhöht die Perspektivenvielfalt4....
• Ideale Größe: Die ideale Teamgröße liegt bei etwa 7 bis 10 Personen3, wobei in anderen Quellen auch 5 bis 8 Personen als ideal für eine kleine, diverse Gruppe genannt werden21....
• Wichtige Rollen: Die Anwesenheit spezifischer Rollen ist entscheidend, um eine realistische Planungsgrundlage zu schaffen und eine reine "Wunschliste" zu vermeiden2425:
    ◦ Moderator (Facilitator): Leitet den Prozess und ist oft der Product Owner, Scrum Master oder ein Business Analyst18.
    ◦ Business Owner / Stakeholder: Liefert das Verständnis der Geschäftsziele und kann "Warum"-Fragen beantworten18.
    ◦ Entwicklungsteam (Entwickler, Tester, UX/Design): Diese sind notwendig, um die technische Machbarkeit zu beurteilen und auf Abhängigkeiten sowie Aufwände hinzuweisen18.... Ihre Teilnahme hilft, technische Stories (z. B. "Datenbank-Schema anlegen") von Anfang an in die Map zu integrieren24.
IV. Organisatorische und Logistische Vorbereitung
Die logistische Vorbereitung legt den Rahmen für die Durchführung der eigentlichen, kollaborativen Arbeit fest:
1. Dokumente zusammentragen: Dazu gehören Product Requirements, Personas, technische Dokumente und gegebenenfalls bestehende Backlogs4....
2. Ziele definieren: Es muss festgelegt werden, was die Map abbilden soll, der MVP definiert und der Umfang festgelegt werden4....
3. Formatwahl (Logistik): Es muss entschieden werden, ob der Workshop physisch (mit Whiteboard, Haftnotizen und Markern) oder digital (mithilfe von Tools wie Miro oder Mural) stattfindet4....
4. Session-Briefing: Ziele, Fragen und Hintergrundinformationen sollten als Briefing an alle Teilnehmenden gesendet werden4....
Zusammenfassend lässt sich sagen: Die Vorbereitung dient als "Startrampe" für den Workshop. Sie garantiert, dass das Team nicht nur die richtigen Personen an Bord hat3, sondern auch eine klare, nutzerzentrierte Problemstellung (Framing)113 vorab definiert, um sicherzustellen, dass die Story Map von Beginn an auf die Lieferung des höchsten Kundennutzens ausgerichtet ist28.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Vorbereitung (Framing)“ über „Problemformulierung / Ziele definieren“ aussagen.

Die Quellen betonen, dass die Phase der „Vorbereitung (Framing)“ (manchmal als Schritt 0 bezeichnet1) von entscheidender Bedeutung für den gesamten Story Mapping Workshop ist1. In dieser initialen Phase geht es primär darum, ein klares, gemeinsames Verständnis für den Kontext und die Ziele der geplanten Produktarbeit zu schaffen, bevor mit der eigentlichen Kartierung begonnen wird12.
Die Aussagen der Quellen zur „Problemformulierung / Ziele definieren“ im Kontext der Vorbereitung lassen sich in drei Kernbereiche unterteilen:

--------------------------------------------------------------------------------
1. Das Fundament legen: Gemeinsames Verständnis und Kernfragen
Die sorgfältige Vorbereitung ist entscheidend für den Erfolg des Workshops1. Das wichtigste Ziel des Story Mapping Prozesses ist die Konversation und das gemeinsame Verständnis (Shared Understanding) im Team2.... Dieses Verständnis wird durch eine klare Problemformulierung im Vorfeld etabliert1.
Die Problemformulierung, auch Framing genannt1..., zwingt das Team, sich auf die wichtigsten Fragen der Produktentwicklung zu einigen10:
• Welches Problem lösen wir?111
• Für wen?1...
• Welchen Nutzen stiftet das Produkt?1...
Diese Fragen verschieben den Fokus von einer "Feature-Fabrik"-Mentalität hin zu einer "Value-Delivery"-Mentalität3, da die zentrale Frage nun lautet: "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"310.
2. Definition des Umfangs und der Zielgruppe
Im Rahmen der Vorbereitung müssen konkrete Ziele für die Story Map definiert werden, um den Umfang festzulegen15.... Jeff Patton beschreibt diesen ersten Schritt seines fünfstufigen Story-Map-Prozesses als "Frame"89:
1. Frame (Rahmen setzen): Hier wird ein kurzes Feature-Brief erstellt, der „Big Story“-Rahmen gesetzt und die hohen Aktivitäten (die später das Backbone bilden) definiert89.
2. MVP-Definition: In der Vorbereitung sollte bereits geklärt werden, was die Map abbilden soll, und der MVP (Minimum Viable Product) sowie dessen Umfang festgelegt werden15....
Zusätzlich zur Problemdefinition ist die Definition der Ziel-Personas unerlässlich11..., da die gesamte Map aus der Perspektive des Benutzers erstellt wird11.... Es ist eine bewährte Methode, den initialen Workshop auf eine primäre Persona zu fokussieren , um die Komplexität zu reduzieren18.
3. Verbindung zum Backbone (Horizontaler Fluss)
Die Problemformulierung und das "Framing" sind direkt mit der Erstellung der horizontalen Achse, dem Backbone (Rückgrat), verbunden24....
• Die horizontalen Schritte des Backbones bilden die narrative Klammer des Produkts und beschreiben die großen Schritte oder Benutzeraktivitäten2430.
• Diese Aktivitäten repräsentieren in ihrer Gesamtheit eine vollständige Darstellung der User Journey2430 und definieren das "Rückgrat" des Produkts24.
• Indem das Team das Backbone definiert, skizziert es den gesamten Prozess des wichtigsten Nutzer-Typs – das "Big Picture" – im Sinne von „mile-wide, inch-deep“ (meilenweit und zentimetertief)8....
Die Vorbereitung stellt also sicher, dass das Team nicht sofort mit dem Brainstorming von Features beginnt, sondern zuerst klärt, warum es etwas baut, für wen und welche chronologische Abfolge von Benutzeraktivitäten (das Backbone) notwendig ist, um den definierten Nutzen zu liefern1....

--------------------------------------------------------------------------------
Analogie: Die Phase der Vorbereitung oder des Framings ist wie das Kalibrieren eines Kompasses und das Festlegen des Zielhafens für eine Seereise. Bevor das Team die Segel setzt (den Workshop beginnt) und entscheidet, welche Ladung (User Stories) es mitnehmen muss, muss klar sein, welche Küste angesteuert wird (Ziel/Problem), für wen die Reise unternommen wird (Persona) und welche großen Etappen (Backbone) dafür notwendig sind. Ohne dieses klare Framing würde das Team womöglich Ressourcen für Ladung verschwenden, die es auf der tatsächlichen Route nicht benötigt, und das Ziel verfehlen.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Vorbereitung (Framing)“ über „Persona-Definition (Fokus auf primäre Persona)“ aussagen.

Die Diskussion über "Persona-Definition" im Kontext der "Vorbereitung (Framing)" beleuchtet die fundamentale Nutzerzentrierung der User Story Mapping (USM) Methode und legt fest, wie Teams Komplexität in der Anfangsphase reduzieren können.
Die Persona-Definition ist ein unerlässlicher Bestandteil der Vorbereitungsphase (Schritt 0) des Story Mapping Workshops, da die gesamte Map explizit aus der Perspektive des Benutzers erstellt wird1....
1. Persona-Definition im Kontext des Framings
Die Vorbereitung dient dazu, das Fundament für den Erfolg des Workshops zu legen1. Dazu gehört die Problemformulierung (Framing), die ein gemeinsames Verständnis für das Ziel des Produkts oder Features schaffen soll1.
Das Framing stellt dabei die Kernfragen, auf die das gesamte Story Mapping eine Antwort finden muss:
• Welches Problem lösen wir?1....
• Für wen?1....
• Welchen Nutzen stiftet das Produkt?1....
Die Persona-Definition beantwortet die Frage "Für wen?"34. Fiktive Nutzerprofile (Personas) mit definierten Zielen und Problemen7... müssen definiert werden23, um sicherzustellen, dass die Arbeit auf den maximalen Kundennutzen ausgerichtet ist310. Die Story Map fördert eine "Value-Delivery"-Mentalität, indem sie den Fokus von "Was bauen wir als Nächstes?" auf "Welches Problem des Nutzers lösen wir als Nächstes vollständig?" verschiebt611.
2. Fokus auf die primäre Persona
Die Quellen betonen eine etablierte Best Practice für den initialen Workshop:
• Es wird empfohlen, den ersten Story Mapping Workshop gezielt auf eine primäre Persona zu fokussieren2.
• Der zentrale Grund für diesen Fokus ist die Reduzierung der Komplexität2.
Dieser Fokus auf den wichtigsten Nutzer-Typ lenkt den Prozess1213. Nach dem initialen "Frame" (Rahmen setzen) besteht der nächste Schritt darin, den gesamten Prozess dieses wichtigsten Nutzer-Typs zu skizzieren ("Map the Big Picture", mile-wide, inch-deep)1213. Das Backbone – die chronologische Abfolge der Hauptaktivitäten – wird direkt ausgehend von dieser Persona definiert14....
Fazit zur Primär-Persona: Der Start mit einer einzigen, primären Persona stellt sicher, dass das Team bei der Definition der User Journey und der Grobstruktur des Produkts (dem Backbone) nicht durch widersprüchliche oder sekundäre Anforderungen abgelenkt wird2.
3. Umgang mit multiplen Personas (Erweiterung)
Die Fokussierung auf die primäre Persona gilt primär für den ersten Workshop2. Sobald das Produkt reift und das Team weitere Nutzergruppen berücksichtigen muss, bieten die Quellen eine Lösung, um diese zu integrieren, ohne den Kontext zu verlieren:
• Statt für jede Persona eine komplett neue Map zu erstellen, passen fortgeschrittene Teams die bestehende Map an17.
• Das Backbone (die Hauptaktivitäten) bleibt dabei oft gleich17.
• Es werden neue horizontale Zeilen (Swimlanes) für die spezifischen Stories der neuen Persona hinzugefügt, wodurch die Map übersichtlich bleibt und Unterschiede im Nutzerverhalten sichtbar werden17.
Dieser Ansatz stellt sicher, dass die User-Zentrierung beibehalten wird18, während die Story Map als "lebendiges Dokument" für die gesamte Produktentwicklung fungieren kann1719.

--------------------------------------------------------------------------------
Die Persona-Definition fungiert somit als der Kompass in der Vorbereitungsphase: Sie stellt sicher, dass das Team weiß, für wen es baut und welches Problem gelöst werden muss, und sorgt durch die anfängliche Konzentration auf die primäre Persona für einen klaren Start, bevor alternative oder sekundäre Wege erkundet werden1....

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Vorbereitung (Framing)“ über „Elevator Pitch (Produktvision)“ aussagen.

Die Quellen beschreiben die Vorbereitung (Framing) als entscheidend für den Erfolg eines Story Mapping Workshops und positionieren den Elevator Pitch (Produktvision) als zentrales Element, das das Fundament für das gesamte anschließende Mapping legt1.
Hier ist eine detaillierte Diskussion, wie diese beiden Konzepte im Kontext der User Story Mapping Methode zusammenhängen:
1. Der Kontext: Vorbereitung (Framing)
Die Phase der Vorbereitung (Schritt 0) ist der erste Schritt des Story Mapping Prozesses1. Ziel dieser Phase ist es, ein gemeinsames Verständnis (Shared Understanding) für das Ziel des Produkts oder Features zu schaffen12.
Das sogenannte Framing (Problemformulierung) beinhaltet die Klärung der grundlegenden strategischen Fragen, die die Map später beantworten soll1...:
1. Welches Problem lösen wir?15.
2. Für wen? (Dies impliziert die Persona-Definition, die ebenfalls in der Vorbereitung unerlässlich ist)1....
3. Welchen Nutzen stiftet das Produkt?14.
Dieser Schritt definiert den Rahmen der "Big Story"3... und hilft dabei, den Umfang (MVP) und die Ziele der Map festzulegen910. Die Story Map fördert durch diesen Fokus eine "Value-Delivery"-Mentalität und verlagert die zentrale Frage von "Was bauen wir als Nächstes?" zu "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"4....
2. Die Rolle des Elevator Pitch (Produktvision)
Der Elevator Pitch ist das konkrete Werkzeug, mit dem die in der Vorbereitung definierten strategischen Ziele und das Framing im Workshop kommuniziert werden613.
• Vorbereitung des Pitch: Der Product Owner (PO) oder der Business Owner ist dafür verantwortlich, eine kurze, prägnante Präsentation der Produktvision oder des zu planenden Epics vorzubereiten6.
• Zweck: Der Pitch dient dazu, die hohe Ziele und den Rahmen des Projekts zu kommunizieren3....
• Beginn des Workshops: Der Workshop beginnt offiziell damit, dass der Business Owner oder PO diesen vorbereiteten "Elevator Pitch" präsentiert1314.
3. Die Funktionale Verbindung (Framing → Pitch → Backbone)
Der Elevator Pitch fungiert als Auslöser und narrative Klammer zwischen der strategischen Vorbereitung und der praktischen Umsetzung im Workshop:
1. Framing schafft den Inhalt: Die im Framing geklärten Kernfragen (Problem, Nutzer, Nutzen)14 bilden die Basis für die Produktvision, die im Pitch zusammengefasst wird6.
2. Pitch liefert den Kontext: Durch die prägnante Präsentation des Elevator Pitch erhält das funktionsübergreifende Team (bestehend aus Business Owner, Entwicklern, Testern, etc.)615 ein sofortiges gemeinsames Verständnis des übergeordneten Ziels1116.
3. Backbone-Erstellung: Unmittelbar nachdem der Elevator Pitch präsentiert wurde, beginnt der nächste Schritt (Schritt 1 des Workshops): die Erstellung des Backbones (Rückgrat)1314. Das Backbone ist die horizontale Achse der Story Map, die die chronologische Abfolge der wichtigsten Benutzeraktivitäten darstellt17.
Fazit:
Der Elevator Pitch ist die kurze, prägnante Kommunikationsform6 des Framing-Ergebnisses1. Er stellt sicher, dass alle Teilnehmer, bevor sie beginnen, die detaillierte Nutzerreise (Backbone) zu skizzieren, dieselbe Produktvision vor Augen haben613. Ohne diesen klaren Rahmen durch den Pitch würde das Team Gefahr laufen, sich in Details zu verlieren oder an Aufgaben zu arbeiten, die nicht den höchsten Kundennutzen liefern1819.

--------------------------------------------------------------------------------
Analogie zur Veranschaulichung:
Stellen Sie sich den Prozess des Story Mappings wie den Bau eines Gebäudes vor. Die Vorbereitung (Framing) ist die Phase, in der der Architekt und der Kunde die Grundsatzentscheidungen treffen: Welchem Zweck dient das Gebäude (Wohnen oder Büro)? Für wen wird es gebaut (eine Großfamilie oder ein Start-up)? Der Elevator Pitch ist das Modell im Miniaturformat oder der kurze, knackige Bauplan, der dem gesamten Bauteam präsentiert wird, bevor sie die eigentliche Arbeit an der Fundamentstruktur (dem Backbone) beginnen. Er sorgt dafür, dass alle Beteiligten, vom Bauleiter bis zum Handwerker, die Gesamtvision des fertigen Gebäudes verstehen, bevor die ersten Steine gesetzt werden613.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Vorbereitung (Framing)“ über „Teilnehmer (Funktionsübergreifend)“ aussagen.

Die Diskussion der Quellen im Kontext von „Vorbereitung (Framing)“ und „Teilnehmer (Funktionsübergreifend)“ zeigt, dass die Zusammensetzung des Teams in der Story-Mapping-Vorbereitungsphase der kritischste Erfolgsfaktor für den gesamten Workshop ist1.
Der Story Mapping Workshop selbst wird als eine „kuratierte Konversation“ beschrieben, deren wahrer Wert nicht im fertigen Artefakt, sondern im kollaborativen Prozess und der Kollektivierung des Wissens aller Beteiligten entsteht23.
1. Die Rolle der Teilnehmer in der Vorbereitungsphase (Framing)
Die Phase der Vorbereitung (Schritt 0) dient dazu, das Fundament für den Erfolg des Workshops zu legen2. Innerhalb dieser Vorbereitung, zu der auch die Problemformulierung (Framing) gehört, muss das Team ein gemeinsames Verständnis für das Ziel des Produkts oder Features entwickeln, indem es die Kernfragen klärt: Welches Problem lösen wir? Für wen? Welchen Nutzen stiftet das Produkt?24.
Die Teilnehmerauswahl ("Das Who") ist unmittelbar mit dieser Framing-Aufgabe verknüpft1.... Die Quellen betonen, dass die Map nur dann erfolgreich sein kann, wenn sie funktionsübergreifend (cross-functional) erstellt wird, da nur so alle notwendigen Perspektiven in die initiale Definition und Planung einfließen1....
2. Die Anforderung der Funktionsübergreifenden Besetzung
Die Zusammenstellung des Teams muss funktionsübergreifend besetzt sein17. Ziel ist es, Business (Warum?), UX (Für wen?) und Entwicklung (Wie?) an einen Tisch zu bringen7.
Die wichtigsten Rollen sind dabei:
• Der Moderator (Facilitator): Diese Person leitet den Prozess und ist oft der Product Owner (PO), Scrum Master oder ein Business Analyst1....
• Business Owner / Stakeholder: Sie sind notwendig, um die Geschäftsziele zu verstehen und die grundlegenden „Warum“-Fragen beantworten zu können910.
• Das Entwicklungsteam (Entwickler, Tester, UX/Design): Ihre Anwesenheit ist essenziell, um die technische Machbarkeit zu beurteilen und die richtigen Fragen zu Abhängigkeiten und Aufwänden zu stellen5....
Es wird empfohlen, fünf bis zehn Personen aus unterschiedlichen Rollen einzuladen, wobei eine diverse Gruppe die Perspektivenvielfalt erhöht5.... Die ideale Größe liegt bei etwa 7–10 Personen1, oder idealerweise bei 5–8 Personen in einer kleinen, diversen Gruppe12....
3. Die essentielle Rolle des Entwicklungsteams (Risikominimierung)
Die Quellen unterstreichen, dass die Teilnahme des Entwicklungsteams in der Vorbereitungs- und Erstellungsphase kritisch für die Realitätsnähe der Planung ist1516.
• Vermeidung der „Fantasy Map“: Einer der häufigsten Fallstricke (Pitfalls) ist die „Fantasy Map“16. Diese entsteht, wenn der Workshop nur von Business- und UX-Vertretern durchgeführt wird16. Das Ergebnis ist eine reine Wunschliste, die technische Abhängigkeiten, Aufwände und Risiken ignoriert1617.
• Einfügen technischer Realitäten: Während der Product Owner und UX-Designer die benutzer-sichtbaren Stories beitragen, ist es die Aufgabe der Entwickler, auf technische Abhängigkeiten hinzuweisen15. Sie fügen "unsichtbare" technische Stories (z.B. "Datenbank-Schema anlegen" oder "Zahlungs-API integrieren") an den richtigen Stellen in die Map ein15.
• Grundlage für Planung: Ohne die aktive Teilnahme des Entwicklungsteams wäre die Map keine realistische Planungsgrundlage15.
• Erhöhung des Verständnisses: Durch die Teilnahme hört das Entwicklungsteam die zugrundeliegenden Gründe (Bedürfnisse, Probleme, Erwartungen) direkt von Nutzern und Stakeholdern, was zu Erkenntnissen führen kann, die ihnen sonst entgangen wären10.
Zusammenfassend stellen die Quellen klar, dass das Framing (Problemformulierung und Zielsetzung)218 und die Definition der Teilnehmer ("Das Who")1 Hand in Hand gehen: Nur eine funktionsübergreifende Besetzung stellt sicher, dass die in der Vorbereitung definierten Produktziele219 nicht zu einer technisch unrealisierbaren „Fantasy Map“ degenerieren, sondern in ein planbares, durch technisches Wissen geerdetes Artefakt münden1516.

--------------------------------------------------------------------------------
Man könnte sich den funktionsübergreifenden Story-Mapping-Workshop wie ein Architektenteam vorstellen, das den Bau eines komplexen Hauses plant: Der Bauherr (Business Owner) definiert das Warum und Wofür (Geschäftsnutzen); der Innenarchitekt (UX/Design) definiert das Für wen und die Ästhetik (Benutzererlebnis/Persona); und der Statiker/Bauleiter (Entwicklungsteam) ist unabdingbar, um die Machbarkeit zu prüfen und sicherzustellen, dass das Fundament (technische Stories) gelegt wird, damit das Haus nicht nur schön, sondern auch stabil und realisierbar ist7....

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Teilnehmer (Funktionsübergreifend)“ über „Moderator (Facilitator)“ aussagen.

Der Moderator (Facilitator) spielt eine zentrale Rolle für den Erfolg eines Story Mapping Workshops1..., insbesondere weil dieser Workshop funktionsübergreifend besetzt sein muss1....
Die Quellen beschreiben den Moderator als die Person, die den Prozess leitet und die "kuratierte Konversation" steuert, aus der der eigentliche Wert der Story Map entsteht5....
I. Die Rolle und Besetzung des Moderators
Die Moderation des Story Mapping Workshops wird typischerweise von Personen mit starker Prozesskompetenz übernommen1:
• Häufige Besetzung: Der Moderator (Facilitator) ist oft der Product Owner (PO), der Scrum Master oder ein Business Analyst1.
• In agilen Umgebungen wird auch explizit empfohlen, dass der Scrum Master oder ein Coach die Story Mapping Session moderieren sollte3.
• Aufgabe: Diese Person leitet den Prozess des Workshops6.
II. Der Moderator im funktionsübergreifenden Kontext
Der kritischste Erfolgsfaktor des Workshops ist die Zusammensetzung des Teams, das funktionsübergreifend sein muss1. Die Hauptaufgabe des Moderators ist es, diese unterschiedlichen Perspektiven zu einem gemeinsamen Verständnis (Shared Understanding) zu führen7...:
1. Einbindung der Rollen: Der Moderator sorgt dafür, dass alle wichtigen Perspektiven am Tisch vertreten sind und gehört werden34:
    ◦ Business Owner / Stakeholder: Sie verstehen die Geschäftsziele und beantworten die "Warum"-Fragen6.
    ◦ Entwicklungsteam (Entwickler, Tester, UX/Design): Sie beurteilen die technische Machbarkeit und stellen die notwendigen Fragen zu Aufwänden und Abhängigkeiten36.
    ◦ Produkt/UX (PO/Designer): Sie bringen die Benutzersicht ein1011.
2. Technisches Framing: Die aktive Rolle der Entwickler ist offensichtlich, da sie die "unsichtbaren" technischen Stories (z.B. Datenbank-Schema anlegen) an den richtigen Stellen in die Map einfügen10. Der Moderator muss sicherstellen, dass die Map nicht zu einer "Wunschliste" wird, indem er das Entwicklungsteam zwingend einbezieht, um technische Risiken zu vermeiden1012.
III. Kernaufgaben und Moderationstechniken
Der Moderator ist verantwortlich für die Gestaltung der Umgebung und die Einhaltung der Regeln13...:
• Vorbereitung: Er muss klare Ziele setzen und diese im Briefing an alle Teilnehmenden kommunizieren13....
• Sicherstellung der "Konversation": Die Story Map ist ein diskursives Werkzeug, das von Gesprächen lebt16.... Der Moderator schafft die psychologische Sicherheit im Raum (oder digital), damit Ideen kritisch diskutiert werden können, aber nicht die Personen selbst13....
• Prozessleitung: Der Moderator leitet das Team durch die Schritte: vom Kick-off über die Definition des Backbones19... und das Sammeln der Stories19... bis hin zur Priorisierung15....
IV. Die Moderatorrolle beim Release-Slicing
Eine der wichtigsten Aufgaben, die der Moderator oder der Product Owner am Ende des Workshops übernimmt, ist das Slicing219:
• Der Moderator (oder Product Owner) zieht horizontale Linien über die gesamte Breite der Map2....
• Diese Release-Slices unterteilen die vertikal priorisierten Stories in geplante Releases oder Versionen, wobei der erste Slice das Minimum Viable Product (MVP) definiert2....
• Der Workshop gilt als erst beendet, wenn der erste Slice (das MVP) klar definiert, visualisiert und vom Team committet ist30. Der Moderator sorgt also für den formalen Abschluss der Planung.
Zusammenfassend ist der Moderator der Dirigent des Story Mapping Orchesters, das aus verschiedenen funktionsübergreifenden Rollen besteht. Er stellt sicher, dass alle Instrumente (Business, Technik, UX) im Einklang spielen, um nicht nur ein Artefakt zu schaffen, sondern vor allem ein gemeinsames, nutzerzentriertes Produktverständnis zu erzeugen5....

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Teilnehmer (Funktionsübergreifend)“ über „Business Owner / Stakeholder (Warum-Fragen)“ aussagen.

Die Quellen positionieren den Business Owner / Stakeholder als einen kritischen Erfolgsfaktor und eine unverzichtbare Rolle im funktionsübergreifenden Team des Story Mapping Workshops12.
Ihre Hauptaufgabe liegt in der strategischen Rahmensetzung und der Beantwortung der "Warum"-Fragen, wodurch sie das gesamte Entwicklungsteam auf die Geschäftsziele ausrichten23.
Im Folgenden wird die Rolle im Kontext der Workshop-Teilnehmer diskutiert:
1. Die Funktion des Business Owners: Antworten auf die „Warum“-Fragen
Die zentrale Funktion des Business Owners bzw. der Stakeholder besteht darin, die Geschäftsziele zu repräsentieren und sicherzustellen, dass das entstehende Produkt den gewünschten Nutzen stiftet34.
• Geschäftsziel-Kompetenz: Der Business Owner / Stakeholder ist die Person im Workshop, die die Geschäftsziele verstehen3 und definieren kann.
• Fundamentale Fragen: Die Story Map selbst ist darauf ausgelegt, Antworten auf grundlegende Fragen der Produktentwicklung zu liefern5.... Der Business Owner ist primär dafür verantwortlich, die Antworten auf diese Fragen zu liefern:
    ◦ "Warum bauen wir das?"5...
    ◦ "Welchen Nutzen liefert es?"4...
    ◦ "Für wen?"4...
Diese inhaltliche Rahmensetzung ist entscheidend, da das Ziel der Story Map darin besteht, eine "Value-Delivery"-Mentalität zu erzwingen, bei der die zentrale Frage lautet: "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"79.
2. Die Rolle im Funktionsübergreifenden Team
Der Story Mapping Workshop wird als eine "kuratierte Konversation"410 beschrieben, die ein funktionsübergreifendes Team erfordert, um erfolgreich zu sein1. Der Business Owner spielt in dieser Konstellation eine spezifische, strategische Rolle neben den anderen Teilnehmern:
• Zusammensetzung: Der Workshop muss Business (Warum?), UX (Für wen?) und Entwicklung (Wie?) an einen Tisch bringen2. Die ideale Größe des Teams liegt zwischen 5–8 oder 7–10 Personen1....
• Wichtigkeit der Teilnahme: Die Zusammenstellung des Teams wird als der kritischste Erfolgsfaktor angesehen1. Die Teilnahme von Stakeholdern erhöht die Perspektivenvielfalt13....
• Wissenskollektivierung: Wenn das Entwicklungsteam teilnimmt, hört es direkt die zugrunde liegenden Gründe (underlying reasons), Bedürfnisse und Frustrationen, die Nutzer und Stakeholder haben16. Dies führt zu einem gemeinsamen Verständnis (Shared Understanding)1017 und kann den Teammitgliedern zu Erkenntnissen verhelfen, die sie sonst verpasst hätten16.
3. Konkrete Aufgaben im Workshop-Prozess
Der Business Owner ist maßgeblich an zwei Phasen des Workshops beteiligt: dem Kick-off (Framing) und der Priorisierung.
• Kick-off (Elevator Pitch): Der Workshop beginnt damit, dass der Business Owner (oder der Product Owner) den vorbereiteten "Elevator Pitch" präsentiert1.... Dies legt den "Big Story"-Rahmen19... fest und kommuniziert die Produktvision oder das zu planende Epic118.
• Priorisierung und MVP-Definition: Bei der Priorisierung der User Stories werden die Stakeholder (einschließlich des Business Owners) gemeinsam herangezogen, um zu definieren, welche Stories in das Minimum Viable Product (MVP) gehören22.... Die Priorisierung innerhalb der vertikalen Spalten richtet sich nach Kriterien wie Nutzen, Risiko und technischem Aufwand22....
Die Anwesenheit des Business Owners stellt somit sicher, dass die Priorisierung nicht nur auf Basis der technischen Machbarkeit oder des Interesses der Entwickler erfolgt, sondern auf dem höchsten Kundennutzen2526.

--------------------------------------------------------------------------------
Zusammenfassend lässt sich sagen: Der Business Owner/Stakeholder ist im Story Mapping Workshop der strategische Anker. Wenn der Workshop ein funktionsübergreifendes Schiff ist, das eine Landkarte erstellt, ist der Business Owner der Kompass, der sicherstellt, dass die Route (die Story Map) konsequent auf den wirtschaftlichen Nordstern (die Geschäftsziele und den Kundennutzen) ausgerichtet ist, indem er die fundamentalen "Warum"-Fragen beantwortet37.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Teilnehmer (Funktionsübergreifend)“ über „Entwicklungsteam (Machbarkeit, Aufwände, technische Abhängigkeiten)“ aussagen.

Die Quellen betonen die unverzichtbare Rolle des Entwicklungsteams im Story Mapping Workshop und sehen deren Beteiligung als kritischsten Erfolgsfaktor für die Erstellung einer realistischen und umsetzbaren Story Map1....
Das Entwicklungsteam (bestehend aus Entwicklern, Testern und UX/Designern)2 ist maßgeblich dafür verantwortlich, die technische Realität und Machbarkeit in den benutzerzentrierten Planungsprozess einzubringen.
Hier sind die zentralen Aussagen der Quellen bezüglich der Beiträge des Entwicklungsteams:
1. Beurteilung der technischen Machbarkeit und Komplexität (Aufwände)
Die Entwickler sind erforderlich, um die Machbarkeit der Features zu beurteilen und die Story Map in eine realistische Planungsgrundlage zu verwandeln24.
• Beurteilung der Machbarkeit: Die Teammitglieder sind Personen, die die technische Machbarkeit beurteilen (technische Machbarkeit beurteilen) können2.
• Beitrag zur Priorisierung: Die Wichtigkeit der User Stories, nach der sie vertikal sortiert werden, ergibt sich aus einer Kombination von Nutzen, Risiko und technischem Aufwand5....
• Hinterfragen und Schätzen: Es ist ihre Aufgabe, die richtigen Fragen zu Abhängigkeiten und Aufwänden zu stellen2. Methoden wie der Value vs. Complexity Quadrant nutzen den Entwicklungsaufwand (Complexity/Cost) explizit als Priorisierungskriterium, um "Quick Wins" zu identifizieren8.
• Steuerung der Konversationstiefe: Teammitglieder können auch dabei helfen, Diskussionen auf dem richtigen Detaillierungsgrad zu halten, um zu verhindern, dass Teilnehmer mehr Zeit damit verbringen, über etwas zu reden, als die Entwickler bräuchten, um es umzusetzen9.
2. Identifizierung und Integration technischer Abhängigkeiten
Der zentrale Wert des Story Mapping Workshops liegt in der Kollekivierung von Wissen und der Risikominimierung10. Die Entwickler spielen hier eine aktive, unverzichtbare Rolle, insbesondere während Schritt 4 ("Lücken und Abhängigkeiten identifizieren")10.
• Aufdeckung technischer Anforderungen: Durch das narrative Abwandern der Map als Gruppe deckt das Team notwendige technische Anforderungen (Technical Stories) und Abhängigkeiten zwischen Spalten auf, die zuvor übersehen wurden10.
• Einbringen technischer Stories: Während Produkt-Owner (PO) und UX-Designer die benutzer-sichtbaren Stories beitragen, ist es die Aufgabe der Entwickler, auf technische Abhängigkeiten hinzuweisen4.
• Platzierung "unsichtbarer" Stories: Die Entwickler fügen "unsichtbare" technische Stories (wie z.B. "Datenbank-Schema anlegen" oder "Zahlungs-API integrieren") an den richtigen Stellen in die Map ein4.
• Risikomanagement: Die Story Map wird genutzt, um Annahmen, Abhängigkeiten und technische Risiken zu visualisieren und zu diskutieren3. Risikonotizen machen unsichere Annahmen oder externe Abhängigkeiten sichtbar und ermöglichen ein rechtzeitiges Gegensteuern5....
3. Konsequenzen bei fehlender Beteiligung
Die Quellen warnen explizit vor dem Szenario, in dem das Entwicklungsteam nicht vollumfänglich am Workshop teilnimmt:
• Die "Fantasy Map": Wenn der Workshop nur von Business- und UX-Vertretern durchgeführt wird, ist die resultierende Map eine "Wunschliste"415. Dies wird als häufiger Fallstrick bezeichnet (Pitfall 6: The "Fantasy Map"), da sie technische Abhängigkeiten, Aufwände und Risiken ignoriert15.
• Fehlende Planungsgrundlage: Ohne die aktive Teilnahme der Entwickler ist die Map keine realistische Planungsgrundlage4.
Um die User-Zentrierung der Map zu gewährleisten, wird jedoch empfohlen, dass die eigentlichen User Stories (aus Nutzersicht formuliert) technische Formulierungen vermeiden1617 und technische Aufgaben in separate Spalten ausgelagert werden können18.... Die kritische Anwesenheit der Entwickler3... sorgt jedoch dafür, dass diese technischen Anforderungen erkannt und dennoch in die Planung integriert werden4.

--------------------------------------------------------------------------------
Fazit (Analogie): Das Entwicklungsteam agiert im Story Mapping Workshop wie die Bauingenieure und Statiker in einem Architekturbüro. Während die Architekten (PO, UX) die Vision und das Nutzererlebnis (die nutzerzentrierte Story) entwerfen, stellen die Ingenieure sicher, dass das Gebäude nicht nur ästhetisch ansprechend ist, sondern auch auf einem festen Fundament steht, die richtigen Materialien verwendet und die Statik den Bau ermöglicht (Machbarkeit, technische Abhängigkeiten und Aufwände)24.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Story Mapping Workshop (Vorgehen)“ über „Durchführung (Schritte)“ aussagen.

Der Story Mapping Workshop ist der kollaborative Prozess, durch den die User Story Map (USM) erstellt wird. Die Quellen betonen, dass der wahre Wert dieser Durchführung in der "kuratierten Konversation" und der Kollekivierung von Wissen liegt, was zum "Shared Understanding" (gemeinsamen Verständnis) im Team führt1....
Das Vorgehen zur Durchführung (abgeschlossen durch eine sorgfältige Vorbereitung, das Framing) lässt sich in einen fünfstufigen Prozess (nach Jeff Patton) oder eine Reihe von aufeinander aufbauenden Workshop-Schritten unterteilen, die die horizontale (Backbone/Reise) und die vertikale (Priorität/Detaillierung) Achse der Map aufbauen5....

--------------------------------------------------------------------------------
I. Kick-off und Aktivierung
Der Workshop beginnt mit einer formalen Initialisierungsphase:
1. Begrüßung und psychologische Sicherheit: Die Teilnehmer werden begrüßt10.... Es ist wichtig, psychologische Sicherheit herzustellen, oft durch Eisbrecher (wie „Unlikely User“), um eine offene Diskussion zu ermöglichen10.... Es gilt die Regel, Ideen zu kritisieren, nicht Personen13....
2. Elevator Pitch: Der Business Owner oder Product Owner präsentiert den vorbereiteten "Elevator Pitch" der Produktvision oder des zu planenden Epics1017. Dies setzt den inhaltlichen Rahmen, der bereits in der Vorbereitung definiert wurde18.
II. Schritt 1: Backbone definieren (Die horizontale Achse)
Dieser Schritt konzentriert sich auf die Erstellung des "Big Picture" und der narrativen Struktur der User Journey7....
1. Brainstorming: Unmittelbar nach dem Pitch beginnt die Erstellung des Backbones17. Ein gängiger Ansatz ist das schweigende Brainstorming der Teilnehmer, bei dem alle Hauptaktivitäten (User Activities/Themen) notiert werden, die die definierte Persona zur Erreichung ihres Ziels durchführen muss10....
2. Chronologische Anordnung: Diese gesammelten Aktivitäten (die "großen Schritte" oder grobgranularen Epics) werden kollaborativ in die richtige chronologische Reihenfolge von links nach rechts gebracht6.... Diese Kette bildet das initiale Backbone (Rückgrat) der Map und fungiert als narrative Klammer des Produkts623.
III. Schritt 2: Detaillierung der Stories (Die vertikale Achse)
Sobald das Backbone steht, wird die Map vertikal mit Details gefüllt, was Jeff Patton als "Explore" bezeichnet7....
1. User-Stories sammeln ("Brain Dump"): Für jede Aktivität im Backbone (jede Spalte) sammelt das Team nun alle Teilschritte, Aufgaben und konkreten User Stories, die notwendig sind, um diese Aktivität durchzuführen10....
2. Fokus auf Vollständigkeit: In dieser Phase ist Vollständigkeit wichtiger als Priorisierung24. Das Team wird ermutigt, alle Ideen, Alternativen und auch Bedenken auf Zettel zu schreiben, ohne sich einzuschränken19.
3. Zuordnung: Diese Stories werden zunächst unsortiert unter die jeweilige Backbone-Aktivität gehängt2426. Die Detailtiefe nimmt nach unten zu; die Stories beschreiben konkrete Interaktionen20....
IV. Schritt 3: Strukturierung und Priorisierung
Dieser Schritt befasst sich mit der vertikalen Organisation der gesammelten Stories10....
1. Sortierung: Die User Stories werden innerhalb ihrer jeweiligen vertikalen Spalte (unterhalb des Backbone-Schritts) priorisiert10....
2. Prioritätskriterien: Die Wichtigkeit ergibt sich aus einer gemeinsamen Bewertung von Nutzen, Risiko und technischem Aufwand10....
3. Anordnung: Die Stories, die für eine minimale Funktionsfähigkeit und die Kernfunktion unerlässlich sind („Must-haves“), werden nach oben (direkt unter das Backbone) geschoben24.... Weniger wichtige Stories oder alternative Implementierungen wandern nach unten2426.
V. Schritt 4: Lücken und Abhängigkeiten identifizieren
Dieser Schritt gilt als der kritischste des gesamten Workshops, da hier der eigentliche Wert der Konversation entsteht2.
1. Narrativer Walkthrough: Das Team "wandert" die Map narrativ ab, von der ersten Aktivität links bis zur letzten rechts, indem es die Geschichte aus der Sicht des Benutzers erzählt226.
2. Risikominimierung: Durch diesen Prozess deckt das Team unweigerlich Lücken (gaps), Engpässe, fehlende Informationen, Abhängigkeiten zwischen Spalten und notwendige technische Anforderungen (Technical Stories) auf2....
3. Einbeziehung der Entwickler: Während Product Owner und Designer die benutzer-sichtbaren Stories einbringen, ist es die Aufgabe des Entwicklungsteams, auf technische Abhängigkeiten hinzuweisen und "unsichtbare" technische Stories (z.B. "Datenbank-Schema anlegen") an den richtigen Stellen in die Map einzufügen33. Ohne diese Teilnahme riskiert die Map, eine unrealistische "Wunschliste" zu werden3334.
VI. Schritt 5: Release-Planung (Slicing)
Dieser abschließende Schritt überführt die fertige, priorisierte Map in eine konkrete, umsetzbare Produkt-Roadmap3536. Patton nennt dies "Slice Out Viable Releases"7....
1. Horizontale Linien ziehen: Der Moderator zieht horizontale Linien ("Release-Slices" oder "Cut-Lines") über die gesamte Breite der Map, oft mithilfe von Klebeband oder farbigen Linien10....
2. MVP definieren: Die oberste Scheibe (alles oberhalb der ersten Linie) definiert das Minimum Viable Product (MVP)10....
3. Walking Skeleton: Das durch Slicing definierte MVP ist der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt – der "Walking Skeleton"14.... Um eine durchgängige Benutzererfahrung zu gewährleisten, muss der MVP-Slice mindestens eine Story aus jedem kritischen Backbone-Schritt enthalten40....
4. Abschluss: Die Slices unterhalb des MVP repräsentieren nachfolgende Releases, die dem "Walking Skeleton" mehr "Fleisch" (zusätzliche Funktionen) hinzufügen4445. Der Workshop gilt erst als beendet, wenn der erste Slice (MVP) definiert, visualisiert und vom Team committet ist38.
VII. Laufende Pflege
Die Quellen betonen, dass die Durchführung des Workshops mit der Freigabe des MVP nicht endet. Die Map ist ein "lebendes Artefakt" oder ein "lebendes, atmendes Ding"10.... Sie sollte regelmäßig aktualisiert und vor jedem Sprintplanungstreffen angepasst werden, um sie in die regulären agilen Zyklen (Grooming) zu integrieren10....

--------------------------------------------------------------------------------
Der Story Mapping Workshop ist vergleichbar mit dem Bau eines Hauses. Man beginnt nicht mit den Fenstern (den kleinsten Stories), sondern mit dem Fundament und dem Rahmenwerk (Backbone). Erst wenn dieser Rahmen steht (Schritt 1), füllt man die Etagen (Schritt 2) und sortiert die Inneneinrichtung nach Priorität (Schritt 3). Der wichtigste Schritt ist die gemeinsame "Begehung" (Schritt 4), bei der das Team als Gruppe durch die Räume geht, um vergessene Steckdosen oder tragende Wände zu identifizieren. Abschließend wird entschieden, welche Teile des Hauses sofort bewohnbar (MVP) und welche in späteren Phasen hinzugefügt werden (Slicing/Releases).

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Durchführung (Schritte)“ über „Kick-off (Psychologische Sicherheit)“ aussagen.

Die Quellen betrachten den Kick-off als den ersten formalen Schritt in der Durchführung des Story Mapping Workshops. Die Hauptaussage der Quellen in diesem Kontext ist, dass der Kick-off nicht nur der formellen Begrüßung dient, sondern primär dazu eingesetzt werden muss, die Grundlage für eine erfolgreiche Kollaboration zu legen.
Das zentrale Ziel des Kick-offs in Bezug auf die Teamdynamik ist es, psychologische Sicherheit herzustellen1... bzw. zu schaffen4....
1. Die Notwendigkeit der Psychologischen Sicherheit
Die Story Map ist ein diskursives Werkzeug78, dessen wahrer Wert in der "kuratierten Konversation" liegt9. Um dieses gemeinsame Verständnis (Shared Understanding) zu erreichen, muss sich das funktionsübergreifende Team10 sicher fühlen, Annahmen, Bedenken und kritische Fragen offen zu äußern. Die psychologische Sicherheit stellt sicher, dass der Workshop nicht zu einem rein formalen Meeting wird, sondern zu einem Mechanismus zur Kollektivierung von Wissen und zur Risikominimierung9.
2. Maßnahmen zur Schaffung von Sicherheit
Die Quellen schlagen konkrete Maßnahmen vor, die vom Moderator (Facilitator)10 im Kick-off angewendet werden sollten:
A. Begrüßung und Eisbrecher
Der Workshop beginnt damit, die Teilnehmer zu begrüßen1.... Um die anfängliche Atmosphäre zu lockern und eine erste, ungezwungene Interaktion zu fördern, wird der Einsatz von Eisbrechern empfohlen1....
Ein spezifisch genannter Eisbrecher ist der „Unlikely User“1.... Bei dieser spielerischen Übung erzählt jede Person eine unerwartete Nutzungserfahrung mit einem Produkt11, was den Fokus sofort auf die Nutzerperspektive lenkt und gleichzeitig eine entspannte Stimmung schafft.
B. Festlegung von Grundregeln (Ground Rules)
Als Moderationstipp und explizite Regel für den Workshop wird die Notwendigkeit der psychologischen Sicherheit hervorgehoben4....
Diese Sicherheit wird durch das Aufstellen von Ground Rules4... erreicht, die oft beinhalten:
• Ideen kritisch diskutieren, nicht Personen4.... Dies ist die wichtigste Regel, um sicherzustellen, dass die Teilnehmer ehrliches, konstruktives Feedback geben, ohne Angst vor negativen persönlichen Konsequenzen.
• Auf den Ideen anderer aufbauen612. Diese Regel fördert eine additive und kollaborative Arbeitsweise, die für das erfolgreiche Brainstorming und die Detaillierung der Stories (Schritt 2) essenziell ist12.
Durch die frühe Etablierung dieser Regeln im Kick-off wird sichergestellt, dass die Teilnehmer, insbesondere das Entwicklungsteam13, sich trauen, während des Mappings technische Abhängigkeiten und Risiken frühzeitig aufzudecken914, wodurch die Map davor bewahrt wird, zu einer unrealistischen "Wunschliste" zu werden1516.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Durchführung (Schritte)“ über „Schritt 1: Backbone definieren (Chronologische User Activities)“ aussagen.

Der Story Mapping Workshop gliedert sich nach der Vorbereitungsphase (Framing) in mehrere Schritte, wobei Schritt 1 die fundamentale horizontale Struktur der Map festlegt.
Dieser Schritt, von Jeff Patton als „Map the Big Picture“ bezeichnet, ist darauf ausgerichtet, den gesamten Prozess des wichtigsten Nutzer-Typs zu skizzieren1. Die Arbeitsweise wird dabei als „mile-wide, inch-deep“ (meilenweit und zentimetertief) beschrieben1.
1. Die Funktion des Backbones (Die horizontale Achse)
Das Backbone (Rückgrat) bildet die horizontale Achse der Story Map23. Es ist die oberste Reihe der Karte und dient als narrative Klammer des Produkts2.
• Chronologie und Abfolge: Die Karten auf dem Backbone müssen von links nach rechts in der richtigen chronologischen Reihenfolge angeordnet werden, in der ein typischer Nutzer sie ausführt2.... Die horizontale Anordnung repräsentiert eine Abfolge von Schritten57. Man liest diese Achse, indem man mental das Wort "dann" (then) zwischen die Karten einfügt58.
• Bestandteile: Das Backbone besteht aus grobgranularen Epics2 oder "großen Schritten"2, die als Benutzeraktivitäten (User Activities)2... oder Themen9... formuliert werden. Diese Aktivitäten beschreiben hohe Ziele des Nutzers4.
• Zweck: Das Backbone liefert in seiner Gesamtheit eine vereinfachte, aber vollständige Darstellung der User Journey2.... Es zeigt das „Warum“ hinter den detaillierten User-Stories, die in den folgenden Schritten darunter einsortiert werden1011.
2. Das Vorgehen im Workshop
Die Erstellung des Backbones folgt unmittelbar auf den Kick-off des Workshops:
• Kick-off: Der Workshop beginnt damit, dass der Business Owner den vorbereiteten "Elevator Pitch" der Produktvision präsentiert13. Unmittelbar danach beginnt die Erstellung des Backbones213.
• Brainstorming der Aktivitäten: Ein gängiger Ansatz besteht darin, dass alle Teilnehmer zunächst schweigend (z.B. in 10 Minuten)14 alle Hauptaktivitäten brainstormen, die die Persona zur Erreichung ihres übergeordneten Ziels durchführen muss1315.
• Kollaborative Anordnung: Diese groben Aktivitäten (Epics/Themen) werden gesammelt und vom Team kollaborativ in die richtige chronologische Reihenfolge gebracht, wodurch die horizontale Achse (der horizontale „Knochen“) entsteht14....
3. Bedeutung für die Struktur
Die Definition des Backbones ist entscheidend, da es die erste der beiden Dimensionen der Map festlegt2. Es stellt die horizontale Frage der Story Map: "Haben wir an die gesamte Reise gedacht?" (Sind alle notwendigen Backbone-Schritte vorhanden?)18.
Das Erzwingen dieser horizontalen Abbildung der gesamten Reise zwingt das Team, zuerst das große Ganze abzubilden19 und stellt sicher, dass Lücken (gaps) in der User Journey sofort visuell ersichtlich werden19....
Beispiele für Backbones:
• E-Commerce-Plattform: Produkte erkunden → Produkte vergleichen/auswählen → Zur Kasse gehen/Bezahlen → Bestellung verfolgen/empfangen2....
• Mobile-Banking-App: Kontostand anzeigen, Geld überweisen und Rechnungen bezahlen2425.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Durchführung (Schritte)“ über „Schritt 2: Stories detaillieren (Brain Dump, Vollständigkeit zählt)“ aussagen.

Schritt 2 des Story Mapping Workshops, oft als "Explore" in Jeff Pattons Prozess bezeichnet1..., konzentriert sich auf die Detaillierung der Nutzerreise, nachdem das hochgradige Rückgrat (Backbone) festgelegt wurde4. Dieser Schritt ist fundamental für die Schaffung der vertikalen Achse der Story Map und legt den Grundstein für die spätere Priorisierung.
Die Quellen beschreiben das Vorgehen in diesem Schritt wie folgt:
1. Durchführung des "Brain Dump"
Sobald das horizontale Backbone (Schritt 1) steht – das die chronologische Abfolge der Hauptaktivitäten des Nutzers darstellt – führt das Team einen "Brain Dump" durch4.
• Ziel des Sammelns: Für jede Aktivität im Backbone (d.h. jede Spalte) sammelt das funktionsübergreifende Team nun alle detaillierten Teilschritte, Aufgaben und User Stories, die zur Durchführung dieser Aktivität notwendig sind45.
• Format der Stories: Diese Elemente können in klassischer Formulierung ("Als [Typ] will ich [Ziel], um [Mehrwert]") oder als simple Aufgaben formuliert werden6....
• Herunterbrechen: Dieser Vorgang entspricht der Phase, in der größere Tasks in kleinere Tasks und UI-Details heruntergebrochen werden1....
2. Fokus auf Vollständigkeit, nicht Priorisierung
Der kritische Aspekt dieses Schritts ist die Priorisierung der Quantität und Breite über die unmittelbare Wichtigkeit:
• Vollständigkeit zählt: In dieser Phase ist Vollständigkeit wichtiger als Priorisierung4.
• Umfassende Ideensammlung: Das Team wird ermutigt, alle Ideen, Alternativen und auch Bedenken auf Zettel zu schreiben, ohne sich einzuschränken4. Das Ziel ist, eine umfassende Sammlung aller potenziellen Funktionen zu erstellen.
• Anordnung: Die gesammelten Stories werden (zunächst unsortiert) unter die jeweilige Backbone-Aktivität gehängt4.
3. Etablierung der Vertikalen Achse
Durch die Detaillierung entsteht die vertikale Achse der Story Map, die eine wichtige strukturelle Funktion erfüllt5:
• Detaillierungsgrad: Die vertikale Anordnung beschreibt den Detaillierungsgrad9... – von den groben Aktivitäten des Backbones bis zu den konkreten, kleinen User Stories/Tasks58.
• Alternativen: Die vertikale Dimension sammelt die verschiedenen Möglichkeiten, wie ein Backbone-Schritt ausgeführt werden kann5.
Indem das Team in Schritt 2 alle potenziellen Stories sammelt und die vertikale Achse füllt, wird sichergestellt, dass keine Lücken (gaps) oder fehlenden Funktionalitäten übersehen werden1112, bevor in Schritt 3 die eigentliche Priorisierung und Strukturierung erfolgt4.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Durchführung (Schritte)“ über „Schritt 3: Strukturierung & Priorisierung (Vertikal nach Wichtigkeit)“ aussagen.

Schritt 3 des Story Mapping Workshops, die Strukturierung und Priorisierung, ist die Phase, in der die in Schritt 2 gesammelten detaillierten User Stories auf der vertikalen Achse der Map angeordnet werden. Diese vertikale Anordnung ist das zentrale Element, das die Story Map von einem flachen Backlog unterscheidet12.
Die Quellen beschreiben diesen Schritt als die Phase, in der die Stories innerhalb ihrer jeweiligen Spalte (unterhalb des zugehörigen Backbone-Schritts) nach Wichtigkeit sortiert werden3.

--------------------------------------------------------------------------------
1. Die Vertikale Achse: Wichtigkeit und Alternativen
Die vertikale Achse ist die zweite Dimension der Story Map und repräsentiert den Prioritäts- und Detaillierungsgrad1.
• Prioritätsanordnung: Die gesammelten User Stories werden vertikal nach Priorität sortiert4.... Die wichtigsten Stories kommen dabei ganz nach oben4.... Stories mit geringerer Priorität, alternative Lösungswege oder Ideen für spätere Versionen folgen darunter13.
• Leserichtung: Die vertikale Anordnung zeigt Alternativen auf9. Man liest Stories, die untereinander stehen, indem man mental das Wort "oder" zwischen die Karten einfügt9.
• Must-haves: Stories, die für eine minimale Funktionsfähigkeit des jeweiligen Backbone-Schritts unerlässlich sind ("Must-haves"), werden nach oben geschoben, direkt unter das Backbone310. Weniger wichtige Stories ("Nice-to-haves") wandern nach unten3.
2. Kriterien für die Priorisierung
Die Priorisierung ist ein kollaborativer Prozess im Team, bei dem die Wichtigkeit der Stories festgelegt wird.
• Wichtigkeitsfaktoren: Die Wichtigkeit der Stories ergibt sich aus einer Kombination von6...:
    ◦ Nutzen (Value)10.
    ◦ Risiko611.
    ◦ Technischem Aufwand (Complexity/Cost)6....
• Ziel: Höchster Kundennutzen: Durch die Priorisierung soll verhindert werden, dass Teams Features auswählen, die am einfachsten oder am interessantesten sind, anstatt das auszuwählen, was den höchsten Kundennutzen liefert10. Die Map zwingt das Team, die Stories nach ihrem Nutzen zu priorisieren1213.
3. Methodische Unterstützung
Um die vertikale Priorisierung fundiert durchzuführen, können verschiedene Frameworks genutzt werden14:
• MoSCoW-Methode: Hier werden Stories in M (Must have), S (Should have), C (Could have) und W (Won’t have) kategorisiert. Die "Must-have"-Stories werden in den Spalten ganz nach oben sortiert und bilden kollektiv den natürlichen MVP-Slice14.
• Value vs. Complexity Quadrant: Stories im Quadranten "Hoher Wert, Geringe Komplexität" (Quick Wins) werden am höchsten priorisiert und oben platziert14.
• Weighted Shortest Job First (WSJF): Stories mit dem höchsten WSJF-Score werden am höchsten priorisiert14.
4. Verbindung zum weiteren Vorgehen (Slicing)
Die vertikale Priorisierung ist die Grundlage für den anschließenden, finalen Schritt des Story Mapping Workshops: das Slicing (Schritt 4: Slice Out Viable Releases1516).
• Vorbereitung für Releases: Erst nachdem die Map vertikal nach Wichtigkeit strukturiert und priorisiert wurde, kann sie horizontal in Release-Slices geschnitten werden1718.
• MVP-Definition: Die Stories, die in den Spalten am weitesten oben platziert sind (die "Must-haves"), bilden die oberste Scheibe1719. Die Stakeholder sollten gemeinsam definieren, welche Stories in das MVP (Minimum Viable Product) gehören6....
Zusammenfassend: Schritt 3 gewährleistet, dass die Map nicht nur die Vollständigkeit der User Journey (horizontal) abbildet, sondern auch die Wichtigkeit (vertikal) jeder einzelnen Story in Bezug auf den Kundennutzen klar visualisiert. Dies transformiert die Story Map von einem Ideen-Katalog in eine priorisierte Planungsgrundlage321.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Durchführung (Schritte)“ über „Schritt 4: Lücken und Abhängigkeiten identifizieren ('Wandern' der Map)“ aussagen.

Der vierte Schritt im Story Mapping Workshop – „Lücken und Abhängigkeiten identifizieren“, oft als das „Wandern“ der Map bezeichnet – wird in den Quellen als der kritischste Schritt des Workshops angesehen, in dem der eigentliche Wert der Methode entsteht1.
Dieser Schritt transformiert die bis dahin erstellte, priorisierte Story Map von einer statischen Anforderungssammlung in ein lebendiges, diskutiertes Planungswerkzeug, das auf Risikominimierung und Kollekivierung von Wissen abzielt1.
1. Das Vorgehen: Narratives „Wandern“ der Map
Um Lücken zu finden, beginnt das Team eine gezielte, kollektive Übung:
• Narrativer Durchlauf: Das Team „wandert“ die Map nun als Gruppe narrativ ab1. Dies erfolgt in strikter chronologischer Reihenfolge von der ersten Aktivität links bis zur letzten rechts12.
• Storytelling als Technik: Durch das „Erzählen“ der Geschichte (der User Journey) entlang der horizontalen Achse wird der Kontext hergestellt13. Man liest die horizontalen Schritte, indem man mental das Wort „dann“ (then) zwischen die Karten einfügt34.
• Gezieltes Hinterfragen: Beim Durchlaufen der Schritte ist es hilfreich, gezielte Fragen aus der Perspektive des Benutzers zu stellen5:
    ◦ Was wird ein Benutzer als Nächstes am wahrscheinlichsten tun wollen?5
    ◦ Welche Fehler könnte ein Benutzer hier machen?5
    ◦ Was könnte den Benutzer an dieser Stelle verwirren?5
    ◦ Welche zusätzlichen Informationen könnte ein Benutzer in diesem Schritt benötigen?5
    ◦ Falls es mehrere Nutzertypen gibt, müssen diese Fragen für jeden Nutzertyp gestellt werden5.
2. Die Ergebnisse: Aufdecken von Lücken und Risiken
Durch diesen narrativen Prozess deckt das Team unweigerlich kritische Planungsfehler und Wissenslücken auf, die in einem flachen Backlog oft übersehen werden16:
• Identifikation von Lücken: Das Team identifiziert Lücken, Engpässe und fehlende Informationen1. Da die horizontale Achse die Vollständigkeit der gesamten User Journey in Frage stellt ("Haben wir an die gesamte Reise gedacht?")2, werden Lücken in der Abfolge der Aktivitäten sofort visuell ersichtlich67.
• Abhängigkeiten: Es werden Abhängigkeiten zwischen den Spalten (also zwischen verschiedenen Benutzeraktivitäten) aufgedeckt1.
• Risiken sichtbar machen: Risikonotizen können in dieser Phase helfen, unsichere Annahmen oder externe Abhängigkeiten sichtbar zu machen und ein rechtzeitiges Gegensteuern zu ermöglichen8....
3. Die Rolle des Entwicklungsteams bei Abhängigkeiten
In diesem Schritt wird die aktive Rolle des funktionsübergreifenden Entwicklungsteams besonders offensichtlich12:
• Technische Stories: Während der Product Owner (PO) und die UX-Designer die benutzer-sichtbaren Stories beitragen, ist es die Aufgabe der Entwickler, auf technische Abhängigkeiten hinzuweisen12.
• Integration technischer Anforderungen: Entwickler fügen „unsichtbare“ technische Stories (wie zum Beispiel „Datenbank-Schema anlegen“ oder „Zahlungs-API integrieren“) an den richtigen Stellen in die Map ein12.
• Vermeidung der Wunschliste: Ohne die Teilnahme des Entwicklungsteams bei dieser Überprüfung wäre die Map eine reine „Wunschliste“ und keine realistische Planungsgrundlage1213.
4. Wertschöpfung: Das gemeinsame Verständnis
Dieser Schritt ist essentiell, weil er direkt das oberste Ziel des Story Mapping erfüllt: die Schaffung von Shared Understanding (gemeinsames Verständnis)114. Der wahre Wert liegt in der „kuratierten Konversation“, die entsteht, wenn das Team darüber diskutiert, warum eine Story wo platziert werden muss1.

--------------------------------------------------------------------------------
Zusammenfassend: Schritt 4 ist der Punkt, an dem die Theorie (die erstellte Karte) auf die Praxis (die Realität der Nutzerreise und der Entwicklung) trifft. Indem das Team die Geschichte gemeinsam erzählt und die Story Map von links nach rechts durchgeht, „testet“ es das Produkt narrativ und füllt die Lücken, bevor das erste Code geschrieben wird.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Story Mapping Workshop (Vorgehen)“ über „Priorisierungsmethoden (Vertikal)“ aussagen.

Die vertikale Priorisierung ist Schritt 3 der Durchführung des Story Mapping Workshops, nachdem das Team alle potenziellen User Stories gesammelt hat (Schritt 2: Brain Dump). Dieser Schritt ist entscheidend, da er die gesammelten Anforderungen in eine klare, umsetzbare Reihenfolge bringt und die Grundlage für die spätere Release-Planung (Slicing) bildet1....
I. Grundprinzip der Vertikalen Priorisierung
Die vertikale Achse der Story Map repräsentiert die Priorität und den Detaillierungsgrad4....
1. Anordnung nach Wichtigkeit: Die gesammelten User Stories werden innerhalb ihrer jeweiligen Spalte (unter dem zugehörigen Backbone-Schritt) priorisiert1. Die wichtigsten Stories, die für die Kernfunktion unverzichtbar sind ("Must-haves"), werden ganz nach oben platziert, direkt unter das Backbone1.... Stories mit geringerer Priorität, alternative Lösungswege oder "Nice-to-have"-Funktionen wandern nach unten14.
2. Priorisierungskriterien: Die Priorität wird nicht willkürlich festgelegt, sondern ergibt sich aus einer gemeinsamen Bewertung des funktionsübergreifenden Teams. Die Wichtigkeit wird anhand einer Kombination aus Nutzen, Risiko und technischem Aufwand bestimmt2....
3. Ziel: Die vertikale Sortierung erzwingt eine "Value-Delivery"-Mentalität9. Sie verhindert, dass Teams das auswählen, was am einfachsten oder am interessantesten ist, anstatt das, was den höchsten Kundennutzen liefert810.
II. Gängige Priorisierungsmethoden im Story Mapping
Um die vertikale Priorisierung methodisch fundiert zu gestalten, wenden Teams verschiedene Frameworks an11:
Methode
Beschreibung
Anwendung im Story Mapping
MoSCoW-Methode11
Kategorisierung aller Stories in: M (Must have), S (Should have), C (Could have), W (Won't have this time)11.
Die "Must-have"-Stories werden in den Spalten ganz nach oben sortiert11. Sie bilden kollektiv den natürlichen MVP-Slice11.
Value vs. Complexity Quadrant11
Ein 2x2-Quadrant zur Einteilung von Stories nach Geschäftswert (Value) und Entwicklungsaufwand (Complexity/Cost)11.
Stories im Quadranten "Hoher Wert, Geringe Komplexität" (Quick Wins) werden am höchsten priorisiert (ganz oben platziert)11. Stories mit "Hohem Wert, Hoher Komplexität" folgen11.
Weighted Shortest Job First (WSJF)11
Eine Methode, die den "Cost of Delay" (Kosten der Verzögerung) durch die "Job Size" (Aufwandsgröße) teilt, um den ökonomischen Wertfluss zu optimieren11.
Die Stories mit dem höchsten WSJF-Score werden in ihren jeweiligen Spalten am höchsten priorisiert11.
III. Übergang zur Release-Planung
Die vertikale Priorisierung ist die direkte Vorbereitung für den letzten Workshop-Schritt, das Slicing (Slice Out Viable Releases).
• Grundlage für Slicing: Erst nachdem die Map vertikal nach Wichtigkeit strukturiert und priorisiert wurde, kann sie horizontal in Release-Slices geschnitten werden1213.
• MVP-Definition: Die Stories, die in den Spalten am weitesten oben stehen, bilden die oberste Scheibe, welche das Minimum Viable Product (MVP) definiert114. Die Stakeholder sollten gemeinsam definieren, welche Stories in dieses MVP gehören2....
• Weiteres Vorgehen: Die Priorisierung legt fest, dass nachfolgende Releases dem initialen "Walking Skeleton" (dem dünnsten, aber funktional vollständigen End-to-End-Weg durch das Produkt1415) mehr "Fleisch" hinzufügen1617, indem sie die Stories mit niedrigerer vertikaler Priorität umsetzen (z.B. PayPal als zweite Zahlungsoption oder „Nice-to-have“-Funktionen)16.
Die Priorisierungsmethoden sind somit die Mechanismen, die sicherstellen, dass die vertikale Anordnung der Stories direkt den maximalen Kundennutzen und die optimale Umsetzungslogik widerspiegelt818.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Priorisierungsmethoden (Vertikal)“ über „MoSCoW (Must-haves bilden natürlichen MVP-Slice)“ aussagen.

Die Quellen diskutieren die MoSCoW-Methode als eines der gängigen Frameworks1, die zur methodisch fundierten vertikalen Priorisierung (Workshop-Schritt 3)1 innerhalb des User Story Mappings (USM) angewendet werden können.
MoSCoW spielt eine entscheidende Rolle bei der Definition des MVP, da es direkt zur Erstellung des natürlichen MVP-Slices führt.
1. Definition und Anwendung der MoSCoW-Methode
Die MoSCoW-Methode dient der Kategorisierung aller gesammelten Stories nach ihrer Dringlichkeit und Wichtigkeit für das Produkt1:
• Kategorien: Stories werden eingeteilt in: M (Must have), S (Should have), C (Could have) und W (Won't have this time)1.
• Anwendung in USM: Bei der vertikalen Priorisierung in der Story Map, werden die "Must-have"-Stories (M) in den Spalten ganz nach oben sortiert12.
• Vertikale Struktur: Die Stories, die für eine minimale Funktionsfähigkeit des jeweiligen Backbone-Schritts unerlässlich sind, werden nach oben geschoben, direkt unter das Backbone2. Die MoSCoW-Klassifizierung hilft dem Team, diese "Must-haves" klar zu identifizieren.
2. Die Must-haves bilden den natürlichen MVP-Slice
Die Hauptaussage der Quellen ist, dass die nach MoSCoW klassifizierten "Must-have"-Stories kollektiv den natürlichen MVP-Slice bilden1.
• Grundlage für das Slicing: Die vertikale Priorisierung in Schritt 3 ist die Grundlage für den anschließenden finalen Schritt der Release-Planung, das Slicing3.
• Definition des MVP: Die MoSCoW-Must-haves stellen die oberste Scheibe der Map dar4..., die das Minimum Viable Product (MVP) definiert5....
• Walking Skeleton: Das so definierte MVP ist nicht bloß eine Liste der wichtigsten Features59, sondern muss der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt sein, der sogenannte "Walking Skeleton"5.... Um dies zu gewährleisten, muss der MVP-Slice mindestens eine Story aus jedem kritischen Backbone-Schritt enthalten5....
Die Verwendung von MoSCoW stellt somit sicher, dass die oberste Schicht der Map genau jene Stories enthält, die notwendig sind, damit der Nutzer sein vollständiges Produktziel mit der kleinstmöglichen Menge an Aufgaben erreichen kann5.... Die nachfolgenden Slices (z.B. S und C) repräsentieren dann nachfolgende Releases, die dem "Walking Skeleton" mehr "Fleisch" hinzufügen3.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Priorisierungsmethoden (Vertikal)“ über „Value vs. Complexity Quadrant (Quick Wins am höchsten)“ aussagen.

Der Value vs. Complexity Quadrant ist eine spezifische Methode zur vertikalen Priorisierung von User Stories (Workshop-Schritt 3)12, die darauf abzielt, den höchsten Kundennutzen bei minimalem Aufwand zu identifizieren und die Stories entsprechend auf der Story Map anzuordnen3.
Die Quellen beschreiben die Anwendung dieser Priorisierungsmethode im Kontext des Story Mapping wie folgt:
1. Definition und Kriterien des Quadranten
Der Value vs. Complexity Quadrant ist ein 2x2-Quadrant2, der in der Praxis angewendet wird, um die vertikale Priorisierung methodisch zu fundieren2.
• Kriterien: Der Quadrant teilt die gesammelten Stories nach zwei Hauptfaktoren ein: dem Geschäftswert (Value) und dem Entwicklungsaufwand (Complexity/Cost)2.
• Priorisierungsbasis: Die allgemeine Wichtigkeit der Stories ergibt sich im Story Mapping immer aus einer Kombination von Nutzen, Risiko und technischem Aufwand1.... Der Quadrant visualisiert die Abwägung von Nutzen und Aufwand.
2. Priorisierung der "Quick Wins"
Die Anwendung des Quadranten dient dazu, die Stories innerhalb ihrer jeweiligen vertikalen Spalte zu sortieren, wobei die wichtigsten Stories ganz oben platziert werden18.
• Höchste Priorität: Stories, die dem Quadranten "Hoher Wert, Geringe Komplexität" zugeordnet werden, werden als "Quick Wins" identifiziert2.
• Platzierung auf der Map: Diese Quick Wins werden im Story Mapping am höchsten priorisiert2 und folglich ganz oben platziert in der vertikalen Achse2.
• Folgepriorisierung: Stories mit "Hohem Wert, Hoher Komplexität" folgen in der Prioritätenreihenfolge danach2.
3. Zielsetzung im Story Mapping
Die vertikale Sortierung mithilfe dieses Quadranten unterstützt die "Value-Delivery"-Mentalität der Story Map39:
• Nutzenfokus: Die Map zwingt das Team, Stories nach ihrem Nutzen zu priorisieren3.
• Vermeidung von Fehlpriorisierung: Durch diese strukturierte Priorisierung soll verhindert werden, dass Teams Features auswählen, die am einfachsten oder am interessantesten sind, anstatt das auszuwählen, was den höchsten Kundennutzen liefert310.
• MVP-Vorbereitung: Stories, die als "Quick Wins" identifiziert werden, gehören zu jenen "Must-haves", die für eine minimale Funktionsfähigkeit unerlässlich sind1..., und bilden so die natürliche oberste Scheibe (den MVP-Slice