Die Aktivierung eines MEMA_ Markers (Meta-Analysis Marker) erfolgt auf der Ebene 4, der höchsten und abstraktesten Stufe der LeanDeep 4.0 Marker-Analyse-Architektur1....
Die Aktivierungslogik folgt strikt dem Bottom-up-Prinzip der Vier-Ebenen-Kaskade (ATO → SEM → CLU → MEMA), bei dem höhere Ebenen nur evaluiert werden, wenn die darunter liegenden Marker feuern34.
1. Die Zwingende Kompositionsregel
Der Kernmechanismus zur Aktivierung eines MEMA-Markers ist die Kombination von Clustern (Ebene 3):
• Zwingende Zusammensetzung: MEMA_ Marker werden typischerweise durch die Kombination (composed_of) von mindestens zwei unterschiedlichen Cluster Markern (CLU_*) aktiviert1....
• Funktion: Diese Komposition ist notwendig, da MEMAs die Aufgabe haben, systemische Trends und übergeordnete Dynamiken zu bewerten, indem sie die Wechselwirkungen zwischen den erkannten CLUs analysieren1.... Die MEMAs analysieren dynamische Trends über CLUs hinweg8.
• Aktivierungslogik: Die Aktivierung erfordert oft die Angabe der Logik, beispielsweise als composed_of [CLU_*] + Regelaggregat Option A7....
2. Beispiele für die MEMA-Aktivierung
MEMA-Marker benötigen das Zusammenspiel verschiedener Muster, die in der darunter liegenden CLU-Ebene bereits als stabil erkannt wurden:
• MEMA_RELATIONSHIP_STRAIN: Dieser Marker wird durch das Zusammenspiel von CLU_CONFLICT_CYCLE und CLU_REPAIR ausgelöst6.... Dies signalisiert eine übergeordnete Beziehungsdynamik, die durch Spannung gefolgt von Lösungsversuchen gekennzeichnet ist613.
• MEMA_INCONSISTENCY_TREND: Dieser Marker kann auf verschiedene Weisen aktiviert werden, z. B.:
    ◦ Durch die Ko-Aktivierung von CLU_INTUITION_UNCERTAINTY und dem Richtungsmarker TEND_UNCLARITY_TO_CLARITY14.
    ◦ Durch die Komposition von CLU_SUPPORT_AFFECTION_RUN und CLU_INTUITION_UNCERTAINTY, was ein Muster aus hoher Wärme/Alltagskooperation bei gleichzeitiger wachsender Unvereinbarkeit bei Zukunftssetups erkennt15.
    ◦ Durch CLU_DECISION_DYNAMICS und CLU_INTUITION_COMMITMENT, was eine Stabilisierung durch Regeln bei gleichzeitiger Rest-Unsicherheit signalisiert9.
3. Ergebnis der Aktivierung
Die erfolgreiche Aktivierung eines MEMA-Markers führt zur Bereitstellung der finalen Diagnose und Risikobewertung:
• Quantifizierung: Die Aktivierung resultiert im Akuten Risk Score (ARS), dem quantitativen Output, der auf einer logistischen Skala von 0 bis 5 kommuniziert wird (z. B. 2.8 / 5.0 für ein signifikantes Risiko)1....
• Kontextualisierung (Manifestation): Abschließend wird die systemische Bedeutung durch Anwendung des Resonance Framework 2.0 (RF 2.0) kontextualisiert1.... Hierbei wird die Manifestationsformel angewendet: [STUFE] × [MARKER-TYP] × [ZEIT-BEZUG] × [INTENSITÄT] = MANIFESTATION1....