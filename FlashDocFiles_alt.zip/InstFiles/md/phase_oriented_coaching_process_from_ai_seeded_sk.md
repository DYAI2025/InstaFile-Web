Phase‑oriented coaching process: from AI‑seeded skills to full human ownership
Evidence: why AI should augment, not replace, human coaching
AI is capable but cannot replace human empathy and judgement. Research by The Conference Board in 2025 found that AI can perform up to 90 % of routine day‑to‑day coaching tasks, providing structure, goal orientation, encouragement of critical thinking and role‑play simulations
prnewswire.com
. However, the same report stresses that human expertise remains critical for emotionally charged or values‑based discussions and that AI can amplify, but not replace, human coaches
prnewswire.com
. This means AI should be used as a tool to automate administrative work, provide analysis and bridge gaps between sessions while keeping human coaches in the loop
prnewswire.com
.

Hybrid models improve coaching effectiveness. An analysis of 2025 coaching trends shows that AI‑powered tools are used to deliver personalised, on‑demand coaching while human coaches remain central for deeper conversations
groowise.com
. People prefer a blended approach—AI for routine guidance and humans for complex or emotional topics; 51 % of employees favoured a mix of AI and human coaching
groowise.com
. AI therefore serves as a “co‑pilot,” offering data‑driven insights and micro‑coaching while humans provide empathy and cultural nuance
groowise.com
.

Creativity and ideation require human curiosity and judgement. Divergent thinking is an ideation mode where designers generate as many ideas as possible without judgement to widen the solution space
interaction-design.org
. Outside‑the‑box thinking encourages teams to discard conventional methods, challenge assumptions and seek alternatives
interaction-design.org
. A design thinking guide emphasises keeping all ideas produced during brainstorming, as even surreal suggestions may lead to innovation if not discarded too early
adchitects.co
.

Backlog refinement and value‑based prioritisation keep teams focused on value. In Agile practice, backlog refinement means reviewing, ranking and editing the product backlog so that only features that customers want and the business needs are built
atlassian.com
. Best practice involves adjusting descriptions, splitting or combining issues, estimating tasks and ranking them clearly so the team knows the highest‑priority work
atlassian.com
. Value‑based prioritisation emphasises selecting work based on its value to the customer and business, which helps team members adjust to changing priorities
atlassian.com
.

Phase‑oriented coaching sequence for AI‑seeded product work
The coaching process below assumes a short development cycle (approximately one week) and builds on the user’s desired “Tag 0–7” schedule. Each phase outlines the coach’s responsibilities and shows how AI can assist without taking over.

Phase (day)	Key activities & coach responsibilities	How AI assists (without replacing people)
1. Goal setting & definitions (Day 0)	The coach helps the team choose a clear goal, write a Definition of Done (DoD) and define key performance indicators (KPIs). They ensure that objectives are transparent, measurable and aligned with user and business value. The coach emphasises psychological safety and encourages the team to take ownership of the goal.	AI can summarise historical data or market research to inform realistic KPIs and suggest potential acceptance criteria. It might draft DoD templates, but the team finalises them and owns the definitions.
2. Divergent ideation & initial implementation (Day 1–2)	The team conducts a divergent ideation session. The coach establishes a judgement‑free environment so participants generate many ideas and challenge assumptions. They remind the team not to discard ideas too early
adchitects.co
 and encourage outside‑the‑box thinking
interaction-design.org
. The team selects an initial feature (F1) to implement. The coach reinforces clarity and ensures the team decides which idea to pursue.	AI can act as a brainstorming partner, suggesting alternative solutions or variations, providing access to relevant user research, or generating mock‑ups. However, humans decide which ideas to adopt and hold authority over design choices.
3. Test & feedback (Day 3)	The coach organises quick user testing of the F1 feature with at least two users. They collect feedback, encourage candid critique and note patterns. The coach guides the team to interpret feedback and challenge their assumptions.	AI can summarise feedback, identify common themes and highlight potential usability issues but does not decide on changes. It may prompt the coach with probing questions to stimulate reflection.
4. Backlog refinement & second implementation (Day 4–5)	Based on feedback, the coach guides the team to refine the product backlog: review, rank and edit items
atlassian.com
. They ensure tasks are broken into understandable components and that only the highest‑priority items enter the next iteration. The coach reminds the team of value‑based prioritisation
atlassian.com
. They help select a second feature (F2) and emphasise that only blockers should be fixed during this period.	AI can analyse backlog items, highlight dependencies, estimate effort or detect duplicates. It can propose prioritisation scores using past data, but humans make final decisions and maintain the value‑driven ordering.
5. Acceptance tests & quality checks (Day 6)	The coach ensures that acceptance criteria derived from the DoD are met. They check that tests cover customer‑relevant scenarios and confirm that the product is reliable and ready for release. Authenticity—ensuring the product truly solves user problems—is a priority.	AI can generate test cases, run automated checks and surface defects, but the coach and team decide whether quality is sufficient and whether to proceed to release.
6. Release & evaluation (Day 7)	The coach facilitates a transparent release (“make ship”), ensures the link to the product is shared with stakeholders and monitors initial KPI results. They host a brief retrospective, reinforcing accountability and continuous improvement.	AI can monitor KPIs in real time, generate analytics dashboards and compare outcomes to benchmarks. It might suggest next‑steps based on metrics, but humans interpret results, celebrate wins and define future improvements.

Coach’s overarching responsibilities
Reinforce structure and clarity: The coach maintains a clear cadence and ensures ceremonies (ideation, refinement, testing, release) occur as scheduled. They help the team articulate goals, break work into manageable pieces and prioritise based on value
atlassian.com
atlassian.com
.

Foster reliability and authenticity: By insisting on acceptance tests and real user feedback, the coach ensures that the product meets both customer needs and business objectives. They encourage honest communication and create space for challenging ideas
interaction-design.org
.

Promote human ownership: Throughout the process, the coach gradually reduces their intervention as the team becomes more confident. AI is framed as a supportive tool (providing data, suggestions and automation) rather than a decision‑maker. This aligns with research showing AI is most effective when it complements human empathy and judgement
groowise.com
.

Comparable phase‑based models
Several established frameworks offer parallels to the above coaching sequence and illustrate the value of phased progress:

Lewin’s Change Management Model – Unfreeze, Change, Refreeze. Lewin breaks change into three phases: prepare people by “unfreezing” current practices, implement the change, then “refreeze” to solidify the new status quo
whatfix.com
. The unfreeze phase is analogous to goal‑setting and creating urgency; the change phase mirrors ideation and implementation; refreeze corresponds to release and reinforcement.

Kotter’s 8‑Step Change Model. Kotter’s theory outlines eight sequential steps: create a sense of urgency, build a change team, form a strategic vision, communicate the vision, remove barriers, focus on short‑term wins, maintain momentum and institute change
whatfix.com
. This model emphasises early alignment, visible wins and sustaining progress—principles echoed in the Tag‑0–7 coaching cycle.

ADKAR Model – Awareness, Desire, Knowledge, Ability, Reinforcement. This framework focuses on the individual’s journey through change: building awareness and desire for change, giving knowledge and ability to implement it, and reinforcing the new behaviour
whatfix.com
. The coaching sequence similarly builds awareness (goal setting), desire (ideation), knowledge/ability (implementation and refinement) and reinforcement (release and KPI measurement).

PDCA (Plan‑Do‑Check‑Act) Cycle. The Deming cycle divides continuous improvement into planning, doing, checking and acting
whatfix.com
. Each iteration of the coaching process follows a similar loop: plan (goal setting and ideation), do (implementation), check (testing and refinement), act (release and adjustments), with learning feeding into the next cycle.

AI Adoption Change Curve. A change‑curve guide for AI adoption maps the emotional journey through stages of shock and denial, anger, bargaining, depression, acceptance, experimentation, decision and integration
cyferd.com
. Leaders are advised to communicate transparently, acknowledge concerns, allow safe experimentation and gradually move to full integration
cyferd.com
. This mirrors the coaching approach: start with clear goals, provide safe spaces to explore AI‑assisted ideas, gather feedback, refine processes and fully integrate successful practices.

Conclusion
Faktisch korrekt sage ich: Evidence from research and agile practice shows that AI can automate much of the coaching workflow and provide useful insights, but human involvement remains essential for empathy, ethical judgement and value‑driven decision‑making
prnewswire.com
groowise.com
.
Logisch scheint mir, dass a phase‑oriented coaching process—beginning with clear goal definition and progressing through ideation, testing, refinement, acceptance and release—offers a structured path for teams to internalise skills initially seeded by AI, leading to full human ownership.
Rein subjektiv, aus meinem Denken ergibt sich, dass adopting similar phase‑based models (Lewin, Kotter, ADKAR or PDCA) can provide further guidance on managing change and ensuring that AI integration enhances rather than undermines human creativity and accountability.