Definition und Anatomie der User Story Map
User Story Mapping ist eine visuelle Technik und agile Methode, die darauf abzielt, die Produktarbeit zu organisieren und zu priorisieren1. Die Technik wurde maßgeblich durch Jeff Patton bekannt2....
1. Abgrenzung zum flachen Backlog
Die USM transformiert ein traditionelles, eindimensionales, flaches Product Backlog1..., das oft als "ein Sack voller kontextfreiem Mulch" empfunden wird27, in eine zweidimensionale Matrix3... oder eine dreidimensionale, kontextreiche "Landkarte"1....
Ein flaches Backlog ist im Wesentlichen eine "To-Do-Liste"2..., die es unmöglich macht, den "Kontext" oder das "große Ganze" (the big picture) zu sehen, sobald das Produkt skaliert2.... Die Story Map hingegen ist eine visuelle Übung, die hilft, die Arbeit zu definieren, die das ansprechendste Benutzererlebnis schafft11.
2. Die zweidimensionale Struktur
Die Struktur der Story Map basiert auf zwei Achsen, die zwei fundamentale Produktmanagement-Fragen voneinander trennen15:
1. Die Horizontale Achse (Das Backbone/Rückgrat):
    ◦ Sie dient als "narrative Klammer" des Produkts16 und bildet die chronologische Abfolge der Benutzeraktivitäten8....
    ◦ Das "Backbone" besteht aus den grobgraularen Epics oder "großen Schritten", die ein Benutzer durchführt, um sein übergeordnetes Ziel mit dem Produkt zu erreichen8....
    ◦ Die horizontale Frage lautet: "Haben wir an die gesamte Reise gedacht?"1523.
2. Die Vertikale Achse (Priorität und Detaillierung):
    ◦ Sie wird unterhalb jedes Schritts im Backbone aufgebaut und repräsentiert den Detaillierungsgrad und die Priorität15....
    ◦ Hier werden die detaillierten Teilschritte, also die eigentlichen User Stories und Aufgaben, gesammelt15....
    ◦ Die wichtigsten, für die Kernfunktion unverzichtbaren Stories (Must-haves) werden ganz oben platziert, während Stories mit geringerer Priorität oder Alternativen nach unten folgen15....
    ◦ Die vertikale Frage lautet: "Was ist der wichtigste Teil jedes Schritts?"15.
3. Fokus und Abgrenzung
Das Story Mapping fokussiert sich auf die Funktionalität des Produkts und die Schritte, die Nutzer durchlaufen9.... Im Gegensatz dazu fokussiert sich die User Journey Map (UJM) auf die Emotionen, Schmerzpunkte und das Erlebnis des Benutzers8.... Idealerweise dient die UJM als Input, um die Probleme zu diagnostizieren, für die das USM die Lösung plant27.

--------------------------------------------------------------------------------
II. Nutzen und Vorteile (Der Wert der Methode)
Der Nutzen von User Story Mapping liegt nicht primär im fertigen Artefakt, sondern im kollaborativen Prozess seiner Erstellung3132.
1. Schaffung eines gemeinsamen Verständnisses (Shared Understanding)
Das ultimative Ziel des Mapping-Prozesses ist die Konversation und das gemeinsame Verständnis im Team7.... Die Erstellung der Map ist eine "kuratierte Konversation"31..., die darauf abzielt, das Wissen aller Beteiligten zu kollektivieren31. Die USM muss Business (Warum?), UX (Für wen?) und Entwicklung (Wie?) an einen Tisch bringen38....
2. Nutzerzentrierung und Wertlieferung
Die Methode ist fundamental benutzerzentriert7.... Eine Story Map beantwortet die Kernfragen: "Warum bauen wir das?", "Für wen?" und "Welchen Nutzen liefert es?"6....
Der kognitive Wandel, den die USM erzwingt, führt von einer "Feature-Fabrik"-Mentalität zu einer "Value-Delivery"-Mentalität11. Die zentrale Frage verschiebt sich von "Was bauen wir als Nächstes?" zu "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"11.
3. Planung von Releases und MVP-Definition
Die Story Map ist ein essenzielles Werkzeug, um MVPs zu definieren und Releases zu planen3....
• Slicing: Die vertikal priorisierte Map wird horizontal "geschnitten" (Slicing)22..., wobei jede Scheibe ein geplantes Release repräsentiert47.
• Walking Skeleton: Der erste und wichtigste Schnitt definiert das MVP4749. Ein durch USM definiertes MVP ist nicht nur eine Liste der wichtigsten Features, sondern der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt50. Dieses Ergebnis wird als "Walking Skeleton" (laufendes Skelett) bezeichnet37.... Das Ziel ist ein Complete Product Experience (CPE), das minimale Versionen aller notwendigen Schritte der User Journey enthält50.
4. Risikominimierung und Kontinuität
• Lückenidentifikation: Das zweidimensionale Layout hilft Teams, Lücken und fehlende Funktionalitäten visuell und intuitiv zu erkennen7.... Indem das Team die gesamte Reise narrativ abschreitet, werden Lücken, Engpässe und Abhängigkeiten aufgedeckt, die in einem flachen Backlog oft übersehen werden23....
• Risikomanagement: Die Story Map ist ein Mechanismus zur Risikominimierung33. Risikonotizen können genutzt werden, um unsichere Annahmen oder externe Abhängigkeiten sichtbar zu machen36....
• Lebendiges Dokument: Die Map sollte nicht nach dem initialen Workshop weggeworfen werden ("Wegwerf-Map" ist ein häufiger Fehler59), sondern als "lebendiges, atmendes Ding"60 gepflegt werden36.... Sie dient als zentrale visuelle Produkt-Roadmap61 und wird als Frontend für das kontinuierliche Backlog Grooming genutzt38....
Zusammenfassend kann man sagen, dass das User Story Mapping wie eine architektonische Blaupause für ein Haus wirkt: Es liefert nicht nur eine Liste aller benötigten Baumaterialien (die Stories), sondern auch einen Grundriss (das Backbone), der zeigt, wie man von der Haustür zur Küche gelangt, und gleichzeitig die Möglichkeit bietet, klar zu definieren, welche minimalen Räume (das MVP) fertiggestellt werden müssen, bevor das Haus nutzbar ist, während der Rest der Innenausstattung für spätere Bauphasen (Releases) priorisiert wird.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Definition & Nutzen“ über „Kernkonzept“ aussagen.

Die Quellen definieren das Kernkonzept des User Story Mapping (USM) als eine leistungsstarke, zweidimensionale, visuelle Methode zur Organisation von Produktarbeit im agilen Projektmanagement und beschreiben deren Nutzen hauptsächlich in der Schaffung von Kontext, der Nutzerzentrierung und der Planung funktional vollständiger Releases1....
Das Kernkonzept von User Story Mapping unterscheidet sich fundamental vom traditionellen, flachen Produkt-Backlog, das oft als "Sack voller kontextfreiem Mulch" beschrieben wird27.

--------------------------------------------------------------------------------
Definition des Kernkonzepts: Die zweidimensionale Struktur
Das Kernkonzept der User Story Map liegt in ihrer zweidimensionalen Matrixstruktur2..., die ein eindimensionales Backlog in eine kontextreiche „Landkarte“ umwandelt1.... Diese Struktur basiert auf zwei Achsen, die zwei fundamentale Produktmanagement-Fragen trennen11:
1. Die horizontale Achse: Das Backbone (Vollständigkeit)
• Definition: Die horizontale Achse bildet das „Backbone“ (Rückgrat) des Produkts12.... Sie fungiert als die narrative Klammer12 und zeigt die wichtigsten Aktivitäten oder Themen des Nutzers in chronologischer Reihenfolge von links nach rechts12....
• Bestandteile: Das Backbone besteht aus grobgranularen Epics oder Benutzeraktivitäten (User Activities), die in ihrer Gesamtheit eine vereinfachte, aber vollständige Darstellung der User Journey bilden12....
• Nutzen (Die horizontale Frage): Durch die chronologische Anordnung ermöglicht die Map die Prüfung auf Vollständigkeit11. Die Story Map zwingt das Team, zuerst die gesamte Reise horizontal abzubilden24. Dies macht Lücken (gaps) und fehlende Funktionalitäten sofort visuell ersichtlich2....
2. Die vertikale Achse: Priorität und Detaillierung (Wichtigkeit)
• Definition: Die vertikale Achse unterhalb jedes Backbone-Schritts enthält die detaillierten Teilschritte, also die eigentlichen User Stories und Aufgaben11....
• Struktur: Diese Anordnung repräsentiert den Prioritäts- und Detaillierungsgrad11.... Die wichtigsten, für die Kernfunktion unverzichtbaren Stories (Must-haves) werden direkt unter dem Backbone-Schritt platziert (ganz oben in der Spalte)11.... Alternativen, „Nice-to-have“-Funktionen oder Stories mit geringerer Priorität folgen darunter1118.
• Leserichtung: Beim Lesen nach unten wird das Wort „oder“ (or) mental eingefügt, da die vertikale Dimension Alternativen oder verschiedene Wege zur Erfüllung eines Ziels aufzeigt18.
• Nutzen (Die vertikale Frage): Hierdurch wird die Wichtigkeit jedes Schritts geklärt11. Im Gegensatz zu einem flachen Backlog, wo Stories unterschiedlicher Wichtigkeit direkt konkurrieren, wird bei der Map erst horizontal die Reise abgebildet und dann vertikal priorisiert24.

--------------------------------------------------------------------------------
Nutzen: Der Wandel von der Liste zur Landkarte
Der Nutzen der Story Map liegt nicht nur in der besseren Visualisierung, sondern in einem Paradigmenwechsel in der Produktentwicklung2.
1. Fokus auf Nutzerzentrierung und Wertlieferung
• Die Story Map beantwortet die grundlegenden Fragen: „Warum bauen wir das?“, „Für wen?“ und „Welchen Nutzen liefert es?“6....
• Der Fokus verschiebt sich von der Verwaltung von Arbeit (Work Planning) zur Erzeugung eines geteilten Verständnisses (Shared Understanding)2.
• Ein flaches Backlog fördert eine „Feature-Fabrik“-Mentalität28. Die Story Map erzwingt hingegen eine „Value-Delivery“-Mentalität28. Die zentrale Frage lautet nicht mehr „Was bauen wir als Nächstes?“, sondern „Welches Problem des Nutzers lösen wir als Nächstes vollständig?“28.
• Die Map wird stets aus der Perspektive des Benutzers (Persona) erstellt, um die Arbeit fest im Kontext der gesamten Customer Journey zu verankern28....
2. Ermöglichung der Release-Planung (Slicing und MVP)
• Die Story Map ist das zentrale Werkzeug für die Release-Planung durch das sogenannte „Slicing“ (Zerschneiden)2....
• Das MVP wird durch einen horizontalen „Slice“ definiert, der nicht nur die wichtigsten Features auflistet, sondern den dünnsten, aber funktional vollständigen End-to-End-Weg durch das Produkt darstellt3236.
• Dieses Ergebnis wird als „Walking Skeleton“ (laufendes Skelett) bezeichnet – eine minimale, aber durchgängig funktionsfähige Version des gesamten Systems, die mindestens eine Story aus jedem kritischen Backbone-Schritt enthalten muss34.... Nachfolgende Releases („Slices“) fügen diesem Skelett mehr „Fleisch“ hinzu42.
3. Kollaboration und Gemeinsames Verständnis
• Der wahre Wert der Methode liegt im kollaborativen Prozess ihrer Erstellung – dem Story Mapping Workshop29. Dieser Workshop ist eine „kuratierte Konversation“29..., die das Wissen aller Beteiligten (Business, UX, Entwicklung) kollektiviert29....
• Das gemeinsame Abwandern der Map entlang der narrativen Achse hilft dem Team, Lücken und Abhängigkeiten aufzudecken, die sonst übersehen würden4345. In diesem Moment wird das „Shared Understanding“ geschaffen4346.

--------------------------------------------------------------------------------
Zusammenfassend kann man sagen, dass das Kernkonzept des Story Mapping wie ein GPS für die Produktentwicklung ist: Es verwandelt eine unübersichtliche Liste von Straßennamen (flaches Backlog) in eine klare Landkarte (Story Map) mit einer Route (Backbone), die nicht nur den Zielort definiert, sondern auch die notwendigen Etappen (horizontale Achse) und die Priorität der Straßenqualität (vertikale Achse), um sicherzustellen, dass man das Ziel auf dem minimal funktionsfähigen Weg erreicht (MVP-Slice).

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Kernkonzept“ über „Visuelle Technik zur Produktorganisation“ aussagen.

Die Quellen beschreiben die User Story Map (USM) als die zentrale Visuelle Technik zur Produktorganisation1 und beleuchten deren Kernkonzept im Vergleich zu traditionellen Ansätzen1....
Das Kernkonzept der User Story Map lässt sich primär als ein Paradigmenwechsel von einer eindimensionalen Liste zu einer zweidimensionalen, kontextreichen Landkarte zusammenfassen1....
1. Der Wandel vom flachen Backlog zur kontextreichen Landkarte
Das Kernproblem, das durch diese visuelle Technik gelöst wird, ist die Kontextfreiheit traditioneller, flacher Product Backlogs2.... Ein flaches Backlog, oft als "To-Do-Liste" oder "Sack voller kontextfreiem Mulch" beschrieben, wird bei skalierenden Produkten überwältigend und verhindert, dass Teams das "große Ganze" (The Big Picture) sehen können2....
Die Story Map hingegen ist eine zweidimensionale Matrix5... und wandelt die flache Liste in eine dreidimensionale Ansicht um, die jede einzelne User Story fest im Kontext der gesamten Customer Journey verankert4....
Dieser Wandel ist nicht nur administrativ, sondern vor allem kognitiv17. Das Kernkonzept erzwingt einen Fokuswechsel2...:
• Vom Feature zur Wertlieferung: Ein flaches Backlog fördert eine "Feature-Fabrik"-Mentalität17. Die Story Map erzwingt stattdessen eine "Value-Delivery"-Mentalität17.
• Die zentrale Frage verschiebt sich von "Was bauen wir als Nächstes?" zu "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"17. Das Ziel der Map ist in erster Linie die Schaffung eines geteilten Verständnisses (Shared Understanding) im Team5....
2. Die Anatomie als Kern des visuellen Konzepts
Das Kernkonzept der visuellen Organisation basiert auf der Trennung von zwei fundamentalen Produktmanagement-Fragen durch die zwei Achsen25:
A. Die horizontale Achse: Die Vollständigkeitsfrage
Die horizontale Achse bildet das "Backbone" (Rückgrat) des Produkts26.... Dies ist die narrative Klammer des Produkts2633 und stellt die chronologische Reihenfolge der "großen Schritte" oder Benutzeraktivitäten (User Activities) dar, die ein Benutzer durchführt, um sein Ziel zu erreichen26....
• Der Fokus liegt auf der User Journey: Das Backbone liefert eine vereinfachte, aber vollständige Darstellung der User Journey26.
• Die horizontale Frage lautet: "Haben wir an die gesamte Reise gedacht?"25.
• Die Stories in dieser Achse sind typischerweise grobgranulare Epics oder Themen26....
B. Die vertikale Achse: Die Wichtigkeits- und Detaillierungsfrage
Unterhalb jedes Schritts im Backbone wird die vertikale Achse aufgebaut25. Diese Achse repräsentiert den Detaillierungsgrad und die Priorität25....
• Priorisierung: Die wichtigsten Stories, die für die Kernfunktion unverzichtbar sind ("Must-haves"), werden ganz oben platziert25.... Stories mit geringerer Priorität, Alternativen oder "Nice-to-have"-Funktionen folgen darunter25....
• Alternativen: Die vertikale Anordnung zeigt auch alternative Lösungswege oder Möglichkeiten auf2535. Man liest diese Achse, indem man mental das Wort "oder" zwischen den Karten einfügt35.
• Die vertikale Frage lautet: "Was ist der wichtigste Teil jedes Schritts?"25.
3. Der organisatorische Nutzen (Slicing und Lückenidentifikation)
Der größte Vorteil der visuellen Technik zur Produktorganisation liegt darin, dass sie die Simultanplanung der gesamten Reise (horizontal) und die Priorisierung jedes einzelnen Schritts (vertikal) ermöglicht25.
1. Lückenidentifikation: Die zweidimensionale Ansicht macht Lücken (gaps) und fehlende Funktionalitäten sofort visuell ersichtlich5.... Dies geschieht oft, indem das Team die Story Map narrativ von links nach rechts "abwandert" und dabei Engpässe und fehlende Schritte aufdeckt20.
2. Release-Planung (Slicing): Die fertige, vertikal priorisierte Map wird durch das "Slicing" (horizontales Schneiden) in Releases oder Iterationen unterteilt5....
3. Definition des MVP: Das Kernkonzept des Slicing definiert das Minimum Viable Product (MVP) neu43. Das MVP ist nicht nur eine Liste der wichtigsten Features, sondern der dünnste, aber funktional vollständige End-to-End-Weg durch das gesamte Produkt22.... Dieses Ergebnis wird oft als "Walking Skeleton" (laufendes Skelett) bezeichnet – eine minimale, aber durchgängig funktionsfähige Version des Systems22....
Zusammenfassend ist das Kernkonzept der visuellen Technik (USM) zur Produktorganisation, das flache Backlog durch eine Landkarte zu ersetzen, die den Kontext der Nutzerreise (horizontal) mit der Priorität und Detaillierung der Arbeitspakete (vertikal) verknüpft, um ein geteiltes Verständnis zu schaffen und eine nutzerzentrierte, vollständige minimale Produktversion (MVP) zu definieren1....

--------------------------------------------------------------------------------
Man könnte die User Story Map metaphorisch als eine Bergsteigerkarte betrachten, während das flache Backlog eine lange Einkaufsliste ist. Die Einkaufsliste mag die Zutaten (die Stories) auflisten und priorisieren (das Wichtigste zuerst), aber sie verrät nichts darüber, warum man sie braucht oder in welcher Reihenfolge man sie verwenden muss, um eine vollständige Mahlzeit zuzubereiten45. Die Bergsteigerkarte (Story Map) hingegen zeigt den gesamten Weg (Backbone) von der Basis bis zum Gipfel chronologisch auf. Sie zeigt, welche Ausrüstung (Stories) an welchem Abschnitt (vertikale Priorität) notwendig ist. Durch horizontales "Slicing" kann man entscheiden, ob man in der ersten Expedition nur das Basislager (MVP/Walking Skeleton) oder den kompletten Gipfel erreicht.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Kernkonzept“ über „Wandelt flaches Backlog in 2D/3D 'Landkarte'“ aussagen.

Die Transformation des flachen Backlogs in eine zwei- oder dreidimensionale „Landkarte“ ist das Kernkonzept der User Story Mapping (USM) Methode12. Diese Transformation zielt darauf ab, die fundamentalen Mängel traditioneller Backlogs zu beheben, indem sie Kontext, Übersicht und Benutzerzentrierung herstellt1....
Hier ist eine detaillierte Diskussion, was die Quellen über diesen Kernwandel aussagen:
1. Das Problem des flachen Backlogs
Das Story Mapping wurde entwickelt, weil einfache (flache) Backlogs den Gesamtzusammenhang (the big picture) nicht sichtbar machen3....
• Eindimensionale Liste: Das traditionelle Product Backlog wird als eine eindimensionale, flache Liste1... oder im Wesentlichen als eine "To-Do-Liste" beschrieben37.
• Mangelnder Kontext: Das fundamentale Problem liegt in dieser Struktur1. Sobald ein Produkt skaliert und Hunderte von Einträgen umfasst, wird das Backlog überwältigend3. Es liefert keine Übersicht über Zusammenhänge und zeigt weder die Reihenfolge, in der Nutzer durch das Produkt navigieren, noch den Kontext der einzelnen Aufgaben3....
• Der "Sack voller Mulch": Jeff Patton, eine Schlüsselfigur der Methode, beschreibt ein solches Backlog treffend als "einen Sack voller kontextfreiem Mulch"3....
• Priorisierungsproblem: Das flache Backlog kann die Fragen der Vollständigkeit und Wichtigkeit nicht trennen14. Dort konkurriert beispielsweise eine wichtige Story für den Bezahlvorgang direkt mit einer weniger wichtigen Story für die Passwort-Wiederherstellung15.
2. Die Transformation zur 2D/3D-Landkarte
Die User Story Map setzt genau hier an, indem sie eine visuelle Technik nutzt, um diese flache Liste in eine räumliche Darstellung zu überführen1....
• Der visuelle Wandel: Im Kern verwandelt die USM das Backlog von einer eindimensionalen, flachen Liste in eine zweidimensionale, kontextreiche "Landkarte"17. Diese Darstellung wird auch als zweidimensionale Matrix (horizontal & vertikal)7 oder sogar als dreidimensionale Ansicht beschrieben2. Die Methode kombiniert die Klarheit einer Liste mit dem Kontext eines visuellen "Boards"4....
• Kontextreich: Diese Darstellung verankert jede einzelne User Story fest im Kontext der gesamten Customer Journey27. Die Map fungiert als visuelles Frontend für das gesamte Product Backlog17.
3. Die Struktur der Landkarte: Zwei Dimensionen
Die Quellen erklären detailliert, wie die zwei Achsen der Story Map den Kontext liefern7....
A. Die horizontale Achse: Der narrative Fluss (Sequenz)
Die horizontale Achse bildet das "Backbone" (Rückgrat) des Produkts7.... Sie ist die narrative Klammer und wird von links nach rechts in chronologischer Reihenfolge angeordnet7....
• Inhalt: Das Backbone besteht aus den grobgranularen "großen Schritten", "Benutzeraktivitäten" (User Activities) oder "Themen"11..., die der Benutzer durchführt, um sein übergeordnetes Ziel zu erreichen13.
• Leserichtung: Man liest über die Map hinweg, indem man mental das Wort "dann" (then) zwischen die Schritte einfügt, um die Sequenz darzustellen2226.
• Die Frage der Vollständigkeit: Die horizontale Achse beantwortet die Frage: "Haben wir an die gesamte Reise gedacht?"714. Dieser Prozess erzwingt die Abbildung der gesamten Reise zuerst, wodurch Lücken (gaps) und fehlende Funktionalitäten (z. B. eine vergessene Passwort-Wiederherstellung) sofort visuell ersichtlich werden15....
B. Die vertikale Achse: Priorität und Detaillierung (Alternativen)
Die vertikale Achse wird unterhalb jedes Backbone-Schritts aufgebaut14 und repräsentiert die Priorität und den Detaillierungsgrad14....
• Inhalt: Hier werden die detaillierten Teilschritte, die eigentlichen User Stories und Aufgaben, gesammelt14. Die Detailtiefe nimmt nach unten zu21....
• Priorisierung: Die Stories, die für die Kernfunktion unverzichtbar sind ("Must-haves"), werden direkt unter dem Backbone-Schritt platziert (ganz oben in der Spalte)14.... Stories mit geringerer Priorität, alternative Lösungswege oder "Nice-to-have"-Funktionen folgen darunter1419.
• Leserichtung: Man liest die vertikale Achse hinunter, indem man mental das Wort "oder" (or) zwischen die Karten einfügt, da sie Alternativen zeigen22.
• Die Frage der Wichtigkeit: Die vertikale Achse beantwortet die Frage: "Was ist der wichtigste Teil jedes Schritts?"714.
4. Der kognitive und strategische Wandel
Der Wandel vom flachen Backlog zur Story Map ist primär kognitiv2.
• Mentalitätswandel: Während ein flaches Backlog eine "Feature-Fabrik"-Mentalität fördert, bei der Tickets abgearbeitet werden, erzwingt eine Story Map eine "Value-Delivery"-Mentalität27.
• Fokusverschiebung: Die zentrale Frage verschiebt sich von dem Feature-basierten Fokus ("Was bauen wir als Nächstes?") zu einem Benutzer-basierten Fokus ("Welches Problem des Nutzers lösen wir als Nächstes vollständig?")27.
• Roadmap-Erstellung: Durch das anschließende horizontale "Slicing" (Schneiden) der vertikal priorisierten Map wird die Landkarte direkt in eine umsetzbare Release-Planung oder Produkt-Roadmap verwandelt7.... Die oberste horizontale Scheibe (Slice) definiert das Minimum Viable Product (MVP) als den dünnsten, aber funktional vollständigen End-to-End-Weg durch das Produkt, oft als "Walking Skeleton" bezeichnet33....
Die Story Map ist somit die visuelle Ergänzung des Backlogs839. Sie schafft ein gemeinsames Verständnis (Shared Understanding) im Team7... und erleichtert die Priorisierung durch die klare Trennung von Vollständigkeit (horizontal) und Wichtigkeit (vertikal)14.

--------------------------------------------------------------------------------
Analogie: Die Umwandlung des flachen Backlogs in die User Story Map ist vergleichbar mit dem Wechsel von einer unendlichen Einkaufsliste zu einem modernen Navigationssystem. Die Liste mag die wichtigsten Zutaten (Stories) nennen, aber sie sagt Ihnen nicht, in welcher Reihenfolge Sie die Gänge des Supermarkts (Backbone) durchqueren müssen, noch zeigt sie Ihnen, welche Alternativen es für jedes Produkt gibt. Die Story Map bietet hingegen die vollständige Route (horizontal) und die Priorität an jeder Station (vertikal), sodass Sie zielgerichtet das minimal verwertbare Gericht (MVP) zubereiten können, anstatt nur einen Sack zufälliger, kontextfreier Zutaten zu besitzen.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Kernkonzept“ über „Fokus auf Benutzererlebnis (Customer Journey)“ aussagen.

Das Kernkonzept der User Story Map (USM) ist untrennbar mit dem Fokus auf das Benutzererlebnis (Customer Journey) verbunden1. Die Quellen beschreiben diesen Fokus als den fundamentalen Wandel weg von einer einfachen Aufgabenliste hin zu einer kontextreichen Planungsmethode2....
1. Das Benutzererlebnis als Kernkonzept der USM
Die User Story Map (USM) ist eine visuelle Technik aus dem agilen Projektmanagement, die Produktarbeit organisiert und priorisiert2.... Im Gegensatz zu einem traditionellen, flachen Backlog, das oft als "Sack voller kontextfreiem Mulch" empfunden wird34, verwandelt die USM die Anforderungen in eine zweidimensionale, kontextreiche "Landkarte"24.
Der Fokus auf die Customer Journey bewirkt einen entscheidenden Paradigmenwechsel:
1. Vom Feature zur Lösung: Ein flaches Backlog fördert eine "Feature-Fabrik"-Mentalität, während eine Story Map eine "Value-Delivery"-Mentalität erzwingt1. Die zentrale Frage verschiebt sich von "Was bauen wir als Nächstes?" zu "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"14.
2. Verankerung im Kontext: Die visuelle Darstellung der USM wandelt die flache Liste in eine dreidimensionale Ansicht um1. Diese Darstellung verankert jede einzelne User Story fest im Kontext der gesamten Customer Journey1.
2. Die User Journey als Struktur (Die Horizontale Achse)
Die Customer Journey ist das strukturelle Rückgrat (Backbone) der Story Map:
• Das Backbone: Die horizontale Achse der Story Map bildet das "Backbone" (Rückgrat)8.... Dieses Backbone fungiert als die narrative Klammer des Produkts und wird von links nach rechts in chronologischer Reihenfolge der Benutzerinteraktion angeordnet8....
• Aktivitäten des Nutzers: Das Backbone setzt sich aus den "großen Schritten"8 oder Benutzeraktivitäten (User Activities)8... zusammen, die ein Benutzer durchführen muss, um sein übergeordnetes Ziel mit dem Produkt zu erreichen8....
• Vollständige Abbildung: In ihrer Gesamtheit bieten diese Aktivitäten eine vereinfachte, aber vollständige Darstellung der User Journey8. Beispielsweise könnte das Backbone für einen Online-Shop lauten: "Produkte erkunden" → "Produkte vergleichen/auswählen" → "Zur Kasse gehen/Bezahlen" → "Bestellung verfolgen/empfangen"8....
Die Story Map zwingt das Team, zuerst die gesamte Reise horizontal abzubilden20. Dies beantwortet die horizontale Frage der USM: "Haben wir an die gesamte Reise gedacht?" (Vollständigkeit)21. Lücken (gaps) oder fehlende Funktionalitäten, die für eine durchgängige Benutzererfahrung notwendig sind (z.B. eine vergessene Passwort-Wiederherstellung), werden durch diesen prozessualen Fokus sofort visuell ersichtlich20....
3. Benutzerzentrierung und Personas
Der Fokus auf den Benutzer ist ein grundlegendes Ziel der Story-Mapping-Methode5...:
• Perspektive: Die Map wird explizit aus der Perspektive des Benutzers erstellt26.... Die Story Map ist benutzerzentriert27..., im Gegensatz zum Process Mapping, das unternehmenszentriert ist und interne Workflows beschreibt32.
• Persona-Definition: Die Definition von Personas (fiktive Nutzerprofile mit Zielen und Problemen) ist unerlässlich, da die Map von deren Zielen und Aktivitäten abgeleitet wird14.... Es ist eine Best Practice, sich anfangs auf eine primäre Persona zu fokussieren, um die Komplexität zu reduzieren33. Fortgeschrittene Teams können später spezifische Stories für weitere Personas in horizontalen Zeilen (Swimlanes) hinzufügen36.
4. Der Einfluss auf die MVP-Definition
Der ganzheitliche Blick auf die Customer Journey ist entscheidend für die Priorisierung und die Definition des Minimum Viable Product (MVP)5...:
• Der "Walking Skeleton": Die Release-Planung durch "Slicing" (horizontales Schneiden)37 stellt sicher, dass das resultierende MVP nicht nur eine Sammlung der wichtigsten Features ist38. Stattdessen definiert es den dünnsten, aber funktional vollständigen End-to-End-Weg durch das Produkt38.
• Dieses Ergebnis, der "Walking Skeleton" (laufendes Skelett)30..., garantiert eine Complete Product Experience (CPE) oder zumindest eine durchgehende Benutzererfahrung38.
• Um eine vollständige Journey zu gewährleisten, muss der MVP-Slice mindestens eine Story aus jedem kritischen Backbone-Schritt enthalten38. Dadurch wird verhindert, dass wichtige Schritte der Customer Journey (z.B. die Bestellung verfolgen) im ersten Release fehlen, obwohl der Rest der Kaufabwicklung implementiert ist1638.
5. Abgrenzung zur Customer Journey Map (UJM)
Obwohl die Story Map (USM) auf der Customer Journey basiert, ist sie nicht identisch mit einer User Journey Map (UJM)10...:
Dimension
User Story Map (USM)
User Journey Map (UJM)
Fokus
Funktionalität & Features4548
Emotionen & Erlebnis, Schmerzpunkte (Pain Points)10...
Ziel
Produkt-Planung, Backlog-Strukturierung45...
Empathie-Aufbau, Problem-Discovery4548
Perspektive
Benutzer (als Akteur – Was macht er?)48
Benutzer/Persona (als fühlendes Wesen – Was fühlt er?)48
Die Quellen betonen, dass die Methoden idealerweise sequenziell angewendet werden: Die UJM diagnostiziert Probleme und baut Empathie auf10..., während die USM diese emotionalen Erkenntnisse in umsetzbare Arbeitspakete (Stories) übersetzt und die technische Lösung plant18....
Zusammenfassend lässt sich sagen, dass der "Fokus auf das Benutzererlebnis" das Herzstück des User Story Mapping ist18. Er transformiert das agile Planning-Artefakt von einer bloßen Liste von Dingen, die gebaut werden sollen, hin zu einem narrativen Plan zur Schaffung einer vollständigen, durchgängigen Produkterfahrung für den Benutzer8....

--------------------------------------------------------------------------------
Man könnte die User Story Map als den GPS-Führer des Produktteams betrachten: Das Backbone ist die chronologische Route, die der Benutzer nehmen muss, um sein Ziel zu erreichen (die Customer Journey). Die vertikale Priorisierung sind die verschiedenen Wege und Fahrzeuge (Features) entlang dieser Route. Der MVP-Slice ist die kürzeste, aber funktional vollständige Fahrt von Start bis Ziel, die sicherstellt, dass der Benutzer niemals auf halbem Weg stehen bleibt.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Kernkonzept“ über „Förderung einer 'Value-Delivery'-Mentalität“ aussagen.

Die Quellen beschreiben die Förderung einer "Value-Delivery"-Mentalität als eines der zentralen Ziele und Kernkonzepte des User Story Mapping (USM)1. Diese Mentalität stellt einen fundamentalen kognitiven Wandel dar, der durch die zweidimensionale Struktur der Story Map erzwungen wird1.
Hier ist eine Diskussion, wie die Quellen dieses Kernkonzept beleuchten:
1. Der Paradigmenwechsel: Von der "Feature-Fabrik" zur "Value-Delivery"
Der Hauptbeitrag des Story Mapping liegt in der Überwindung der Mängel traditioneller, eindimensionaler Produkt-Backlogs2....
• Das Problem des flachen Backlogs: Ein traditionelles, flaches Backlog ist im Wesentlichen eine "To-Do-Liste"1. Es ist kontextfrei, überwältigend und unüberschaubar, sobald das Produkt skaliert3. Dieses Format wird treffend als "einen Sack voller kontextfreiem Mulch" beschrieben34. In der Praxis führt dies dazu, dass Teams oft das auswählen, was am einfachsten oder interessantesten ist, anstatt das, was den höchsten Kundennutzen liefert3.
• Die alte Mentalität: Ein flaches Backlog fördert zwangsläufig eine "Feature-Fabrik"-Mentalität ("Feature-Factory"-Mentalität), bei der es primär darum geht, Tickets abzuarbeiten ("Was bauen wir als Nächstes?")14.
• Die neue Mentalität: Im Gegensatz dazu erzwingt die Story Map eine "Value-Delivery"-Mentalität1. Die zentrale Frage verschiebt sich von "Was bauen wir als Nächstes?" zu "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"2. Die Story Map hilft, die Anforderungen aus Kundensicht zu ordnen und beantwortet die Fragen Warum bauen wir das?, Für wen? und Welchen Nutzen liefert es?7....
2. Mechanismus der Wertlieferung durch die 2D-Struktur
Die physische Anordnung der Story Map ist der Mechanismus, der diese Wertorientierung in den Fokus rückt10....
• Verankerung im Kontext: Die Story Map wandelt die flache Liste in eine zweidimensionale (oder dreidimensionale) Ansicht um, die jede User Story fest im Kontext der gesamten Customer Journey verankert12.
• Fokus auf den Nutzen (Vertikale Achse): Die vertikale Achse der Story Map repräsentiert Priorität und Detaillierungsgrad10.... Die wichtigste Frage, die durch diese vertikale Anordnung beantwortet wird (Wichtigkeit), ist: "Welche Story in dieser Spalte liefert den meisten Wert?"10.
• Priorisierung nach Wert: Die Story Map erlaubt es Teams, Lücken zu identifizieren und Stories nach Nutzen zu priorisieren11.... Die Stories, die für die Kernfunktion unverzichtbar sind ("Must-haves"), werden ganz oben in der Spalte platziert217. Die Wichtigkeit wird dabei aus einer Kombination von Nutzen, Risiko und technischem Aufwand abgeleitet1819. Frameworks wie der "Value vs. Complexity Quadrant" oder WSJF (Weighted Shortest Job First) werden im Story Mapping angewendet, um den ökonomischen Wertfluss zu optimieren20.
3. Sicherstellung der vollständigen Wertlieferung (Slicing)
Die "Value-Delivery"-Mentalität manifestiert sich am deutlichsten in der Definition des Minimum Viable Product (MVP) durch das sogenannte "Slicing" (in Scheiben schneiden)21.
• Vollständige End-to-End-Erfahrung: Das durch Slicing definierte MVP ist nicht einfach eine Liste der fünf wichtigsten Features22. Stattdessen ist es der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt22. Dieses Ergebnis wird auch als "Walking Skeleton" (laufendes Skelett) bezeichnet – eine minimale, aber durchgängig funktionsfähige Version des gesamten Systems18....
• Erzwungene Lückenprüfung: Die Story Map erzwingt, dass der MVP-Slice eine minimale Version aller notwendigen Schritte (Aktivitäten im Backbone) enthält, wodurch eine "Complete Product Experience" (CPE) geliefert wird222. Dies verhindert den Fehler eines flachen Backlogs, bei dem wichtige, aber vermeintlich unwichtige Schritte (wie die Passwort-Wiederherstellung) vergessen werden, während sich das Team auf andere, leichter zu liefernde Features konzentriert2227. Die Priorisierung zielt auf das minimal Nützliche ab2829.
4. Der Workshop als Mittel zur Konsensbildung
Die Story Map ist kein reines Artefakt, sondern ein diskursives Werkzeug, dessen wahrer Wert durch den kollaborativen Workshop entsteht – eine "kuratierte Konversation"30....
• Geteiltes Verständnis (Shared Understanding): Das ultimative Ziel des Mapping-Prozesses ist die Konversation und das gemeinsame Verständnis im Team3135. Das funktionsübergreifende Team (Business, UX, Entwicklung) muss anwesend sein4.... Die Entwickler müssen technische Abhängigkeiten und Anforderungen einbringen, damit die Map nicht zu einer reinen "Wunschliste" wird3839.
• Fokus auf Nutzerwert: Durch die Einbindung aller relevanten Rollen wird sichergestellt, dass der Fokus auf dem Nutzen für den Benutzer liegt28.... Der Story Mapping Workshop beginnt mit der Definition der Persona und dem Problem-Framing, was das Team direkt auf die Frage "Welches Problem lösen wir? Für wen?" einstimmt7....
• Erfolgsmessung: Die "Value-Delivery"-Mentalität wird durch die Aufforderung unterstützt, für jede Release-Slice Ziele ("Outcome") und Metriken festzulegen, um den gelieferten Nutzen zu überprüfen6....
Zusammenfassend lässt sich sagen, dass die Story Map im Kern ein kognitives Werkzeug1 ist, das durch seine zweidimensionale Struktur (chronologische Journey horizontal, Wertpriorisierung vertikal) die Produktplanung weg von der reinen Feature-Abarbeitung hin zur kontinuierlichen und vollständigen Lieferung von Nutzerwert lenkt1....

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Definition & Nutzen“ über „Vorteile gegenüber Flachem Backlog“ aussagen.

Die Story Map wurde entwickelt, weil einfache Backlogs den Gesamtzusammenhang (the big picture) nicht sichtbar machen1.... Die Quellen legen klar dar, dass die Vorteile der User Story Map (USM) gegenüber dem flachen Backlog direkt aus ihrer zweidimensionalen Definition und dem daraus resultierenden Nutzen für Kontext, Priorisierung und gemeinsames Verständnis entstehen1....
Im Kontext von „Definition & Nutzen“ lassen sich die Vorteile der User Story Map gegenüber einem flachen Backlog wie folgt diskutieren:
1. Überwindung der Kontextarmut und der Unübersichtlichkeit
Das fundamentale Problem eines traditionellen, flachen Backlogs liegt in seiner eindimensionalen Struktur45.
• Definition der Schwäche: Ein flaches Backlog ist im Grunde eine lineare, eindimensionale "To-Do-Liste"5.... Sobald ein Produkt skaliert und Hunderte von Einträgen umfasst, wird diese Liste überwältigend und unüberschaubar8.
• Fehlender Kontext: Es ist unmöglich, das „große Ganze“ (the big picture) zu sehen oder den Kontext der einzelnen Aufgaben zu verstehen8. Jeff Patton beschreibt ein solches Backlog treffend als einen „Sack voller kontextfreiem Mulch“5.... Diese Kontextarmut führt in der Praxis oft dazu, dass Teams Aufgaben auswählen, die am einfachsten oder interessantesten sind, anstatt diejenigen, die den höchsten Kundennutzen liefern8.
• Story Map als Lösung (Definition & Nutzen): Die Story Map transformiert die eindimensionale Liste in eine zweidimensionale Matrix (horizontal und vertikal)1... oder eine kontextreiche "Landkarte"45. Diese Darstellung verankert jede einzelne User Story fest im Kontext der gesamten Customer Journey17.
2. Trennung von Vollständigkeit und Wichtigkeit (Fokus auf den Nutzerwert)
Die zweidimensionale Struktur der Story Map ist ihr entscheidender Vorteil, da sie zwei fundamentale Produktmanagement-Fragen trennt, die in flachen Backlogs oft vermischt werden18:
Kriterium
Flaches Product Backlog
User Story Map
Fokus
Feature-basiert (Was wird gebaut?)5
Benutzer-basiert (Welches Problem wird gelöst?)1...
Primäres Ziel
Arbeitsverwaltung (Work planning)5
Geteiltes Verständnis (Shared Understanding)5...
Mentalität
"Feature-Fabrik"-Mentalität (Tickets abarbeiten)17
"Value-Delivery"-Mentalität (Nutzerprobleme vollständig lösen)17
• Fehlgeleitete Priorisierung im Flachen Backlog: Ein flaches Backlog priorisiert linear, oft eindimensional (z. B. durch Stack-Ranking)5. Dort konkurriert eine wichtige Story für den Bezahlvorgang direkt mit einer weniger wichtigen Story für die Passwort-Wiederherstellung21.
• Strukturierte Priorisierung in der Story Map: Die USM erzwingt, dass das Team zuerst die gesamte Benutzerreise horizontal abbildet (die Frage der Vollständigkeit)21. Die horizontale Achse (das Backbone) stellt die chronologische Abfolge der Benutzeraktivitäten dar22.... Erst danach wird vertikal priorisiert (die Frage der Wichtigkeit)1821. Die wichtigsten, für die Kernfunktion unverzichtbaren Stories werden dabei ganz oben in ihrer Spalte platziert18.
3. Effektive Identifizierung von Lücken und Risikominimierung
Story Mapping ist ein Mechanismus zur Risikominimierung19, insbesondere hinsichtlich der Vollständigkeit des Produkts:
• Lücken erkennen: Beim flachen Backlog werden Lücken oft übersehen5. Das zweidimensionale Layout der Story Map hingegen macht Lücken (gaps) und fehlende Funktionalitäten sofort visuell ersichtlich und die Vollständigkeitsprüfung intuitiv5....
• Narrative Abwanderung: Der kritischste Schritt des Workshops ist das "Wandern" der Map als Gruppe, bei dem die Geschichte narrativ von links nach rechts abgewandert wird19.... Durch dieses "Erzählen" deckt das Team unweigerlich Engpässe, fehlende Informationen, Abhängigkeiten und notwendige technische Stories auf, die zuvor übersehen wurden1930.
4. Definition eines funktional vollständigen MVP ("Walking Skeleton")
Der Unterschied zwischen einem flachen Backlog und einer Story Map wird besonders bei der Definition des Minimum Viable Product (MVP) deutlich31.
• Backlog-MVP (Ineffizient): Ein MVP, das aus einem flachen Backlog abgeleitet wird, ist oft nur „die 5 wichtigsten Features“ aus einer Liste32. Dies kann zu einem funktional unbrauchbaren Produkt führen, weil notwendige Schritte fehlen (z.B. wenn man nur die wichtigsten Stories für eine Mahlzeit baut und ein ungewürztes, hartgekochtes Ei liefert, weil die Story "gut gewürzt sein" niedrig priorisiert wurde)32.
• Story Map-MVP (Vollständig): Die Story Map ermöglicht die horizontale Release-Planung durch "Slicing"5.... Der erste "Slice" (die oberste horizontale Zeile) definiert das MVP nicht als die wichtigsten Features, sondern als den dünnsten, aber funktional vollständigen End-to-End-Weg durch das Produkt32.
• Walking Skeleton: Die Story Map erzwingt, dass der MVP-Slice eine minimale Version aller notwendigen Schritte (Aktivitäten) enthält32. Dieses Ergebnis wird als "Walking Skeleton" (laufendes Skelett) bezeichnet – eine minimale, aber durchgängig funktionsfähige Version des gesamten Systems, die es dem Benutzer erlaubt, seine Ziele zu erreichen32....
Zusammenfassend lässt sich sagen, dass der Story Map-Prozess im Gegensatz zum flachen Backlog nicht nur ein Werkzeug zur Arbeitsverwaltung (Work planning) ist, sondern ein diskursives Werkzeug zur Schaffung eines geteilten Verständnisses5... über die gesamte User Journey3....
Analogie: Das flache Backlog ist wie eine unstrukturierte Einkaufsliste, auf der die 50 wichtigsten Zutaten für das Abendessen aufgereiht sind – Sie wissen, was Sie brauchen, aber nicht, in welcher Reihenfolge Sie es verwenden oder ob Sie damit überhaupt ein vollständiges Gericht zubereiten können. Die User Story Map hingegen ist wie ein Kochbuch: Sie visualisiert den gesamten Prozess (horizontal: vom Appetizer bis zum Dessert) und ordnet die Zutaten (vertikal: Stories) nach ihrer Wichtigkeit und ihrer Rolle im jeweiligen Schritt. Dadurch stellen Sie sicher, dass Sie den minimalen, aber durchgängigen "Laufweg" (Walking Skeleton) zum fertigen Essen kochen können.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Vorteile gegenüber Flachem Backlog“ über „Kontextreich ('Das große Ganze')“ aussagen.

Die Quellen betonen übereinstimmend, dass die Kontextarmut des flachen Backlogs der Hauptgrund für die Entwicklung des User Story Mappings (USM) war und dass der größte Vorteil der USM gerade in ihrer Fähigkeit liegt, "Das große Ganze" (The Big Picture) sichtbar und kontextreich zu machen1....
Hier ist eine detaillierte Diskussion, was die Quellen im Kontext der Vorteile gegenüber dem flachen Backlog über „Kontextreich ('Das große Ganze')“ aussagen:
1. Das Problem des flachen Backlogs: Kontextfreier Mulch
Die Notwendigkeit des Story Mappings ergibt sich direkt aus dem fundamentalen Problem der Struktur traditioneller Backlogs, die Jeff Patton (eine Schlüsselfigur der Methode) treffend als "einen Sack voller kontextfreiem Mulch" beschreibt15.
Ein flaches Product Backlog wird als eindimensionale Liste (vertikal) betrachtet1 oder im Wesentlichen als eine "To-Do-Liste"56. Sobald ein Produkt skaliert und Hunderte von Einträgen umfasst, wird dieses flache Backlog überwältigend und unüberschaubar5.
Die kritischen Mängel, die die Quellen in Bezug auf den Kontext des flachen Backlogs hervorheben, sind:
• Verlust des Überblicks: Es wird unmöglich, das "große Ganze" (the big picture) zu sehen5. Ein flaches Backlog macht den Gesamtzusammenhang nicht sichtbar2....
• Fehlender Kontext: Es ist unmöglich, den Kontext der einzelnen Aufgaben zu verstehen5. Die User Stories in einem flachen Backlog sind kontextfrei oder bestenfalls implizit1.
• Erschwerte Priorisierung: Da keine Übersicht über die Zusammenhänge besteht, wird die Priorisierung erschwert2.... Dort konkurriert beispielsweise eine "wichtige" Story für den Bezahlvorgang direkt mit einer "weniger wichtigen" Story für die Passwort-Wiederherstellung, ohne dass der breitere Kontext der gesamten Nutzerreise berücksichtigt wird9.
• Fokus auf Features statt Nutzen: Ein flaches Backlog fördert eine "Feature-Fabrik"-Mentalität, bei der es primär um das Abarbeiten von Tickets geht6.
2. Die Lösung: Die Story Map als kontextreiche Landkarte
Die User Story Map (USM) transformiert das Problem des kontextfreien Backlogs, indem sie dieses in eine zweidimensionale, kontextreiche "Landkarte" verwandelt110. Einige Quellen beschreiben diesen Wandel sogar als eine Umwandlung in eine dreidimensionale Ansicht6.
Die Quellen definieren die Story Map explizit als kontextreich und als das Werkzeug, das "Das große Ganze" (The Big Picture) sichtbar macht1.
Erreichung des Kontexts durch die Struktur:
Der Kontext wird durch die zweidimensionale Struktur der Map geschaffen, die jede einzelne Story fest im Rahmen der gesamten Customer Journey verankert6:
1. Horizontale Achse (Das große Ganze): Die Story Map nutzt die horizontale Achse, um das "Backbone" (Rückgrat) zu bilden11. Dieses Backbone ist die narrative Klammer des Produkts und repräsentiert die chronologische Reihenfolge der Benutzeraktivitäten1112. In ihrer Gesamtheit bildet diese Achse eine vereinfachte, aber vollständige Darstellung der User Journey11.
    ◦ Die Map erlaubt es, den gesamten Prozess des wichtigsten Nutzer-Typs zu skizzieren, was Jeff Patton als „mile‑wide, inch‑deep“ (meilenweit, zoll-tief) bezeichnet13....
    ◦ Durch diese horizontale Achse erhält das Team eine Landkarte der User Journey1, die den Zusammenhang zwischen Aktivitäten, Features und Releases sichtbar macht1617.
2. Vertikale Achse (Detaillierung und Priorität): Die Stories werden unterhalb der Backbone-Schritte vertikal angeordnet und nach Priorität sortiert18. Dieser Aufbau verankert die Stories im Kontext der jeweiligen Benutzeraktivität und trennt die Frage nach der Vollständigkeit (horizontal) von der Frage nach der Wichtigkeit (vertikal)18.
Vorteile des Kontextreichtums:
Die gewonnene Kontextualisierung führt zu direkten Vorteilen gegenüber dem flachen Backlog:
• Gezwungene Vollständigkeit: Die Story Map zwingt das Team, zuerst die gesamte Reise horizontal abzubilden9. Dadurch werden Lücken (gaps) und fehlende Funktionalitäten, wie beispielsweise eine vergessene Passwort-Wiederherstellung, sofort visuell ersichtlich1....
• Fokus auf Wert: Anstatt nur Tickets abzuarbeiten (Feature-Fabrik-Mentalität), erzwingt die Story Map eine "Value-Delivery"-Mentalität6. Die zentrale Frage verschiebt sich von "Was bauen wir als Nächstes?" zu "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"6.
• Gemeinsames Verständnis (Shared Understanding): Der wahre Wert des Story Mappings liegt im kollaborativen Prozess, der eine "kuratierte Konversation" erzeugt22.... Diese Konversation, die darauf abzielt, das Wissen aller Beteiligten zu kollektivieren, ist der Mechanismus, der ein gemeinsames Verständnis (Shared Understanding) des Produkts und seines Kontexts schafft16....
• Lebendiger Kontext: Im Gegensatz zur "Wegwerf-Map"27 kann die Story Map als "lebendiges Dokument" dienen, das in das kontinuierliche Backlog Grooming integriert wird2728. Dies löst das Problem des "kontextfreien Mulchs" auf permanenter Basis, da neue Anforderungen direkt an der richtigen Stelle im Kontext der User Journey platziert werden29. Die Map wird zum Kontextgeber vor jedem Sprint Planning30.
Zusammenfassend lässt sich sagen, dass der Vorteil der Story Map im Kontext von „Das große Ganze“ darin besteht, eine kontextfreie, lineare Liste durch eine zweidimensionale, narrative Struktur zu ersetzen, die es dem Team ermöglicht, Visuell die gesamte Nutzerreise zu überblicken, was essenziell für fundierte Priorisierungsentscheidungen und ein gemeinsames, vollständiges Produktverständnis ist1....

--------------------------------------------------------------------------------
Analogie zum besseren Verständnis des Kontextvorteils:
Ein flaches Backlog ist wie eine lange Einkaufsliste, auf der 50 Artikel linear nach Preis sortiert sind. Man weiß, was man kaufen soll, aber nicht warum oder wie die Zutaten später zusammenpassen. Es ist schwer zu erkennen, ob man eine Zutat für ein dreigängiges Menü oder nur für einen Snack vergessen hat.
Die User Story Map ist hingegen wie ein Rezeptbuch, das zuerst die Abfolge der Gänge (horizontaler Kontext) zeigt: Vorspeise, Hauptspeise, Dessert. Erst darunter werden die benötigten Zutaten (User Stories) vertikal nach Wichtigkeit sortiert. Dadurch sieht man sofort, welche Zutaten für die Hauptspeise fehlen (Lücken im Kontext) und welche optional sind, und man hat jederzeit "Das große Ganze" des Menüs vor Augen.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Vorteile gegenüber Flachem Backlog“ über „Trennung von Vollständigkeit (Horizontal) & Wichtigkeit (Vertikal)“ aussagen.

Die Quellen betonen, dass die Trennung von Vollständigkeit (Horizontal) und Wichtigkeit (Vertikal) der entscheidende Vorteil der User Story Map (USM) gegenüber dem traditionellen, flachen Backlog ist1. Diese zweidimensionale Perspektive ist nicht nur administrativ, sondern vor allem kognitiv2 und transformiert das Backlog von einer eindimensionalen Liste in eine kontextreiche Landkarte34.
Das Problem des Flachen Backlogs
Das fundamentale Problem eines traditionellen, flachen Backlogs liegt in seiner Struktur als eindimensionale Liste35. Es ist im Wesentlichen eine "To-Do-Liste"24. In einem flachen Backlog konkurrieren Stories unterschiedlicher Abstraktion und Dringlichkeit direkt miteinander6. Beispielsweise könnte eine "wichtige" Story für den Bezahlvorgang direkt neben einer "weniger wichtigen" Story für die Passwort-Wiederherstellung stehen6. Ein solches Backlog wird als "Sack voller kontextfreiem Mulch" beschrieben, sobald es skaliert und Hunderte von Einträgen umfasst, was es unmöglich macht, das "große Ganze" (the big picture) zu sehen4....
Das flache Backlog listet Aufgaben linear nach Priorität1011 und kann die Trennung von Kontext und Priorität nicht leisten1. Es erschwert die MVP-Definition und Release-Planung, da weder Zusammenhänge noch die Reihenfolge der Nutzeraktion sichtbar sind10....
Die Trennung durch die Zweidimensionale Story Map
Die User Story Map (USM) wandelt das eindimensionale Backlog in eine zweidimensionale Matrix um57, wodurch zwei zentrale Produktmanagement-Fragen klar getrennt und nacheinander beantwortet werden1:
1. Die Horizontale Achse: Vollständigkeit (Das „Backbone“)
Die horizontale Achse bildet das Backbone (Rückgrat) des Produkts7.... Sie dient als narrative Klammer715 und ist chronologisch von links nach rechts angeordnet1....
• Darstellung: Das Backbone besteht aus den groben Benutzeraktivitäten (User Activities) oder "großen Schritten"7, die ein Benutzer durchführt, um sein übergeordnetes Ziel zu erreichen718. Diese Aktivitäten bilden in ihrer Gesamtheit die vereinfachte, aber vollständige Darstellung der User Journey7.
• Die Frage der Vollständigkeit: Die horizontale Achse beantwortet die Frage: "Haben wir an die gesamte Reise gedacht?" bzw. "Sind alle notwendigen Backbone-Schritte vorhanden?"1.
• Vorteil (Gaps): Die Story Map zwingt das Team, zuerst die gesamte Reise horizontal abzubilden6. Dieser Prozess macht Lücken (gaps) und fehlende Funktionalitäten (z.B. die vergessene Passwort-Wiederherstellung) sofort visuell ersichtlich5....
2. Die Vertikale Achse: Wichtigkeit und Priorität
Die vertikale Achse wird unterhalb jedes Backbone-Schritts aufgebaut1. Hier werden die detaillierten Teilschritte und die eigentlichen User Stories gesammelt1....
• Darstellung: Diese Achse repräsentiert die Priorität und den Detaillierungsgrad1.... Die wichtigsten Stories, die für die Kernfunktion unverzichtbar sind ("Must-haves")2728, werden direkt unter dem Backbone platziert (ganz oben in der Spalte)1.... Darunter folgen Stories mit geringerer Priorität, alternative Lösungswege, oder "Nice-to-have"-Funktionen1. Innerhalb einer Spalte zeigen die Karten Alternativen, die mit dem Wort "oder" mental gelesen werden können1626.
• Die Frage der Wichtigkeit: Die vertikale Achse beantwortet die Frage: "Was ist der wichtigste Teil jedes Schritts?" bzw. "Welche Story in dieser Spalte liefert den meisten Wert?"1.
• Priorisierung: Die Stories werden vertikal nach Wichtigkeit sortiert29..., wobei Wichtigkeit sich aus Nutzen, Risiko und technischem Aufwand ergibt3031.
Ergebnis: Fokus auf Value Delivery und den "Walking Skeleton"
Durch diese Trennung fördert die Story Map eine "Value-Delivery"-Mentalität2. Die zentrale Frage verschiebt sich von "Was bauen wir als Nächstes?" zu "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"2.
Die klare Abbildung von Vollständigkeit (horizontal) und Wichtigkeit (vertikal) ist die Grundlage für das "Slicing" (in Scheiben schneiden), bei dem horizontale Linien über die gesamte Breite der Map gezogen werden, um Releases zu definieren17....
Der erste und wichtigste dieser horizontalen "Slices" definiert das Minimum Viable Product (MVP)32. Die Map stellt sicher, dass dieses MVP nicht nur "die 5 wichtigsten Features" sind, sondern der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt33. Das resultierende MVP, auch als "Walking Skeleton" (laufendes Skelett) bezeichnet33..., muss dafür Stories aus jedem kritischen Backbone-Schritt enthalten, da die Vollständigkeit (horizontal) gewährleistet wurde, bevor die Priorität (vertikal) festgelegt wurde633.
Diese Struktur verhindert, dass wichtige Schritte der User Journey übersehen werden, was bei einer linearen Priorisierung eines flachen Backlogs leicht geschehen kann und das Produkt unbrauchbar machen würde33.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Vorteile gegenüber Flachem Backlog“ über „Lücken (Gaps) werden sofort visuell ersichtlich“ aussagen.

Die Quellen betonen, dass die sofortige visuelle Erkennbarkeit von Lücken (Gaps) der entscheidende Vorteil des User Story Mapping (USM) gegenüber einem flachen Produkt-Backlog ist. Dieses Resultat wird durch die einzigartige zweidimensionale Struktur der Story Map erzwungen12.
1. Die Begrenzung des Flachen Backlogs
Im Gegensatz zur Story Map ist das traditionelle, flache Backlog eine eindimensionale Liste (eine "To-Do-Liste")34, die Aufgaben linear nach Priorität auflistet5. Da ihr der Kontext der gesamten User Journey fehlt45, wird die Vollständigkeitsprüfung schwierig, und Lücken in der Customer Journey werden oft übersehen3. Jeff Patton beschreibt ein solches Backlog als "einen Sack voller kontextfreiem Mulch"4.
2. Der Mechanismus der USM zur Lückenerkennung
Die Story Map löst dieses Problem, indem sie eine zweidimensionale Matrix einführt, die zwei fundamentale Produktmanagement-Fragen trennt1:
1. Die horizontale Frage (Vollständigkeit): "Haben wir an die gesamte Reise gedacht?" (Sind alle notwendigen Backbone-Schritte vorhanden?)1.
2. Die vertikale Frage (Wichtigkeit): "Was ist der wichtigste Teil jedes Schritts?"1.
Die Story Map zwingt das Team, zuerst die gesamte Benutzerreise horizontal abzubilden, bevor vertikal priorisiert wird2. Dieses zweidimensionale Layout67 und die Fokussierung auf die chronologische Reihenfolge der Benutzeraktivitäten8 machen Lücken und fehlende Funktionalitäten sofort visuell ersichtlich23.
Infolgedessen wird die Vollständigkeitsprüfung, die bei flachen Backlogs schwierig ist, bei der Story Map intuitiv3.
3. Der Prozess der Lückenidentifizierung im Workshop
Der Story Mapping Workshop nutzt die visuelle Struktur aktiv, um Gaps aufzudecken:
• Narrative Abwanderung: Im kritischsten Schritt des Workshops "wandert" das Team die Map als Gruppe narrativ ab, von der ersten Aktivität links bis zur letzten rechts19.
• Gemeinsames Verständnis: Durch das "Erzählen" der Geschichte entlang der Map9 deckt das Team unweigerlich Lücken, Engpässe, fehlende Informationen und Abhängigkeiten auf, die zuvor übersehen wurden9.
• Beispiel für vergessene Funktionalität: Die Quellen führen das Beispiel der vergessenen Passwort-Wiederherstellung an, die in einem flachen Backlog leicht untergehen kann, aber in der visuellen Story Map sofort als fehlender Schritt in der Customer Journey ("Anmelden" / "Zugang erhalten") erkannt wird2.
Das Aufdecken dieser Lücken minimiert somit das Risiko9.
Zusammenfassend lässt sich sagen: Die User Story Map agiert wie ein Röntgenbild der Customer Journey, das transparente Einblicke in die Vollständigkeit des Produkts bietet10. Während das flache Backlog wie eine ungeordnete Einkaufsliste ist, bei der man leicht vergisst, die Milch zu kaufen, sorgt die Story Map durch ihre Landkarten-Analogie dafür, dass jeder notwendige "Ort" auf der Benutzerreise kartografiert ist34.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Vorteile gegenüber Flachem Backlog“ über „Primäres Ziel: Geteiltes Verständnis (Shared Understanding)“ aussagen.

Die Quellen betonen übereinstimmend, dass das primäre Ziel des User Story Mapping (USM) – und damit sein größter Vorteil gegenüber einem flachen Backlog – die Schaffung eines Geteilten Verständnisses (Shared Understanding) im Team ist1....
Im Kontrast dazu dient das flache Product Backlog primär der Arbeitsverwaltung (Work planning)1.
1. Die Priorität des Geteilten Verständnisses
Das ultimative Ziel des Story Mapping liegt nicht in der Erstellung des physischen oder digitalen Artefakts selbst, sondern im Prozess der Erstellung36.
• Prozess vor Artefakt: Das Mapping zielt darauf ab, die Konversation und das gemeinsame Verständnis im Team zu fördern3.
• Wissen kollektivieren: Der Story Mapping Workshop fungiert als Mechanismus zur Kollektivierung des Wissens aller Beteiligten26.
• Kernfrage: Das Team muss zu Beginn ein gemeinsames Verständnis für das Ziel des Produkts oder Features haben6. Eine Story Map beantwortet die Fragen: Warum bauen wir das? Für wen? und Welchen Nutzen liefert es?78.
2. Der Mechanismus: Die kuratierte Konversation
Dieses gemeinsame Verständnis entsteht durch den kollaborativen Prozess im Story Mapping Workshop, der als "kuratierte Konversation" bezeichnet wird2....
In dieser Konversation wird das Shared Understanding in folgenden Momenten geschaffen:
1. Diskussion über Platzierung: Der wahre Wert liegt in der Diskussion darüber, warum eine Story an einer bestimmten Stelle auf der Map platziert werden muss (vertikal in der Priorität oder horizontal in der Customer Journey)2.
2. Lücken identifizieren: Durch das narrative Abwandern der Map deckt die Gruppe unweigerlich Lücken und fehlende Funktionalitäten auf, die zuvor übersehen wurden2.... Diese Lücken zu visualisieren und zu diskutieren, festigt das gemeinsame Wissen2.
3. Hören der Gründe: Die Teilnahme von funktionsübergreifenden Teammitgliedern, insbesondere Entwicklern, ist entscheidend1415. Wenn Teammitglieder teilnehmen, hören sie die zugrundeliegenden Gründe, warum Nutzer und Stakeholder bestimmte Dinge benötigen (Probleme, Frustrationen, Erwartungen)15. Dieses Zuhören kann zu Erkenntnissen führen, die sie sonst verpasst hätten15.
3. Der kognitive Wandel
Die Story Map forciert einen kognitiven Wandel weg von der isolierten Abarbeitung von Tickets, wie sie das flache Backlog fördert, hin zu einem fokussierten, gemeinsamen Ziel16.
Die Umwandlung des "Sacks voller kontextfreiem Mulch" (das flache Backlog)1718 in eine kontextreiche Landkarte19 verankert jede einzelne User Story fest im Kontext der gesamten Customer Journey16.
Dieser Wandel führt zu einer Verschiebung der Denkweise:
• Von Feature zu Wert: Statt einer "Feature-Fabrik"-Mentalität16, die das Abarbeiten von Tickets fördert, erzwingt die Story Map eine "Value-Delivery"-Mentalität16.
• Neue zentrale Frage: Die Prioritätenverschiebung drückt sich in der geänderten zentralen Frage aus: Statt "Was bauen wir als Nächstes?" lautet die Frage nun "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"16. Die gemeinsame Beantwortung dieser Frage ist der Ausdruck des geschaffenen Shared Understandings.

--------------------------------------------------------------------------------
Analogie: Man kann das Story Mapping als den Unterschied zwischen dem Erhalt einer Einkaufsliste (dem flachen Backlog) und dem gemeinsamen Besuch des Supermarkts mit der Familie (dem Story Mapping Workshop) betrachten. Auf der Liste stehen nur die Artikel (Stories) in Prioritätsreihenfolge. Beim gemeinsamen Einkaufen (Mapping) wird aber klar, warum man Mehl vor Eiern kaufen muss (Abhängigkeiten), für wen das Abendessen ist (Persona/Ziel), welche Teile des Rezepts man streichen kann, wenn die Zeit knapp wird (Slicing/MVP), und man vermeidet, wichtige Schritte zu vergessen, die auf der Liste gefehlt haben (Lücken) – weil alle Beteiligten den Gesamtzusammenhang (das "große Ganze") sehen und diskutieren2....

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Definition & Nutzen“ über „Ziele“ aussagen.

Die Quellen definieren die Ziele des User Story Mapping (USM) als weit über die bloße Organisation von Anforderungen hinausgehend und legen den Fokus auf die Schaffung eines gemeinsamen Verständnisses, die Nutzerzentrierung und die konkrete Release-Planung.
Die zentralen Ziele von User Story Mapping sind:
I. Kognitive und Kollaborative Ziele (Shared Understanding)
Das ultimative Ziel des User Story Mapping liegt nicht primär im fertigen Artefakt selbst, sondern im kollaborativen Prozess seiner Erstellung, der eine "kuratierte Konversation" darstellt12.
1. Schaffung eines gemeinsamen Verständnisses (Shared Understanding): Das oberste Ziel des gesamten Mapping-Prozesses ist die Konversation und das gemeinsame Verständnis im Team23. Durch die Einbindung unterschiedlicher Rollen in interaktiven Workshops schafft die Methode ein gemeinsames Verständnis des Produkts45.
2. Kollektivierung von Wissen: Der Workshop zielt darauf ab, das Wissen aller Beteiligten zu kollektivieren12. Um dies zu erreichen, muss der Workshop funktionsübergreifend besetzt sein und Business (Warum?), UX (Für wen?) und Entwicklung (Wie?) an einen Tisch bringen6.
3. Risikominimierung und Lückenidentifikation: Das Story Mapping ist ein Mechanismus zur Risikominimierung2. Es hilft Teams, Lücken (gaps) und fehlende Funktionalitäten (z. B. vergessene Passwort-Wiederherstellung) sofort visuell ersichtlich zu machen7.... Durch das narrative Abwandern der Map deckt das Team unweigerlich Lücken, Engpässe und Abhängigkeiten auf2.
4. Bessere Kommunikation: Die Map ist ein diskursives Werkzeug; sie lebt durch Gespräche411.
II. Strategische und Nutzerzentrierte Ziele
USM erzwingt einen Fokuswechsel weg von der reinen Aufgabenverwaltung hin zur Wertlieferung aus Sicht des Kunden1213.
1. Beantwortung der Kernfragen des Produkts: Eine Story-Map ist darauf ausgelegt, die fundamentalen Fragen der Produktentwicklung zu beantworten: Warum bauen wir das?, Für wen? und Welchen Nutzen liefert es?14....
2. Förderung der Nutzerzentrierung: Das Ziel ist es, die Anforderungen aus Kundensicht zu ordnen14... und den Fokus auf den Nutzer zu behalten16.... Die visuelle Übung soll helfen, die Arbeit zu definieren, die das ansprechendste Benutzererlebnis schafft12.
3. Verschiebung der zentralen Frage: Die Methode erzwingt eine "Value-Delivery"-Mentalität im Gegensatz zur "Feature-Fabrik"-Mentalität eines flachen Backlogs12. Die zentrale Frage verschiebt sich von "Was bauen wir als Nächstes?" zu "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"12.
III. Konkrete Planungsziele
Die visuelle Organisation der Stories in der zweidimensionalen Matrix dient direkt der effektiven agilen Planung1319.
1. MVP-Definition: Ein Hauptziel von USM ist es, Minimum Viable Products (MVPs) zu definieren10.... Dabei soll ein MVP nicht nur eine Liste wichtiger Features, sondern der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt sein, oft als "Walking Skeleton" bezeichnet21....
2. Release- und Roadmap-Planung: Die Map dient dazu, Releases zu planen16.... Durch das "Slicing" (horizontales Schneiden der Map) kann die beabsichtigte Lieferreihenfolge von Features für zukünftige Versionen und Quartale visualisiert werden26....
3. Backlog-Strukturierung und Priorisierung: Story Mapping dient der Produkt-Planung und Backlog-Strukturierung29. Es erleichtert die Priorisierung der Anforderungen45, indem es die Fragen der Vollständigkeit und der Wichtigkeit trennt und somit eine transparente Übersicht über die zu erstellende Software bietet3031.
4. Kontinuierliches Grooming: Ein weiteres Ziel ist die Nutzung der Map als "lebendiges Dokument" und zentrales Werkzeug für das kontinuierliche Backlog Grooming (Refinement)6....
Zusammenfassend lässt sich sagen: Die User Story Map hat das Ziel, die Komplexität eines wachsenden Backlogs zu beherrschen, indem sie das Backlog in eine kontextreiche, zweidimensionale Landkarte verwandelt, die dem Team hilft, nicht nur zu sehen, was es baut, sondern warum es dies aus der Perspektive des Nutzers tut12.... Es ist der Wandel von der einfachen "To-Do-Liste" zur "Landkarte" der User Journey und der Releases13.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Ziele“ über „MVP definieren“ aussagen.

Das Definieren des Minimum Viable Product (MVP) ist eines der zentralen und primären Ziele des User Story Mappings (USM)1.... Die Story Map dient als ein essenzielles Werkzeug, um Releases zu planen und den Umfang des MVP festzulegen2....
Die Quellen beschreiben, dass die USM das Konzept des MVP fundamental neu definiert6.
1. Der Mechanismus: Horizontales "Slicing"
Das Ziel, das MVP zu definieren, wird durch die Technik des "Slicing" (in Scheiben schneiden) der fertigen, priorisierten Map erreicht7....
• Vorgehen: Die vertikal priorisierte Map wird horizontal "geschnitten"8. Der Moderator oder Product Owner zieht hierfür horizontale Linien über die gesamte Breite der Map8.
• Die oberste Scheibe: Der erste und wichtigste "Slice" ist die oberste horizontale Scheibe, welche das Minimum Viable Product (MVP) definiert8....
• Release-Planung: Jede dieser horizontalen Scheiben repräsentiert ein geplantes Release, einen Sprint oder eine Iteration, wobei die Stories oberhalb der ersten Linie das erste Release bilden8....
2. Die Neudefinition des MVP: Der "Walking Skeleton"
Ein durch Slicing entstandenes MVP unterscheidet sich grundlegend von einem MVP, das aus einer flachen Liste abgeleitet wird:
• Vermeidung der "Feature-Liste": Das USM-MVP ist nicht einfach "die 5 wichtigsten Features" aus einer Liste6.
• Funktional vollständiger Weg: Stattdessen ist das MVP der dünnste, aber funktional vollständige End-to-End-Weg durch das gesamte Produkt6. Das Ziel dieses Slices ist es, eine "Complete Product Experience" (CPE) oder zumindest eine durchgehende Benutzererfahrung zu liefern6.
• Das Walking Skeleton: Dieses Ergebnis wird als "Walking Skeleton" (laufendes Skelett) bezeichnet6.... Es handelt sich dabei um einen minimalen, aber nutzbaren Ablauf, der dem Benutzer erlaubt, seine Ziele zu erreichen16....
• Anforderung an die Vollständigkeit: Der MVP-Slice muss (mindestens) eine Story aus jedem kritischen Backbone-Schritt enthalten6. Dies stellt sicher, dass alle notwendigen Schritte der User Journey (horizontal) abgedeckt sind, auch wenn nur in minimaler Form6....
3. Implementierung und Priorisierung
Um den MVP definieren zu können, muss die vertikale Priorisierung der Stories in jeder Spalte klar sein, denn die Stories, die für eine minimale Funktionsfähigkeit unerlässlich sind ("Must-haves"), werden nach oben geschoben und bilden so den MVP-Slice11....
• Kollaborativer Prozess: Stakeholder und das Entwicklungsteam sollten gemeinsam definieren, welche Stories in das MVP gehören1121.
• Methoden: Die Priorisierung, welche die Grundlage für das Slicing bildet, kann methodisch fundiert sein. Wird beispielsweise die MoSCoW-Methode angewendet, so bilden die "Must-have"-Stories kollektiv den natürlichen MVP-Slice20.
• Nachfolgende Releases: Die Slices unterhalb des MVP repräsentieren nachfolgende Releases, die dem "Walking Skeleton" mehr "Fleisch" (zusätzliche Funktionen oder Alternativen) hinzufügen12....
Das finale MVP ist somit ein Produkt, das, obwohl es minimalistisch ist, die Kernfunktionalität in jedem Schritt der Benutzerreise sicherstellt, wie es anhand der Fallstudien (z.B. E-Commerce oder Fitness-App) gezeigt wird24.... Das Ziehen des MVP-Slices ist so kritisch, dass der Workshop erst dann als beendet gilt, wenn der MVP klar definiert und vom Team committet ist27.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Ziele“ über „Releases planen“ aussagen.

Die Planung von Releases ist eines der zentralen Ziele und Hauptanwendungsgebiete des User Story Mappings (USM) im agilen Projektmanagement1.... Die Story Map wird explizit genutzt, um MVPs zu definieren und Releases zu planen1....
Das Ziel der Release-Planung wird durch die Technik des "Slicing" (in Scheiben schneiden) erreicht, welche die vertikal priorisierte Map in einen umsetzbaren Plan verwandelt4....
1. Die Methode: Horizontales "Slicing"
Die Release-Planung erfolgt durch das Hinzufügen von horizontalen Linien (Slices oder Cut-Lines) über die gesamte Breite der Map6....
• Definition der Scheibe: Jede dieser horizontalen „Scheiben“ (Slices) repräsentiert ein geplantes Release, einen Sprint oder eine Iteration6....
• Sequenz der Features: Die Anordnung der Stories in den Slices ermöglicht es dem Product Owner, die beabsichtigte Liefersequenz (delivery sequence) der Features in den kommenden Versionen zu kommunizieren16.
• Patton's Prozess: In Jeff Pattons fünfstufigem Prozess ist das "Slice Out Viable Releases" (Definition von MVP und nachfolgenden Releases) der vierte Schritt7....
2. Das Ziel: Definition des Minimum Viable Product (MVP)
Der wichtigste Planungsschritt ist die Definition des ersten Releases, des Minimum Viable Product (MVP)6....
• Der erste Slice: Die oberste Scheibe (alles oberhalb der ersten horizontalen Linie) definiert das MVP6....
• Neudefinition des MVP: Hier zeigt sich die wahre Stärke des Slicing: Es definiert das Konzept eines MVP fundamental neu6. Das MVP ist nicht nur eine Liste der wichtigsten Features ("die 5 wichtigsten Features")19, sondern der dünnste, aber funktional vollständige End-to-End-Weg durch das gesamte Produkt19....
• Der "Walking Skeleton": Das Ziel dieses MVP-Slices ist es, eine durchgehende Benutzererfahrung (Complete Product Experience, CPE) oder zumindest einen minimalen, aber nutzbaren Ablauf zu liefern19.... Dieses Ergebnis wird als „Walking Skeleton“ (laufendes Skelett) bezeichnet13.... Ein solcher Slice muss mindestens eine Story aus jedem kritischen Backbone-Schritt enthalten19.
• Beispiele: Fallstudien, wie die E-Commerce-Plattform, zeigen, dass der MVP-Slice einen kompletten Kaufzyklus ermöglichen muss, auch wenn er auf erweiterte Funktionen (wie PayPal oder Filter) verzichtet23.
3. Fortgeschrittene und kontinuierliche Release-Planung
Die Release-Planung ist kein einmaliger, abgeschlossener Schritt, sondern ein iterativer Prozess, der das Produktmanagement kontinuierlich unterstützt.
• Nachfolgende Releases: Die Slices unterhalb des MVP repräsentieren nachfolgende Releases (z.B. Version 1.1, Version 2.0)2425. Sie dienen dazu, dem "Walking Skeleton" mehr "Fleisch" hinzuzufügen—etwa durch die Implementierung höher priorisierter Alternativen oder "Nice-to-have"-Funktionen25.
• Roadmap-Funktion: Die Story Map fungiert nach dem Slicing als lebendige, visuelle Produkt-Roadmap25.
• Messung und Risiken: Für jede Release-Slice muss ein Ziel („Outcome“) definiert und es müssen Metriken festgelegt werden, um den Erfolg des Releases zu messen und den Nutzen zu überprüfen8.... Zudem helfen Risikonotizen, unsichere Annahmen oder externe Abhängigkeiten, die den Release gefährden könnten, sichtbar zu machen13....
Wichtiger Hinweis (Fallstrick): Das Ziehen der Release-Linien ist essenziell. Ein häufiger Fehler (Pitfall) ist das fehlende oder falsche "Slicing"32. Ohne diese Linien ist die Map lediglich ein Katalog aller Möglichkeiten, aber es existiert kein klarer Plan, was als Nächstes geliefert wird32. Daher ist der Workshop erst beendet, wenn der erste Slice (das MVP) klar definiert, visualisiert und vom Team committed ist32.

--------------------------------------------------------------------------------
Analogie:
Wenn das flache Backlog eine unübersichtliche Liste aller potenziellen Bauteile in einem Lagerhaus ist, ist die Story Map der Bauplan des Hauses. Das Releases Planen (Slicing) ist vergleichbar mit dem Definieren der Bauabschnitte: Der erste Slice (MVP/Walking Skeleton) garantiert, dass das Fundament, die tragenden Wände und ein funktionierendes Dach vorhanden sind – der Nutzer kann minimal, aber vollständig darin wohnen. Die nachfolgenden Slices fügen dann die Tapeten, Möbel und Extras hinzu, um das Erlebnis zu perfektionieren.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Ziele“ über „Fokus auf Nutzer behalten“ aussagen.

Die Quellen definieren den Fokus auf den Nutzer als eines der Hauptziele und eine grundlegende Anforderung für die erfolgreiche Anwendung des User Story Mapping (USM)1....
Die User Story Map ist eine agile Methode, die darauf abzielt, MVPs zu definieren, Releases zu planen und den Fokus auf den Nutzer zu behalten1....
1. Das Ziel: Nutzerzentrierung und Wertlieferung
Die Story Map ist eine visuelle Übung, die Produktmanagern und Teams hilft, Arbeit zu definieren, die das ansprechendste Benutzererlebnis schafft5.
Die primären Ziele der Methode sind explizit benutzerzentriert:
• Kernfragen beantworten: Eine Story Map beantwortet die grundlegenden Fragen "Warum bauen wir das?", "Für wen?" und "Welchen Nutzen liefert es?"3.... Sie hilft, die Anforderungen aus Kundensicht zu ordnen36.
• Mentalitätswandel: Die Story Map erzwingt einen kognitiven Wandel vom Abarbeiten von Tickets (der "Feature-Fabrik"-Mentalität) hin zu einer "Value-Delivery"-Mentalität5. Die zentrale Frage verschiebt sich zu: "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"5.
• Nutzenbasierte Priorisierung: Das zweidimensionale Layout hilft Teams, Stories nach Nutzen zu priorisieren8.... Die vertikale Achse beantwortet die Frage: "Welche Story in dieser Spalte liefert den meisten Wert?"11.
2. Strukturelle Verankerung in der Customer Journey
Der Fokus auf den Nutzer wird durch die zweidimensionale Struktur der Map festgeschrieben, die das gesamte Backlog im Kontext der Customer Journey verankert3....
• Das Backbone: Die horizontale Achse (das Backbone oder Rückgrat) dient als narrative Klammer14. Sie besteht aus den grobgranularen Benutzeraktivitäten (User Activities) oder "großen Schritten"14... in chronologischer Reihenfolge14.... Diese Aktivitäten bilden in ihrer Gesamtheit eine vereinfachte, aber vollständige Darstellung der User Journey14.
• Stories aus Nutzersicht: Die unter dem Backbone gesammelten Stories müssen als kurz formulierte Aussagen aus Sicht des Nutzers verfasst werden19.... Sie beschreiben, welche konkreten Funktionen gebaut werden müssen, um entdeckte Probleme zu lösen7....
3. Operative Anforderungen (Personas und Workshop-Regeln)
Um den Fokus auf den Nutzer aktiv zu gewährleisten, empfehlen die Quellen spezifische vorbereitende Schritte und Regeln für den Story Mapping Workshop:
• Persona-Definition: Die Definition der Ziel-Personas ist unerlässlich17..., da die Map aus der Perspektive des Benutzers erstellt wird24. Es ist eine Best Practice, den ersten Workshop auf eine primäre Persona zu fokussieren, um die Komplexität zu reduzieren24.
• Formulierung als Nutzeraktivität: Bei den Moderations-Tipps und Regeln wird explizit die User-Zentrierung gefordert: Alle Elemente müssen als Nutzeraktivitäten formuliert werden25....
• Vermeidung technischer Sprache: Im Gegensatz dazu sollten technische Formulierungen vermieden werden28.... Technische Aufgaben (Technical Stories) sollten in separate Spalten ausgelagert werden, um die Sicht des Nutzers auf das Produkt nicht zu stören25....
• Story Mapping Game: Selbst spielerische Übungen, wie das User-Story-Mapping-Spiel ("Morning Routine"), verdeutlichen, wie wichtig Priorisierung und Nutzerfokus sind31....
4. Abgrenzung zur User Journey Map
Der Fokus auf den Nutzer ist ein Unterscheidungsmerkmal der USM, obwohl sie nicht mit der User Journey Map (UJM) verwechselt werden sollte34....
• Die UJM ist ein Werkzeug aus dem UX-Design, das Empathie aufbaut und Probleme diagnostiziert, indem es Emotionen und Schmerzpunkte des Benutzers visualisiert3738.
• Die USM ist hingegen ein Werkzeug der Produktplanung, das die Funktionalität des Produkts fokussiert und die Lösung für die in der UJM identifizierten Probleme plant3738.
Idealerweise dient die UJM als perfekter Input für den USM-Workshop, um sicherzustellen, dass die geplante Funktionalität (USM) auf einem tiefen Verständnis der Nutzerbedürfnisse und -erlebnisse (UJM) basiert37.

--------------------------------------------------------------------------------
Zusammenfassend ist der Fokus auf den Nutzer im Story Mapping nicht nur eine Empfehlung, sondern ein durch die Struktur und Methodik erzwungenes Ziel. Indem die Story Map die gesamte Produktentwicklung an der chronologischen Abfolge der Benutzeraktivitäten ausrichtet, wird sichergestellt, dass das Team nicht in einer "Feature-Fabrik"-Mentalität verfällt, sondern sich stets darauf konzentriert, funktional vollständigen und wertvollen Nutzen für den Benutzer zu liefern.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Ziele“ über „Anforderungen aus Kundensicht ordnen“ aussagen.

Die Anforderungen aus Kundensicht zu ordnen und zu strukturieren, ist ein zentrales Ziel der User Story Mapping (USM) Methode und ein direkter Vorteil gegenüber dem flachen Produkt-Backlog.
Die Quellen beschreiben, dass die USM durch ihren benutzerzentrierten Ansatz und ihre visuelle Struktur eine "Value-Delivery"-Mentalität fördert, um sicherzustellen, dass die Produktentwicklung auf den maximalen Kundennutzen ausgerichtet ist1....
1. Das explizite Ziel: Antworten auf die Kundenfragen finden
Das Ziel einer Story Map ist es, grundlegende Fragen zur Produktentwicklung zu beantworten und dadurch die Anforderungen aus Kundensicht zu ordnen2....
Eine Story Map beantwortet explizit folgende Fragen2...:
• Warum bauen wir das?
• Für wen?
• Welchen Nutzen liefert es?
Dieser Fokus führt dazu, dass die Story Map eine benutzerzentrierte Methode der agilen Produktplanung ist5.... Das Ziel verschiebt sich weg von der Abarbeitung von Features hin zur vollständigen Lösung von Nutzerproblemen1. Die zentrale Frage lautet: "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"1.
2. Die Verankerung in der User Journey (Horizontal)
Die Story Map ordnet die Anforderungen, indem sie diese fest in den Kontext der gesamten Benutzerreise stellt1....
• Orientierung an Schritten: Die Technik orientiert sich an den Schritten des Benutzers bei der Nutzung des Systems, der sogenannten User Journey1112.
• Chronologische Abfolge: Die horizontale Achse der Map (das Backbone) bildet die chronologische Reihenfolge der Benutzeraktivitäten oder "großen Schritte" ab13.... Dieses Backbone fungiert als die narrative Klammer des Produkts und liefert eine vollständige Darstellung der User Journey4....
• Kognitiver Vorteil: Während ein flaches Backlog kontextfrei ist und verhindert, dass man das "große Ganze" sieht519, verankert die Story Map jede einzelne User Story fest im Kontext der gesamten Customer Journey1.
3. Die Priorisierung nach Nutzen (Vertikal)
Die Stories werden vertikal nach ihrer Wichtigkeit und dem Nutzen sortiert, um die Anforderungen im Sinne des Kunden zu strukturieren20....
• Wichtigkeitsachse: Unterhalb jeder Benutzeraktivität (Backbone-Schritt) werden die detaillierten User Stories vertikal angeordnet und nach Priorität sortiert18....
• Nutzen als Kriterium: Die Wichtigkeit der Stories ergibt sich aus einer Kombination von Nutzen, Risiko und technischem Aufwand26.... Die Stories, die für die Kernfunktion unverzichtbar sind ("Must-haves"), werden ganz oben platziert18....
• Gefahrvermeidung: Durch diese Struktur wird verhindert, dass Teams das auswählen, was am einfachsten oder am interessantesten ist, anstatt das, was den höchsten Kundennutzen liefert19.
4. Die Persona-Definition als Voraussetzung
Um Anforderungen aus Kundensicht ordnen zu können, ist die Definition der Ziel-Personas unerlässlich7....
• Perspektive: Die Map wird explizit aus der Perspektive des Benutzers erstellt7....
• Workshop-Regel: Eine Best Practice ist die User-Zentrierung, bei der alle Elemente als Nutzeraktivitäten formuliert werden, während technische Formulierungen vermieden werden32....
• Problemframing: Schon in der Vorbereitung des Workshops müssen die Kernfragen "Welches Problem lösen wir? Für wen? Welchen Nutzen stiftet das Produkt?" definiert werden31.
5. Das Ergebnis: Lieferung eines vollständigen Nutzens (MVP)
Die Ordnung der Anforderungen aus Kundensicht führt direkt zur Definition des Minimum Viable Product (MVP), das einen vollständigen Nutzen liefert:
• Walking Skeleton: Die Story Map wird horizontal "geschnitten" (Slicing), um Releases zu definieren18.... Der wichtigste Slice definiert das MVP. Dieses MVP ist der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt35....
• Complete Product Experience (CPE): Dieses Ergebnis, oft als "Walking Skeleton" bezeichnet, garantiert, dass der minimale, aber nutzbare Ablauf41 und eine durchgehende Benutzererfahrung (Complete Product Experience oder CPE) realisiert wird, da der MVP-Slice mindestens eine Story aus jedem kritischen Backbone-Schritt enthalten muss40. Dies ist die ultimative Form der Organisation von Anforderungen: sicherzustellen, dass der Kunde ein vollständiges Produktziel erreichen kann.
Zusammenfassend: Das Ordnen der Anforderungen aus Kundensicht wird durch die USM erreicht, indem sie die Anforderungen in einen narrativen Kontext (horizontal) setzt und sie dann nach dem maximalen Nutzerwert (vertikal) priorisiert, wodurch der Fokus von "Was bauen wir?" auf "Welchen vollständigen Nutzen liefern wir?" verlagert wird1.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down