The AI-Seeded Coaching Process for Human Mastery in Product Development
The coaching process we describe here is designed to empower human teams to build and own essential skills in product development, starting with initial inputs from artificial intelligence (AI) and progressing toward complete human autonomy. This is not about handing over control to machines but about using AI as a thoughtful catalyst to spark human creativity, critical thinking, and decision-making. By the end, teams will not only master the methodology but also adapt it confidently to their unique contexts, ensuring sustained value creation without ongoing reliance on AI or external coaching.

We define this coaching sequence as a phase-oriented process, structured into three interconnected phases that align with key stages of product development: Divergent Ideation, Backlog Refinement, and Value-Based Prioritization. Each phase builds on the last, with humans taking progressively greater ownership. This structure provides clear milestones, allowing teams to track progress and adjust as needed. It's important to note that while AI provides initial seeds—such as ideas, data insights, or frameworks—it never replaces human initiative; instead, it facilitates by offering objective starting points that humans can question, refine, and ultimately transform.

Throughout, the coach acts as a facilitator, not a director, reinforcing structure (through consistent frameworks), clarity (via transparent communication), reliability (by modeling dependable practices), and authenticity (encouraging genuine team input over performative compliance). This supports both individual growth—such as building confidence in challenging ideas—and team skillfulness, like collaborative prioritization. Expectations are straightforward: teams must engage actively, as passive participation undermines mastery. Boundaries are firm—AI is a tool, not a crutch, and humans are accountable for final outcomes—to foster true empowerment rather than dependency.

Below, we outline the steps within each phase, the methods and methodologies employed, and the rationale for their use. Steps are sequential within phases but iterative across the process, allowing for feedback loops.

Phase 1: Divergent Ideation – Seeding Creativity with AI, Building Human Exploration
This initial phase focuses on generating a broad range of ideas, where AI provides foundational sparks to overcome blank-page syndrome, and humans learn to expand, challenge, and own the creative process.

Steps:

AI Seeding: The coach prompts the team to use AI tools (e.g., generative models) to produce initial idea sets based on project goals, such as "Generate 20 diverse concepts for a new user feature."
Human Divergence: Team members individually and collectively brainstorm expansions on AI outputs, adding personal insights, cultural contexts, or novel angles.
Challenge and Discard: In facilitated discussions, ideas are rigorously debated; unviable ones are discarded to refine the pool.
Synthesis and Ownership Transition: The team consolidates ideas into a preliminary list, with humans deciding final inclusions.
Coach's Responsibilities: The coach structures sessions with timed activities for focus, ensures clarity by defining success criteria (e.g., "Ideas must align with user needs"), models reliability through follow-up on commitments, and promotes authenticity by encouraging vulnerable sharing of doubts. They guide without dictating, asking questions like "What feels off about this AI suggestion?"

AI Facilitation: AI generates diverse, unbiased starting points (e.g., via prompt engineering for varied outputs), freeing humans from starting from scratch and exposing them to perspectives they might overlook. This facilitates rather than replaces initiative by providing raw material for human critique.

Methods and Methodologies Used:

Design Thinking (Empathy Mapping and Brainstorming): Employed for its human-centered approach, encouraging empathy with users and wild ideation. Why? It counters AI's potential for generic outputs by emphasizing emotional and contextual human input, building skills in divergent thinking.
** Nominal Group Technique (NGT):** For structured idea generation and voting. Why? It ensures every voice is heard, preventing dominant personalities from overshadowing, and teaches teams to challenge ideas diplomatically, fostering ownership early.
Human ownership increases here as teams move from reacting to AI seeds to actively reshaping them, learning the importance of discarding weak ideas to avoid downstream waste.

Phase 2: Backlog Refinement – Segmenting Work with AI Support, Enhancing Human Judgment
Building on ideation, this phase involves breaking ideas into actionable components, where AI helps with initial segmentation, and humans refine for feasibility and value.

Steps:

AI-Assisted Breakdown: Use AI to suggest decompositions, such as turning a broad idea into user stories or tasks (e.g., "Break this feature into epics, stories, and subtasks").
Human Refinement: Team reviews and adjusts breakdowns, incorporating domain expertise, risks, and dependencies.
Value Segmentation: Prioritize components by user impact, segmenting into "must-have" vs. "nice-to-have" based on discussions.
Iteration and Validation: Test refinements through small prototypes or feedback loops, discarding or merging as needed.
Coach's Responsibilities: The coach enforces structure with backlog templates, promotes clarity by facilitating definition-of-done criteria, ensures reliability via regular refinement sessions, and supports authenticity by validating team concerns (e.g., "It's okay to push back on AI suggestions if they don't fit our reality"). They monitor for over-reliance on AI, gently redirecting to human-led decisions.

AI Facilitation: AI analyzes complexity and suggests breakdowns using data patterns (e.g., natural language processing for task extraction), facilitating by handling rote analysis so humans can focus on nuanced judgments like ethical considerations or team capacity.

Methods and Methodologies Used:

Agile Backlog Grooming (from Scrum): Involves story mapping and refinement meetings. Why? It segments work into understandable, valuable components, reducing overwhelm and teaching teams to maintain focus on deliverables that matter.
MoSCoW Method (Must-have, Should-have, Could-have, Won't-have): For categorizing items. Why? It provides a simple, diplomatic framework for challenging and discarding ideas, ensuring resources align with value and building human responsibility in trade-offs.
Ownership grows as humans increasingly question AI breakdowns, segmenting work themselves to create a backlog that's truly theirs, emphasizing the need for understandable components to drive efficient execution.

Phase 3: Value-Based Prioritization – Human-Led Decision-Making with AI Insights, Achieving Full Ownership
The culminating phase shifts to prioritizing the refined backlog, where AI offers data-driven insights, but humans fully own choices, leading to independent methodology application.

Steps:

AI Insight Generation: Leverage AI for metrics like effort estimates or impact scoring (e.g., "Rank these items by predicted user value using historical data").
Human Evaluation: Team debates and adjusts priorities, incorporating business goals, risks, and intuition.
Consistent Prioritization: Establish and apply value criteria (e.g., ROI, user satisfaction) across items, discarding low-value ones.
Mastery Handover: Teams simulate future prioritizations without AI, with coach feedback, culminating in a human-owned methodology document.
Coach's Responsibilities: The coach reinforces structure with prioritization matrices, ensures clarity through value definition workshops, builds reliability by tracking adherence to criteria, and fosters authenticity by celebrating human insights over AI defaults. They set boundaries by phasing out AI use, expecting teams to demonstrate independence.

AI Facilitation: AI provides objective data (e.g., predictive analytics), facilitating by highlighting patterns humans might miss, but always as input for human override, ensuring initiative remains with the team.

Methods and Methodologies Used:

Kanban and Weighted Shortest Job First (WSJF): For visualizing flow and scoring priorities (cost of delay divided by job size). Why? It guides consistent value-driven prioritization, teaching teams to balance urgency and impact, which is crucial for ongoing value creation without waste.
RICE Scoring (Reach, Impact, Confidence, Effort): A quantitative framework. Why? It combines data with human judgment, allowing ideas to be challenged objectively, and reinforces responsibility by making prioritization transparent and defensible.
By this phase, humans fully own the process, having internalized the importance of challenging ideas (to innovate effectively), segmenting work (for manageability), and consistent prioritization (for reliability). This leads to authentic skillfulness, where teams create value independently, with AI as an optional ally rather than a necessity.

This process isn't rigid—adapt it to your team's pace—but commit to the progression for genuine mastery. If shortcuts are taken, such as over-relying on AI, the outcome will be superficial skills rather than true ownership. We're here to support, but the drive must come from you.









3,3
Experte
Explain WSJF methodology deeper
Agile coaching case studies
Make it more concise