Definition und Anatomie der User Story Map
User Story Mapping ist eine visuelle Technik und agile Methode, die darauf abzielt, die Produktarbeit zu organisieren und zu priorisieren1. Die Technik wurde maßgeblich durch Jeff Patton bekannt2....
1. Abgrenzung zum flachen Backlog
Die USM transformiert ein traditionelles, eindimensionales, flaches Product Backlog1..., das oft als "ein Sack voller kontextfreiem Mulch" empfunden wird27, in eine zweidimensionale Matrix3... oder eine dreidimensionale, kontextreiche "Landkarte"1....
Ein flaches Backlog ist im Wesentlichen eine "To-Do-Liste"2..., die es unmöglich macht, den "Kontext" oder das "große Ganze" (the big picture) zu sehen, sobald das Produkt skaliert2.... Die Story Map hingegen ist eine visuelle Übung, die hilft, die Arbeit zu definieren, die das ansprechendste Benutzererlebnis schafft11.
2. Die zweidimensionale Struktur
Die Struktur der Story Map basiert auf zwei Achsen, die zwei fundamentale Produktmanagement-Fragen voneinander trennen15:
1. Die Horizontale Achse (Das Backbone/Rückgrat):
    ◦ Sie dient als "narrative Klammer" des Produkts16 und bildet die chronologische Abfolge der Benutzeraktivitäten8....
    ◦ Das "Backbone" besteht aus den grobgraularen Epics oder "großen Schritten", die ein Benutzer durchführt, um sein übergeordnetes Ziel mit dem Produkt zu erreichen8....
    ◦ Die horizontale Frage lautet: "Haben wir an die gesamte Reise gedacht?"1523.
2. Die Vertikale Achse (Priorität und Detaillierung):
    ◦ Sie wird unterhalb jedes Schritts im Backbone aufgebaut und repräsentiert den Detaillierungsgrad und die Priorität15....
    ◦ Hier werden die detaillierten Teilschritte, also die eigentlichen User Stories und Aufgaben, gesammelt15....
    ◦ Die wichtigsten, für die Kernfunktion unverzichtbaren Stories (Must-haves) werden ganz oben platziert, während Stories mit geringerer Priorität oder Alternativen nach unten folgen15....
    ◦ Die vertikale Frage lautet: "Was ist der wichtigste Teil jedes Schritts?"15.
3. Fokus und Abgrenzung
Das Story Mapping fokussiert sich auf die Funktionalität des Produkts und die Schritte, die Nutzer durchlaufen9.... Im Gegensatz dazu fokussiert sich die User Journey Map (UJM) auf die Emotionen, Schmerzpunkte und das Erlebnis des Benutzers8.... Idealerweise dient die UJM als Input, um die Probleme zu diagnostizieren, für die das USM die Lösung plant27.

--------------------------------------------------------------------------------
II. Nutzen und Vorteile (Der Wert der Methode)
Der Nutzen von User Story Mapping liegt nicht primär im fertigen Artefakt, sondern im kollaborativen Prozess seiner Erstellung3132.
1. Schaffung eines gemeinsamen Verständnisses (Shared Understanding)
Das ultimative Ziel des Mapping-Prozesses ist die Konversation und das gemeinsame Verständnis im Team7.... Die Erstellung der Map ist eine "kuratierte Konversation"31..., die darauf abzielt, das Wissen aller Beteiligten zu kollektivieren31. Die USM muss Business (Warum?), UX (Für wen?) und Entwicklung (Wie?) an einen Tisch bringen38....
2. Nutzerzentrierung und Wertlieferung
Die Methode ist fundamental benutzerzentriert7.... Eine Story Map beantwortet die Kernfragen: "Warum bauen wir das?", "Für wen?" und "Welchen Nutzen liefert es?"6....
Der kognitive Wandel, den die USM erzwingt, führt von einer "Feature-Fabrik"-Mentalität zu einer "Value-Delivery"-Mentalität11. Die zentrale Frage verschiebt sich von "Was bauen wir als Nächstes?" zu "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"11.
3. Planung von Releases und MVP-Definition
Die Story Map ist ein essenzielles Werkzeug, um MVPs zu definieren und Releases zu planen3....
• Slicing: Die vertikal priorisierte Map wird horizontal "geschnitten" (Slicing)22..., wobei jede Scheibe ein geplantes Release repräsentiert47.
• Walking Skeleton: Der erste und wichtigste Schnitt definiert das MVP4749. Ein durch USM definiertes MVP ist nicht nur eine Liste der wichtigsten Features, sondern der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt50. Dieses Ergebnis wird als "Walking Skeleton" (laufendes Skelett) bezeichnet37.... Das Ziel ist ein Complete Product Experience (CPE), das minimale Versionen aller notwendigen Schritte der User Journey enthält50.
4. Risikominimierung und Kontinuität
• Lückenidentifikation: Das zweidimensionale Layout hilft Teams, Lücken und fehlende Funktionalitäten visuell und intuitiv zu erkennen7.... Indem das Team die gesamte Reise narrativ abschreitet, werden Lücken, Engpässe und Abhängigkeiten aufgedeckt, die in einem flachen Backlog oft übersehen werden23....
• Risikomanagement: Die Story Map ist ein Mechanismus zur Risikominimierung33. Risikonotizen können genutzt werden, um unsichere Annahmen oder externe Abhängigkeiten sichtbar zu machen36....
• Lebendiges Dokument: Die Map sollte nicht nach dem initialen Workshop weggeworfen werden ("Wegwerf-Map" ist ein häufiger Fehler59), sondern als "lebendiges, atmendes Ding"60 gepflegt werden36.... Sie dient als zentrale visuelle Produkt-Roadmap61 und wird als Frontend für das kontinuierliche Backlog Grooming genutzt38....
Zusammenfassend kann man sagen, dass das User Story Mapping wie eine architektonische Blaupause für ein Haus wirkt: Es liefert nicht nur eine Liste aller benötigten Baumaterialien (die Stories), sondern auch einen Grundriss (das Backbone), der zeigt, wie man von der Haustür zur Küche gelangt, und gleichzeitig die Möglichkeit bietet, klar zu definieren, welche minimalen Räume (das MVP) fertiggestellt werden müssen, bevor das Haus nutzbar ist, während der Rest der Innenausstattung für spätere Bauphasen (Releases) priorisiert wird.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Definition & Nutzen“ über „Kernkonzept“ aussagen.

Die Quellen definieren das Kernkonzept des User Story Mapping (USM) als eine leistungsstarke, zweidimensionale, visuelle Methode zur Organisation von Produktarbeit im agilen Projektmanagement und beschreiben deren Nutzen hauptsächlich in der Schaffung von Kontext, der Nutzerzentrierung und der Planung funktional vollständiger Releases1....
Das Kernkonzept von User Story Mapping unterscheidet sich fundamental vom traditionellen, flachen Produkt-Backlog, das oft als "Sack voller kontextfreiem Mulch" beschrieben wird27.

--------------------------------------------------------------------------------
Definition des Kernkonzepts: Die zweidimensionale Struktur
Das Kernkonzept der User Story Map liegt in ihrer zweidimensionalen Matrixstruktur2..., die ein eindimensionales Backlog in eine kontextreiche „Landkarte“ umwandelt1.... Diese Struktur basiert auf zwei Achsen, die zwei fundamentale Produktmanagement-Fragen trennen11:
1. Die horizontale Achse: Das Backbone (Vollständigkeit)
• Definition: Die horizontale Achse bildet das „Backbone“ (Rückgrat) des Produkts12.... Sie fungiert als die narrative Klammer12 und zeigt die wichtigsten Aktivitäten oder Themen des Nutzers in chronologischer Reihenfolge von links nach rechts12....
• Bestandteile: Das Backbone besteht aus grobgranularen Epics oder Benutzeraktivitäten (User Activities), die in ihrer Gesamtheit eine vereinfachte, aber vollständige Darstellung der User Journey bilden12....
• Nutzen (Die horizontale Frage): Durch die chronologische Anordnung ermöglicht die Map die Prüfung auf Vollständigkeit11. Die Story Map zwingt das Team, zuerst die gesamte Reise horizontal abzubilden24. Dies macht Lücken (gaps) und fehlende Funktionalitäten sofort visuell ersichtlich2....
2. Die vertikale Achse: Priorität und Detaillierung (Wichtigkeit)
• Definition: Die vertikale Achse unterhalb jedes Backbone-Schritts enthält die detaillierten Teilschritte, also die eigentlichen User Stories und Aufgaben11....
• Struktur: Diese Anordnung repräsentiert den Prioritäts- und Detaillierungsgrad11.... Die wichtigsten, für die Kernfunktion unverzichtbaren Stories (Must-haves) werden direkt unter dem Backbone-Schritt platziert (ganz oben in der Spalte)11.... Alternativen, „Nice-to-have“-Funktionen oder Stories mit geringerer Priorität folgen darunter1118.
• Leserichtung: Beim Lesen nach unten wird das Wort „oder“ (or) mental eingefügt, da die vertikale Dimension Alternativen oder verschiedene Wege zur Erfüllung eines Ziels aufzeigt18.
• Nutzen (Die vertikale Frage): Hierdurch wird die Wichtigkeit jedes Schritts geklärt11. Im Gegensatz zu einem flachen Backlog, wo Stories unterschiedlicher Wichtigkeit direkt konkurrieren, wird bei der Map erst horizontal die Reise abgebildet und dann vertikal priorisiert24.

--------------------------------------------------------------------------------
Nutzen: Der Wandel von der Liste zur Landkarte
Der Nutzen der Story Map liegt nicht nur in der besseren Visualisierung, sondern in einem Paradigmenwechsel in der Produktentwicklung2.
1. Fokus auf Nutzerzentrierung und Wertlieferung
• Die Story Map beantwortet die grundlegenden Fragen: „Warum bauen wir das?“, „Für wen?“ und „Welchen Nutzen liefert es?“6....
• Der Fokus verschiebt sich von der Verwaltung von Arbeit (Work Planning) zur Erzeugung eines geteilten Verständnisses (Shared Understanding)2.
• Ein flaches Backlog fördert eine „Feature-Fabrik“-Mentalität28. Die Story Map erzwingt hingegen eine „Value-Delivery“-Mentalität28. Die zentrale Frage lautet nicht mehr „Was bauen wir als Nächstes?“, sondern „Welches Problem des Nutzers lösen wir als Nächstes vollständig?“28.
• Die Map wird stets aus der Perspektive des Benutzers (Persona) erstellt, um die Arbeit fest im Kontext der gesamten Customer Journey zu verankern28....
2. Ermöglichung der Release-Planung (Slicing und MVP)
• Die Story Map ist das zentrale Werkzeug für die Release-Planung durch das sogenannte „Slicing“ (Zerschneiden)2....
• Das MVP wird durch einen horizontalen „Slice“ definiert, der nicht nur die wichtigsten Features auflistet, sondern den dünnsten, aber funktional vollständigen End-to-End-Weg durch das Produkt darstellt3236.
• Dieses Ergebnis wird als „Walking Skeleton“ (laufendes Skelett) bezeichnet – eine minimale, aber durchgängig funktionsfähige Version des gesamten Systems, die mindestens eine Story aus jedem kritischen Backbone-Schritt enthalten muss34.... Nachfolgende Releases („Slices“) fügen diesem Skelett mehr „Fleisch“ hinzu42.
3. Kollaboration und Gemeinsames Verständnis
• Der wahre Wert der Methode liegt im kollaborativen Prozess ihrer Erstellung – dem Story Mapping Workshop29. Dieser Workshop ist eine „kuratierte Konversation“29..., die das Wissen aller Beteiligten (Business, UX, Entwicklung) kollektiviert29....
• Das gemeinsame Abwandern der Map entlang der narrativen Achse hilft dem Team, Lücken und Abhängigkeiten aufzudecken, die sonst übersehen würden4345. In diesem Moment wird das „Shared Understanding“ geschaffen4346.

--------------------------------------------------------------------------------
Zusammenfassend kann man sagen, dass das Kernkonzept des Story Mapping wie ein GPS für die Produktentwicklung ist: Es verwandelt eine unübersichtliche Liste von Straßennamen (flaches Backlog) in eine klare Landkarte (Story Map) mit einer Route (Backbone), die nicht nur den Zielort definiert, sondern auch die notwendigen Etappen (horizontale Achse) und die Priorität der Straßenqualität (vertikale Achse), um sicherzustellen, dass man das Ziel auf dem minimal funktionsfähigen Weg erreicht (MVP-Slice).

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Kernkonzept“ über „Visuelle Technik zur Produktorganisation“ aussagen.

Die Quellen beschreiben die User Story Map (USM) als die zentrale Visuelle Technik zur Produktorganisation1 und beleuchten deren Kernkonzept im Vergleich zu traditionellen Ansätzen1....
Das Kernkonzept der User Story Map lässt sich primär als ein Paradigmenwechsel von einer eindimensionalen Liste zu einer zweidimensionalen, kontextreichen Landkarte zusammenfassen1....
1. Der Wandel vom flachen Backlog zur kontextreichen Landkarte
Das Kernproblem, das durch diese visuelle Technik gelöst wird, ist die Kontextfreiheit traditioneller, flacher Product Backlogs2.... Ein flaches Backlog, oft als "To-Do-Liste" oder "Sack voller kontextfreiem Mulch" beschrieben, wird bei skalierenden Produkten überwältigend und verhindert, dass Teams das "große Ganze" (The Big Picture) sehen können2....
Die Story Map hingegen ist eine zweidimensionale Matrix5... und wandelt die flache Liste in eine dreidimensionale Ansicht um, die jede einzelne User Story fest im Kontext der gesamten Customer Journey verankert4....
Dieser Wandel ist nicht nur administrativ, sondern vor allem kognitiv17. Das Kernkonzept erzwingt einen Fokuswechsel2...:
• Vom Feature zur Wertlieferung: Ein flaches Backlog fördert eine "Feature-Fabrik"-Mentalität17. Die Story Map erzwingt stattdessen eine "Value-Delivery"-Mentalität17.
• Die zentrale Frage verschiebt sich von "Was bauen wir als Nächstes?" zu "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"17. Das Ziel der Map ist in erster Linie die Schaffung eines geteilten Verständnisses (Shared Understanding) im Team5....
2. Die Anatomie als Kern des visuellen Konzepts
Das Kernkonzept der visuellen Organisation basiert auf der Trennung von zwei fundamentalen Produktmanagement-Fragen durch die zwei Achsen25:
A. Die horizontale Achse: Die Vollständigkeitsfrage
Die horizontale Achse bildet das "Backbone" (Rückgrat) des Produkts26.... Dies ist die narrative Klammer des Produkts2633 und stellt die chronologische Reihenfolge der "großen Schritte" oder Benutzeraktivitäten (User Activities) dar, die ein Benutzer durchführt, um sein Ziel zu erreichen26....
• Der Fokus liegt auf der User Journey: Das Backbone liefert eine vereinfachte, aber vollständige Darstellung der User Journey26.
• Die horizontale Frage lautet: "Haben wir an die gesamte Reise gedacht?"25.
• Die Stories in dieser Achse sind typischerweise grobgranulare Epics oder Themen26....
B. Die vertikale Achse: Die Wichtigkeits- und Detaillierungsfrage
Unterhalb jedes Schritts im Backbone wird die vertikale Achse aufgebaut25. Diese Achse repräsentiert den Detaillierungsgrad und die Priorität25....
• Priorisierung: Die wichtigsten Stories, die für die Kernfunktion unverzichtbar sind ("Must-haves"), werden ganz oben platziert25.... Stories mit geringerer Priorität, Alternativen oder "Nice-to-have"-Funktionen folgen darunter25....
• Alternativen: Die vertikale Anordnung zeigt auch alternative Lösungswege oder Möglichkeiten auf2535. Man liest diese Achse, indem man mental das Wort "oder" zwischen den Karten einfügt35.
• Die vertikale Frage lautet: "Was ist der wichtigste Teil jedes Schritts?"25.
3. Der organisatorische Nutzen (Slicing und Lückenidentifikation)
Der größte Vorteil der visuellen Technik zur Produktorganisation liegt darin, dass sie die Simultanplanung der gesamten Reise (horizontal) und die Priorisierung jedes einzelnen Schritts (vertikal) ermöglicht25.
1. Lückenidentifikation: Die zweidimensionale Ansicht macht Lücken (gaps) und fehlende Funktionalitäten sofort visuell ersichtlich5.... Dies geschieht oft, indem das Team die Story Map narrativ von links nach rechts "abwandert" und dabei Engpässe und fehlende Schritte aufdeckt20.
2. Release-Planung (Slicing): Die fertige, vertikal priorisierte Map wird durch das "Slicing" (horizontales Schneiden) in Releases oder Iterationen unterteilt5....
3. Definition des MVP: Das Kernkonzept des Slicing definiert das Minimum Viable Product (MVP) neu43. Das MVP ist nicht nur eine Liste der wichtigsten Features, sondern der dünnste, aber funktional vollständige End-to-End-Weg durch das gesamte Produkt22.... Dieses Ergebnis wird oft als "Walking Skeleton" (laufendes Skelett) bezeichnet – eine minimale, aber durchgängig funktionsfähige Version des Systems22....
Zusammenfassend ist das Kernkonzept der visuellen Technik (USM) zur Produktorganisation, das flache Backlog durch eine Landkarte zu ersetzen, die den Kontext der Nutzerreise (horizontal) mit der Priorität und Detaillierung der Arbeitspakete (vertikal) verknüpft, um ein geteiltes Verständnis zu schaffen und eine nutzerzentrierte, vollständige minimale Produktversion (MVP) zu definieren1....

--------------------------------------------------------------------------------
Man könnte die User Story Map metaphorisch als eine Bergsteigerkarte betrachten, während das flache Backlog eine lange Einkaufsliste ist. Die Einkaufsliste mag die Zutaten (die Stories) auflisten und priorisieren (das Wichtigste zuerst), aber sie verrät nichts darüber, warum man sie braucht oder in welcher Reihenfolge man sie verwenden muss, um eine vollständige Mahlzeit zuzubereiten45. Die Bergsteigerkarte (Story Map) hingegen zeigt den gesamten Weg (Backbone) von der Basis bis zum Gipfel chronologisch auf. Sie zeigt, welche Ausrüstung (Stories) an welchem Abschnitt (vertikale Priorität) notwendig ist. Durch horizontales "Slicing" kann man entscheiden, ob man in der ersten Expedition nur das Basislager (MVP/Walking Skeleton) oder den kompletten Gipfel erreicht.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Kernkonzept“ über „Wandelt flaches Backlog in 2D/3D 'Landkarte'“ aussagen.

Die Transformation des flachen Backlogs in eine zwei- oder dreidimensionale „Landkarte“ ist das Kernkonzept der User Story Mapping (USM) Methode12. Diese Transformation zielt darauf ab, die fundamentalen Mängel traditioneller Backlogs zu beheben, indem sie Kontext, Übersicht und Benutzerzentrierung herstellt1....
Hier ist eine detaillierte Diskussion, was die Quellen über diesen Kernwandel aussagen:
1. Das Problem des flachen Backlogs
Das Story Mapping wurde entwickelt, weil einfache (flache) Backlogs den Gesamtzusammenhang (the big picture) nicht sichtbar machen3....
• Eindimensionale Liste: Das traditionelle Product Backlog wird als eine eindimensionale, flache Liste1... oder im Wesentlichen als eine "To-Do-Liste" beschrieben37.
• Mangelnder Kontext: Das fundamentale Problem liegt in dieser Struktur1. Sobald ein Produkt skaliert und Hunderte von Einträgen umfasst, wird das Backlog überwältigend3. Es liefert keine Übersicht über Zusammenhänge und zeigt weder die Reihenfolge, in der Nutzer durch das Produkt navigieren, noch den Kontext der einzelnen Aufgaben3....
• Der "Sack voller Mulch": Jeff Patton, eine Schlüsselfigur der Methode, beschreibt ein solches Backlog treffend als "einen Sack voller kontextfreiem Mulch"3....
• Priorisierungsproblem: Das flache Backlog kann die Fragen der Vollständigkeit und Wichtigkeit nicht trennen14. Dort konkurriert beispielsweise eine wichtige Story für den Bezahlvorgang direkt mit einer weniger wichtigen Story für die Passwort-Wiederherstellung15.
2. Die Transformation zur 2D/3D-Landkarte
Die User Story Map setzt genau hier an, indem sie eine visuelle Technik nutzt, um diese flache Liste in eine räumliche Darstellung zu überführen1....
• Der visuelle Wandel: Im Kern verwandelt die USM das Backlog von einer eindimensionalen, flachen Liste in eine zweidimensionale, kontextreiche "Landkarte"17. Diese Darstellung wird auch als zweidimensionale Matrix (horizontal & vertikal)7 oder sogar als dreidimensionale Ansicht beschrieben2. Die Methode kombiniert die Klarheit einer Liste mit dem Kontext eines visuellen "Boards"4....
• Kontextreich: Diese Darstellung verankert jede einzelne User Story fest im Kontext der gesamten Customer Journey27. Die Map fungiert als visuelles Frontend für das gesamte Product Backlog17.
3. Die Struktur der Landkarte: Zwei Dimensionen
Die Quellen erklären detailliert, wie die zwei Achsen der Story Map den Kontext liefern7....
A. Die horizontale Achse: Der narrative Fluss (Sequenz)
Die horizontale Achse bildet das "Backbone" (Rückgrat) des Produkts7.... Sie ist die narrative Klammer und wird von links nach rechts in chronologischer Reihenfolge angeordnet7....
• Inhalt: Das Backbone besteht aus den grobgranularen "großen Schritten", "Benutzeraktivitäten" (User Activities) oder "Themen"11..., die der Benutzer durchführt, um sein übergeordnetes Ziel zu erreichen13.
• Leserichtung: Man liest über die Map hinweg, indem man mental das Wort "dann" (then) zwischen die Schritte einfügt, um die Sequenz darzustellen2226.
• Die Frage der Vollständigkeit: Die horizontale Achse beantwortet die Frage: "Haben wir an die gesamte Reise gedacht?"714. Dieser Prozess erzwingt die Abbildung der gesamten Reise zuerst, wodurch Lücken (gaps) und fehlende Funktionalitäten (z. B. eine vergessene Passwort-Wiederherstellung) sofort visuell ersichtlich werden15....
B. Die vertikale Achse: Priorität und Detaillierung (Alternativen)
Die vertikale Achse wird unterhalb jedes Backbone-Schritts aufgebaut14 und repräsentiert die Priorität und den Detaillierungsgrad14....
• Inhalt: Hier werden die detaillierten Teilschritte, die eigentlichen User Stories und Aufgaben, gesammelt14. Die Detailtiefe nimmt nach unten zu21....
• Priorisierung: Die Stories, die für die Kernfunktion unverzichtbar sind ("Must-haves"), werden direkt unter dem Backbone-Schritt platziert (ganz oben in der Spalte)14.... Stories mit geringerer Priorität, alternative Lösungswege oder "Nice-to-have"-Funktionen folgen darunter1419.
• Leserichtung: Man liest die vertikale Achse hinunter, indem man mental das Wort "oder" (or) zwischen die Karten einfügt, da sie Alternativen zeigen22.
• Die Frage der Wichtigkeit: Die vertikale Achse beantwortet die Frage: "Was ist der wichtigste Teil jedes Schritts?"714.
4. Der kognitive und strategische Wandel
Der Wandel vom flachen Backlog zur Story Map ist primär kognitiv2.
• Mentalitätswandel: Während ein flaches Backlog eine "Feature-Fabrik"-Mentalität fördert, bei der Tickets abgearbeitet werden, erzwingt eine Story Map eine "Value-Delivery"-Mentalität27.
• Fokusverschiebung: Die zentrale Frage verschiebt sich von dem Feature-basierten Fokus ("Was bauen wir als Nächstes?") zu einem Benutzer-basierten Fokus ("Welches Problem des Nutzers lösen wir als Nächstes vollständig?")27.
• Roadmap-Erstellung: Durch das anschließende horizontale "Slicing" (Schneiden) der vertikal priorisierten Map wird die Landkarte direkt in eine umsetzbare Release-Planung oder Produkt-Roadmap verwandelt7.... Die oberste horizontale Scheibe (Slice) definiert das Minimum Viable Product (MVP) als den dünnsten, aber funktional vollständigen End-to-End-Weg durch das Produkt, oft als "Walking Skeleton" bezeichnet33....
Die Story Map ist somit die visuelle Ergänzung des Backlogs839. Sie schafft ein gemeinsames Verständnis (Shared Understanding) im Team7... und erleichtert die Priorisierung durch die klare Trennung von Vollständigkeit (horizontal) und Wichtigkeit (vertikal)14.

--------------------------------------------------------------------------------
Analogie: Die Umwandlung des flachen Backlogs in die User Story Map ist vergleichbar mit dem Wechsel von einer unendlichen Einkaufsliste zu einem modernen Navigationssystem. Die Liste mag die wichtigsten Zutaten (Stories) nennen, aber sie sagt Ihnen nicht, in welcher Reihenfolge Sie die Gänge des Supermarkts (Backbone) durchqueren müssen, noch zeigt sie Ihnen, welche Alternativen es für jedes Produkt gibt. Die Story Map bietet hingegen die vollständige Route (horizontal) und die Priorität an jeder Station (vertikal), sodass Sie zielgerichtet das minimal verwertbare Gericht (MVP) zubereiten können, anstatt nur einen Sack zufälliger, kontextfreier Zutaten zu besitzen.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Kernkonzept“ über „Fokus auf Benutzererlebnis (Customer Journey)“ aussagen.

Das Kernkonzept der User Story Map (USM) ist untrennbar mit dem Fokus auf das Benutzererlebnis (Customer Journey) verbunden1. Die Quellen beschreiben diesen Fokus als den fundamentalen Wandel weg von einer einfachen Aufgabenliste hin zu einer kontextreichen Planungsmethode2....
1. Das Benutzererlebnis als Kernkonzept der USM
Die User Story Map (USM) ist eine visuelle Technik aus dem agilen Projektmanagement, die Produktarbeit organisiert und priorisiert2.... Im Gegensatz zu einem traditionellen, flachen Backlog, das oft als "Sack voller kontextfreiem Mulch" empfunden wird34, verwandelt die USM die Anforderungen in eine zweidimensionale, kontextreiche "Landkarte"24.
Der Fokus auf die Customer Journey bewirkt einen entscheidenden Paradigmenwechsel:
1. Vom Feature zur Lösung: Ein flaches Backlog fördert eine "Feature-Fabrik"-Mentalität, während eine Story Map eine "Value-Delivery"-Mentalität erzwingt1. Die zentrale Frage verschiebt sich von "Was bauen wir als Nächstes?" zu "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"14.
2. Verankerung im Kontext: Die visuelle Darstellung der USM wandelt die flache Liste in eine dreidimensionale Ansicht um1. Diese Darstellung verankert jede einzelne User Story fest im Kontext der gesamten Customer Journey1.
2. Die User Journey als Struktur (Die Horizontale Achse)
Die Customer Journey ist das strukturelle Rückgrat (Backbone) der Story Map:
• Das Backbone: Die horizontale Achse der Story Map bildet das "Backbone" (Rückgrat)8.... Dieses Backbone fungiert als die narrative Klammer des Produkts und wird von links nach rechts in chronologischer Reihenfolge der Benutzerinteraktion angeordnet8....
• Aktivitäten des Nutzers: Das Backbone setzt sich aus den "großen Schritten"8 oder Benutzeraktivitäten (User Activities)8... zusammen, die ein Benutzer durchführen muss, um sein übergeordnetes Ziel mit dem Produkt zu erreichen8....
• Vollständige Abbildung: In ihrer Gesamtheit bieten diese Aktivitäten eine vereinfachte, aber vollständige Darstellung der User Journey8. Beispielsweise könnte das Backbone für einen Online-Shop lauten: "Produkte erkunden" → "Produkte vergleichen/auswählen" → "Zur Kasse gehen/Bezahlen" → "Bestellung verfolgen/empfangen"8....
Die Story Map zwingt das Team, zuerst die gesamte Reise horizontal abzubilden20. Dies beantwortet die horizontale Frage der USM: "Haben wir an die gesamte Reise gedacht?" (Vollständigkeit)21. Lücken (gaps) oder fehlende Funktionalitäten, die für eine durchgängige Benutzererfahrung notwendig sind (z.B. eine vergessene Passwort-Wiederherstellung), werden durch diesen prozessualen Fokus sofort visuell ersichtlich20....
3. Benutzerzentrierung und Personas
Der Fokus auf den Benutzer ist ein grundlegendes Ziel der Story-Mapping-Methode5...:
• Perspektive: Die Map wird explizit aus der Perspektive des Benutzers erstellt26.... Die Story Map ist benutzerzentriert27..., im Gegensatz zum Process Mapping, das unternehmenszentriert ist und interne Workflows beschreibt32.
• Persona-Definition: Die Definition von Personas (fiktive Nutzerprofile mit Zielen und Problemen) ist unerlässlich, da die Map von deren Zielen und Aktivitäten abgeleitet wird14.... Es ist eine Best Practice, sich anfangs auf eine primäre Persona zu fokussieren, um die Komplexität zu reduzieren33. Fortgeschrittene Teams können später spezifische Stories für weitere Personas in horizontalen Zeilen (Swimlanes) hinzufügen36.
4. Der Einfluss auf die MVP-Definition
Der ganzheitliche Blick auf die Customer Journey ist entscheidend für die Priorisierung und die Definition des Minimum Viable Product (MVP)5...:
• Der "Walking Skeleton": Die Release-Planung durch "Slicing" (horizontales Schneiden)37 stellt sicher, dass das resultierende MVP nicht nur eine Sammlung der wichtigsten Features ist38. Stattdessen definiert es den dünnsten, aber funktional vollständigen End-to-End-Weg durch das Produkt38.
• Dieses Ergebnis, der "Walking Skeleton" (laufendes Skelett)30..., garantiert eine Complete Product Experience (CPE) oder zumindest eine durchgehende Benutzererfahrung38.
• Um eine vollständige Journey zu gewährleisten, muss der MVP-Slice mindestens eine Story aus jedem kritischen Backbone-Schritt enthalten38. Dadurch wird verhindert, dass wichtige Schritte der Customer Journey (z.B. die Bestellung verfolgen) im ersten Release fehlen, obwohl der Rest der Kaufabwicklung implementiert ist1638.
5. Abgrenzung zur Customer Journey Map (UJM)
Obwohl die Story Map (USM) auf der Customer Journey basiert, ist sie nicht identisch mit einer User Journey Map (UJM)10...:
Dimension
User Story Map (USM)
User Journey Map (UJM)
Fokus
Funktionalität & Features4548
Emotionen & Erlebnis, Schmerzpunkte (Pain Points)10...
Ziel
Produkt-Planung, Backlog-Strukturierung45...
Empathie-Aufbau, Problem-Discovery4548
Perspektive
Benutzer (als Akteur – Was macht er?)48
Benutzer/Persona (als fühlendes Wesen – Was fühlt er?)48
Die Quellen betonen, dass die Methoden idealerweise sequenziell angewendet werden: Die UJM diagnostiziert Probleme und baut Empathie auf10..., während die USM diese emotionalen Erkenntnisse in umsetzbare Arbeitspakete (Stories) übersetzt und die technische Lösung plant18....
Zusammenfassend lässt sich sagen, dass der "Fokus auf das Benutzererlebnis" das Herzstück des User Story Mapping ist18. Er transformiert das agile Planning-Artefakt von einer bloßen Liste von Dingen, die gebaut werden sollen, hin zu einem narrativen Plan zur Schaffung einer vollständigen, durchgängigen Produkterfahrung für den Benutzer8....

--------------------------------------------------------------------------------
Man könnte die User Story Map als den GPS-Führer des Produktteams betrachten: Das Backbone ist die chronologische Route, die der Benutzer nehmen muss, um sein Ziel zu erreichen (die Customer Journey). Die vertikale Priorisierung sind die verschiedenen Wege und Fahrzeuge (Features) entlang dieser Route. Der MVP-Slice ist die kürzeste, aber funktional vollständige Fahrt von Start bis Ziel, die sicherstellt, dass der Benutzer niemals auf halbem Weg stehen bleibt.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Kernkonzept“ über „Förderung einer 'Value-Delivery'-Mentalität“ aussagen.

Die Quellen beschreiben die Förderung einer "Value-Delivery"-Mentalität als eines der zentralen Ziele und Kernkonzepte des User Story Mapping (USM)1. Diese Mentalität stellt einen fundamentalen kognitiven Wandel dar, der durch die zweidimensionale Struktur der Story Map erzwungen wird1.
Hier ist eine Diskussion, wie die Quellen dieses Kernkonzept beleuchten:
1. Der Paradigmenwechsel: Von der "Feature-Fabrik" zur "Value-Delivery"
Der Hauptbeitrag des Story Mapping liegt in der Überwindung der Mängel traditioneller, eindimensionaler Produkt-Backlogs2....
• Das Problem des flachen Backlogs: Ein traditionelles, flaches Backlog ist im Wesentlichen eine "To-Do-Liste"1. Es ist kontextfrei, überwältigend und unüberschaubar, sobald das Produkt skaliert3. Dieses Format wird treffend als "einen Sack voller kontextfreiem Mulch" beschrieben34. In der Praxis führt dies dazu, dass Teams oft das auswählen, was am einfachsten oder interessantesten ist, anstatt das, was den höchsten Kundennutzen liefert3.
• Die alte Mentalität: Ein flaches Backlog fördert zwangsläufig eine "Feature-Fabrik"-Mentalität ("Feature-Factory"-Mentalität), bei der es primär darum geht, Tickets abzuarbeiten ("Was bauen wir als Nächstes?")14.
• Die neue Mentalität: Im Gegensatz dazu erzwingt die Story Map eine "Value-Delivery"-Mentalität1. Die zentrale Frage verschiebt sich von "Was bauen wir als Nächstes?" zu "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"2. Die Story Map hilft, die Anforderungen aus Kundensicht zu ordnen und beantwortet die Fragen Warum bauen wir das?, Für wen? und Welchen Nutzen liefert es?7....
2. Mechanismus der Wertlieferung durch die 2D-Struktur
Die physische Anordnung der Story Map ist der Mechanismus, der diese Wertorientierung in den Fokus rückt10....
• Verankerung im Kontext: Die Story Map wandelt die flache Liste in eine zweidimensionale (oder dreidimensionale) Ansicht um, die jede User Story fest im Kontext der gesamten Customer Journey verankert12.
• Fokus auf den Nutzen (Vertikale Achse): Die vertikale Achse der Story Map repräsentiert Priorität und Detaillierungsgrad10.... Die wichtigste Frage, die durch diese vertikale Anordnung beantwortet wird (Wichtigkeit), ist: "Welche Story in dieser Spalte liefert den meisten Wert?"10.
• Priorisierung nach Wert: Die Story Map erlaubt es Teams, Lücken zu identifizieren und Stories nach Nutzen zu priorisieren11.... Die Stories, die für die Kernfunktion unverzichtbar sind ("Must-haves"), werden ganz oben in der Spalte platziert217. Die Wichtigkeit wird dabei aus einer Kombination von Nutzen, Risiko und technischem Aufwand abgeleitet1819. Frameworks wie der "Value vs. Complexity Quadrant" oder WSJF (Weighted Shortest Job First) werden im Story Mapping angewendet, um den ökonomischen Wertfluss zu optimieren20.
3. Sicherstellung der vollständigen Wertlieferung (Slicing)
Die "Value-Delivery"-Mentalität manifestiert sich am deutlichsten in der Definition des Minimum Viable Product (MVP) durch das sogenannte "Slicing" (in Scheiben schneiden)21.
• Vollständige End-to-End-Erfahrung: Das durch Slicing definierte MVP ist nicht einfach eine Liste der fünf wichtigsten Features22. Stattdessen ist es der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt22. Dieses Ergebnis wird auch als "Walking Skeleton" (laufendes Skelett) bezeichnet – eine minimale, aber durchgängig funktionsfähige Version des gesamten Systems18....
• Erzwungene Lückenprüfung: Die Story Map erzwingt, dass der MVP-Slice eine minimale Version aller notwendigen Schritte (Aktivitäten im Backbone) enthält, wodurch eine "Complete Product Experience" (CPE) geliefert wird222. Dies verhindert den Fehler eines flachen Backlogs, bei dem wichtige, aber vermeintlich unwichtige Schritte (wie die Passwort-Wiederherstellung) vergessen werden, während sich das Team auf andere, leichter zu liefernde Features konzentriert2227. Die Priorisierung zielt auf das minimal Nützliche ab2829.
4. Der Workshop als Mittel zur Konsensbildung
Die Story Map ist kein reines Artefakt, sondern ein diskursives Werkzeug, dessen wahrer Wert durch den kollaborativen Workshop entsteht – eine "kuratierte Konversation"30....
• Geteiltes Verständnis (Shared Understanding): Das ultimative Ziel des Mapping-Prozesses ist die Konversation und das gemeinsame Verständnis im Team3135. Das funktionsübergreifende Team (Business, UX, Entwicklung) muss anwesend sein4.... Die Entwickler müssen technische Abhängigkeiten und Anforderungen einbringen, damit die Map nicht zu einer reinen "Wunschliste" wird3839.
• Fokus auf Nutzerwert: Durch die Einbindung aller relevanten Rollen wird sichergestellt, dass der Fokus auf dem Nutzen für den Benutzer liegt28.... Der Story Mapping Workshop beginnt mit der Definition der Persona und dem Problem-Framing, was das Team direkt auf die Frage "Welches Problem lösen wir? Für wen?" einstimmt7....
• Erfolgsmessung: Die "Value-Delivery"-Mentalität wird durch die Aufforderung unterstützt, für jede Release-Slice Ziele ("Outcome") und Metriken festzulegen, um den gelieferten Nutzen zu überprüfen6....
Zusammenfassend lässt sich sagen, dass die Story Map im Kern ein kognitives Werkzeug1 ist, das durch seine zweidimensionale Struktur (chronologische Journey horizontal, Wertpriorisierung vertikal) die Produktplanung weg von der reinen Feature-Abarbeitung hin zur kontinuierlichen und vollständigen Lieferung von Nutzerwert lenkt1....

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Definition & Nutzen“ über „Vorteile gegenüber Flachem Backlog“ aussagen.

Die Story Map wurde entwickelt, weil einfache Backlogs den Gesamtzusammenhang (the big picture) nicht sichtbar machen1.... Die Quellen legen klar dar, dass die Vorteile der User Story Map (USM) gegenüber dem flachen Backlog direkt aus ihrer zweidimensionalen Definition und dem daraus resultierenden Nutzen für Kontext, Priorisierung und gemeinsames Verständnis entstehen1....
Im Kontext von „Definition & Nutzen“ lassen sich die Vorteile der User Story Map gegenüber einem flachen Backlog wie folgt diskutieren:
1. Überwindung der Kontextarmut und der Unübersichtlichkeit
Das fundamentale Problem eines traditionellen, flachen Backlogs liegt in seiner eindimensionalen Struktur45.
• Definition der Schwäche: Ein flaches Backlog ist im Grunde eine lineare, eindimensionale "To-Do-Liste"5.... Sobald ein Produkt skaliert und Hunderte von Einträgen umfasst, wird diese Liste überwältigend und unüberschaubar8.
• Fehlender Kontext: Es ist unmöglich, das „große Ganze“ (the big picture) zu sehen oder den Kontext der einzelnen Aufgaben zu verstehen8. Jeff Patton beschreibt ein solches Backlog treffend als einen „Sack voller kontextfreiem Mulch“5.... Diese Kontextarmut führt in der Praxis oft dazu, dass Teams Aufgaben auswählen, die am einfachsten oder interessantesten sind, anstatt diejenigen, die den höchsten Kundennutzen liefern8.
• Story Map als Lösung (Definition & Nutzen): Die Story Map transformiert die eindimensionale Liste in eine zweidimensionale Matrix (horizontal und vertikal)1... oder eine kontextreiche "Landkarte"45. Diese Darstellung verankert jede einzelne User Story fest im Kontext der gesamten Customer Journey17.
2. Trennung von Vollständigkeit und Wichtigkeit (Fokus auf den Nutzerwert)
Die zweidimensionale Struktur der Story Map ist ihr entscheidender Vorteil, da sie zwei fundamentale Produktmanagement-Fragen trennt, die in flachen Backlogs oft vermischt werden18:
Kriterium
Flaches Product Backlog
User Story Map
Fokus
Feature-basiert (Was wird gebaut?)5
Benutzer-basiert (Welches Problem wird gelöst?)1...
Primäres Ziel
Arbeitsverwaltung (Work planning)5
Geteiltes Verständnis (Shared Understanding)5...
Mentalität
"Feature-Fabrik"-Mentalität (Tickets abarbeiten)17
"Value-Delivery"-Mentalität (Nutzerprobleme vollständig lösen)17
• Fehlgeleitete Priorisierung im Flachen Backlog: Ein flaches Backlog priorisiert linear, oft eindimensional (z. B. durch Stack-Ranking)5. Dort konkurriert eine wichtige Story für den Bezahlvorgang direkt mit einer weniger wichtigen Story für die Passwort-Wiederherstellung21.
• Strukturierte Priorisierung in der Story Map: Die USM erzwingt, dass das Team zuerst die gesamte Benutzerreise horizontal abbildet (die Frage der Vollständigkeit)21. Die horizontale Achse (das Backbone) stellt die chronologische Abfolge der Benutzeraktivitäten dar22.... Erst danach wird vertikal priorisiert (die Frage der Wichtigkeit)1821. Die wichtigsten, für die Kernfunktion unverzichtbaren Stories werden dabei ganz oben in ihrer Spalte platziert18.
3. Effektive Identifizierung von Lücken und Risikominimierung
Story Mapping ist ein Mechanismus zur Risikominimierung19, insbesondere hinsichtlich der Vollständigkeit des Produkts:
• Lücken erkennen: Beim flachen Backlog werden Lücken oft übersehen5. Das zweidimensionale Layout der Story Map hingegen macht Lücken (gaps) und fehlende Funktionalitäten sofort visuell ersichtlich und die Vollständigkeitsprüfung intuitiv5....
• Narrative Abwanderung: Der kritischste Schritt des Workshops ist das "Wandern" der Map als Gruppe, bei dem die Geschichte narrativ von links nach rechts abgewandert wird19.... Durch dieses "Erzählen" deckt das Team unweigerlich Engpässe, fehlende Informationen, Abhängigkeiten und notwendige technische Stories auf, die zuvor übersehen wurden1930.
4. Definition eines funktional vollständigen MVP ("Walking Skeleton")
Der Unterschied zwischen einem flachen Backlog und einer Story Map wird besonders bei der Definition des Minimum Viable Product (MVP) deutlich31.
• Backlog-MVP (Ineffizient): Ein MVP, das aus einem flachen Backlog abgeleitet wird, ist oft nur „die 5 wichtigsten Features“ aus einer Liste32. Dies kann zu einem funktional unbrauchbaren Produkt führen, weil notwendige Schritte fehlen (z.B. wenn man nur die wichtigsten Stories für eine Mahlzeit baut und ein ungewürztes, hartgekochtes Ei liefert, weil die Story "gut gewürzt sein" niedrig priorisiert wurde)32.
• Story Map-MVP (Vollständig): Die Story Map ermöglicht die horizontale Release-Planung durch "Slicing"5.... Der erste "Slice" (die oberste horizontale Zeile) definiert das MVP nicht als die wichtigsten Features, sondern als den dünnsten, aber funktional vollständigen End-to-End-Weg durch das Produkt32.
• Walking Skeleton: Die Story Map erzwingt, dass der MVP-Slice eine minimale Version aller notwendigen Schritte (Aktivitäten) enthält32. Dieses Ergebnis wird als "Walking Skeleton" (laufendes Skelett) bezeichnet – eine minimale, aber durchgängig funktionsfähige Version des gesamten Systems, die es dem Benutzer erlaubt, seine Ziele zu erreichen32....
Zusammenfassend lässt sich sagen, dass der Story Map-Prozess im Gegensatz zum flachen Backlog nicht nur ein Werkzeug zur Arbeitsverwaltung (Work planning) ist, sondern ein diskursives Werkzeug zur Schaffung eines geteilten Verständnisses5... über die gesamte User Journey3....
Analogie: Das flache Backlog ist wie eine unstrukturierte Einkaufsliste, auf der die 50 wichtigsten Zutaten für das Abendessen aufgereiht sind – Sie wissen, was Sie brauchen, aber nicht, in welcher Reihenfolge Sie es verwenden oder ob Sie damit überhaupt ein vollständiges Gericht zubereiten können. Die User Story Map hingegen ist wie ein Kochbuch: Sie visualisiert den gesamten Prozess (horizontal: vom Appetizer bis zum Dessert) und ordnet die Zutaten (vertikal: Stories) nach ihrer Wichtigkeit und ihrer Rolle im jeweiligen Schritt. Dadurch stellen Sie sicher, dass Sie den minimalen, aber durchgängigen "Laufweg" (Walking Skeleton) zum fertigen Essen kochen können.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Vorteile gegenüber Flachem Backlog“ über „Kontextreich ('Das große Ganze')“ aussagen.

Die Quellen betonen übereinstimmend, dass die Kontextarmut des flachen Backlogs der Hauptgrund für die Entwicklung des User Story Mappings (USM) war und dass der größte Vorteil der USM gerade in ihrer Fähigkeit liegt, "Das große Ganze" (The Big Picture) sichtbar und kontextreich zu machen1....
Hier ist eine detaillierte Diskussion, was die Quellen im Kontext der Vorteile gegenüber dem flachen Backlog über „Kontextreich ('Das große Ganze')“ aussagen:
1. Das Problem des flachen Backlogs: Kontextfreier Mulch
Die Notwendigkeit des Story Mappings ergibt sich direkt aus dem fundamentalen Problem der Struktur traditioneller Backlogs, die Jeff Patton (eine Schlüsselfigur der Methode) treffend als "einen Sack voller kontextfreiem Mulch" beschreibt15.
Ein flaches Product Backlog wird als eindimensionale Liste (vertikal) betrachtet1 oder im Wesentlichen als eine "To-Do-Liste"56. Sobald ein Produkt skaliert und Hunderte von Einträgen umfasst, wird dieses flache Backlog überwältigend und unüberschaubar5.
Die kritischen Mängel, die die Quellen in Bezug auf den Kontext des flachen Backlogs hervorheben, sind:
• Verlust des Überblicks: Es wird unmöglich, das "große Ganze" (the big picture) zu sehen5. Ein flaches Backlog macht den Gesamtzusammenhang nicht sichtbar2....
• Fehlender Kontext: Es ist unmöglich, den Kontext der einzelnen Aufgaben zu verstehen5. Die User Stories in einem flachen Backlog sind kontextfrei oder bestenfalls implizit1.
• Erschwerte Priorisierung: Da keine Übersicht über die Zusammenhänge besteht, wird die Priorisierung erschwert2.... Dort konkurriert beispielsweise eine "wichtige" Story für den Bezahlvorgang direkt mit einer "weniger wichtigen" Story für die Passwort-Wiederherstellung, ohne dass der breitere Kontext der gesamten Nutzerreise berücksichtigt wird9.
• Fokus auf Features statt Nutzen: Ein flaches Backlog fördert eine "Feature-Fabrik"-Mentalität, bei der es primär um das Abarbeiten von Tickets geht6.
2. Die Lösung: Die Story Map als kontextreiche Landkarte
Die User Story Map (USM) transformiert das Problem des kontextfreien Backlogs, indem sie dieses in eine zweidimensionale, kontextreiche "Landkarte" verwandelt110. Einige Quellen beschreiben diesen Wandel sogar als eine Umwandlung in eine dreidimensionale Ansicht6.
Die Quellen definieren die Story Map explizit als kontextreich und als das Werkzeug, das "Das große Ganze" (The Big Picture) sichtbar macht1.
Erreichung des Kontexts durch die Struktur:
Der Kontext wird durch die zweidimensionale Struktur der Map geschaffen, die jede einzelne Story fest im Rahmen der gesamten Customer Journey verankert6:
1. Horizontale Achse (Das große Ganze): Die Story Map nutzt die horizontale Achse, um das "Backbone" (Rückgrat) zu bilden11. Dieses Backbone ist die narrative Klammer des Produkts und repräsentiert die chronologische Reihenfolge der Benutzeraktivitäten1112. In ihrer Gesamtheit bildet diese Achse eine vereinfachte, aber vollständige Darstellung der User Journey11.
    ◦ Die Map erlaubt es, den gesamten Prozess des wichtigsten Nutzer-Typs zu skizzieren, was Jeff Patton als „mile‑wide, inch‑deep“ (meilenweit, zoll-tief) bezeichnet13....
    ◦ Durch diese horizontale Achse erhält das Team eine Landkarte der User Journey1, die den Zusammenhang zwischen Aktivitäten, Features und Releases sichtbar macht1617.
2. Vertikale Achse (Detaillierung und Priorität): Die Stories werden unterhalb der Backbone-Schritte vertikal angeordnet und nach Priorität sortiert18. Dieser Aufbau verankert die Stories im Kontext der jeweiligen Benutzeraktivität und trennt die Frage nach der Vollständigkeit (horizontal) von der Frage nach der Wichtigkeit (vertikal)18.
Vorteile des Kontextreichtums:
Die gewonnene Kontextualisierung führt zu direkten Vorteilen gegenüber dem flachen Backlog:
• Gezwungene Vollständigkeit: Die Story Map zwingt das Team, zuerst die gesamte Reise horizontal abzubilden9. Dadurch werden Lücken (gaps) und fehlende Funktionalitäten, wie beispielsweise eine vergessene Passwort-Wiederherstellung, sofort visuell ersichtlich1....
• Fokus auf Wert: Anstatt nur Tickets abzuarbeiten (Feature-Fabrik-Mentalität), erzwingt die Story Map eine "Value-Delivery"-Mentalität6. Die zentrale Frage verschiebt sich von "Was bauen wir als Nächstes?" zu "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"6.
• Gemeinsames Verständnis (Shared Understanding): Der wahre Wert des Story Mappings liegt im kollaborativen Prozess, der eine "kuratierte Konversation" erzeugt22.... Diese Konversation, die darauf abzielt, das Wissen aller Beteiligten zu kollektivieren, ist der Mechanismus, der ein gemeinsames Verständnis (Shared Understanding) des Produkts und seines Kontexts schafft16....
• Lebendiger Kontext: Im Gegensatz zur "Wegwerf-Map"27 kann die Story Map als "lebendiges Dokument" dienen, das in das kontinuierliche Backlog Grooming integriert wird2728. Dies löst das Problem des "kontextfreien Mulchs" auf permanenter Basis, da neue Anforderungen direkt an der richtigen Stelle im Kontext der User Journey platziert werden29. Die Map wird zum Kontextgeber vor jedem Sprint Planning30.
Zusammenfassend lässt sich sagen, dass der Vorteil der Story Map im Kontext von „Das große Ganze“ darin besteht, eine kontextfreie, lineare Liste durch eine zweidimensionale, narrative Struktur zu ersetzen, die es dem Team ermöglicht, Visuell die gesamte Nutzerreise zu überblicken, was essenziell für fundierte Priorisierungsentscheidungen und ein gemeinsames, vollständiges Produktverständnis ist1....

--------------------------------------------------------------------------------
Analogie zum besseren Verständnis des Kontextvorteils:
Ein flaches Backlog ist wie eine lange Einkaufsliste, auf der 50 Artikel linear nach Preis sortiert sind. Man weiß, was man kaufen soll, aber nicht warum oder wie die Zutaten später zusammenpassen. Es ist schwer zu erkennen, ob man eine Zutat für ein dreigängiges Menü oder nur für einen Snack vergessen hat.
Die User Story Map ist hingegen wie ein Rezeptbuch, das zuerst die Abfolge der Gänge (horizontaler Kontext) zeigt: Vorspeise, Hauptspeise, Dessert. Erst darunter werden die benötigten Zutaten (User Stories) vertikal nach Wichtigkeit sortiert. Dadurch sieht man sofort, welche Zutaten für die Hauptspeise fehlen (Lücken im Kontext) und welche optional sind, und man hat jederzeit "Das große Ganze" des Menüs vor Augen.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Vorteile gegenüber Flachem Backlog“ über „Trennung von Vollständigkeit (Horizontal) & Wichtigkeit (Vertikal)“ aussagen.

Die Quellen betonen, dass die Trennung von Vollständigkeit (Horizontal) und Wichtigkeit (Vertikal) der entscheidende Vorteil der User Story Map (USM) gegenüber dem traditionellen, flachen Backlog ist1. Diese zweidimensionale Perspektive ist nicht nur administrativ, sondern vor allem kognitiv2 und transformiert das Backlog von einer eindimensionalen Liste in eine kontextreiche Landkarte34.
Das Problem des Flachen Backlogs
Das fundamentale Problem eines traditionellen, flachen Backlogs liegt in seiner Struktur als eindimensionale Liste35. Es ist im Wesentlichen eine "To-Do-Liste"24. In einem flachen Backlog konkurrieren Stories unterschiedlicher Abstraktion und Dringlichkeit direkt miteinander6. Beispielsweise könnte eine "wichtige" Story für den Bezahlvorgang direkt neben einer "weniger wichtigen" Story für die Passwort-Wiederherstellung stehen6. Ein solches Backlog wird als "Sack voller kontextfreiem Mulch" beschrieben, sobald es skaliert und Hunderte von Einträgen umfasst, was es unmöglich macht, das "große Ganze" (the big picture) zu sehen4....
Das flache Backlog listet Aufgaben linear nach Priorität1011 und kann die Trennung von Kontext und Priorität nicht leisten1. Es erschwert die MVP-Definition und Release-Planung, da weder Zusammenhänge noch die Reihenfolge der Nutzeraktion sichtbar sind10....
Die Trennung durch die Zweidimensionale Story Map
Die User Story Map (USM) wandelt das eindimensionale Backlog in eine zweidimensionale Matrix um57, wodurch zwei zentrale Produktmanagement-Fragen klar getrennt und nacheinander beantwortet werden1:
1. Die Horizontale Achse: Vollständigkeit (Das „Backbone“)
Die horizontale Achse bildet das Backbone (Rückgrat) des Produkts7.... Sie dient als narrative Klammer715 und ist chronologisch von links nach rechts angeordnet1....
• Darstellung: Das Backbone besteht aus den groben Benutzeraktivitäten (User Activities) oder "großen Schritten"7, die ein Benutzer durchführt, um sein übergeordnetes Ziel zu erreichen718. Diese Aktivitäten bilden in ihrer Gesamtheit die vereinfachte, aber vollständige Darstellung der User Journey7.
• Die Frage der Vollständigkeit: Die horizontale Achse beantwortet die Frage: "Haben wir an die gesamte Reise gedacht?" bzw. "Sind alle notwendigen Backbone-Schritte vorhanden?"1.
• Vorteil (Gaps): Die Story Map zwingt das Team, zuerst die gesamte Reise horizontal abzubilden6. Dieser Prozess macht Lücken (gaps) und fehlende Funktionalitäten (z.B. die vergessene Passwort-Wiederherstellung) sofort visuell ersichtlich5....
2. Die Vertikale Achse: Wichtigkeit und Priorität
Die vertikale Achse wird unterhalb jedes Backbone-Schritts aufgebaut1. Hier werden die detaillierten Teilschritte und die eigentlichen User Stories gesammelt1....
• Darstellung: Diese Achse repräsentiert die Priorität und den Detaillierungsgrad1.... Die wichtigsten Stories, die für die Kernfunktion unverzichtbar sind ("Must-haves")2728, werden direkt unter dem Backbone platziert (ganz oben in der Spalte)1.... Darunter folgen Stories mit geringerer Priorität, alternative Lösungswege, oder "Nice-to-have"-Funktionen1. Innerhalb einer Spalte zeigen die Karten Alternativen, die mit dem Wort "oder" mental gelesen werden können1626.
• Die Frage der Wichtigkeit: Die vertikale Achse beantwortet die Frage: "Was ist der wichtigste Teil jedes Schritts?" bzw. "Welche Story in dieser Spalte liefert den meisten Wert?"1.
• Priorisierung: Die Stories werden vertikal nach Wichtigkeit sortiert29..., wobei Wichtigkeit sich aus Nutzen, Risiko und technischem Aufwand ergibt3031.
Ergebnis: Fokus auf Value Delivery und den "Walking Skeleton"
Durch diese Trennung fördert die Story Map eine "Value-Delivery"-Mentalität2. Die zentrale Frage verschiebt sich von "Was bauen wir als Nächstes?" zu "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"2.
Die klare Abbildung von Vollständigkeit (horizontal) und Wichtigkeit (vertikal) ist die Grundlage für das "Slicing" (in Scheiben schneiden), bei dem horizontale Linien über die gesamte Breite der Map gezogen werden, um Releases zu definieren17....
Der erste und wichtigste dieser horizontalen "Slices" definiert das Minimum Viable Product (MVP)32. Die Map stellt sicher, dass dieses MVP nicht nur "die 5 wichtigsten Features" sind, sondern der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt33. Das resultierende MVP, auch als "Walking Skeleton" (laufendes Skelett) bezeichnet33..., muss dafür Stories aus jedem kritischen Backbone-Schritt enthalten, da die Vollständigkeit (horizontal) gewährleistet wurde, bevor die Priorität (vertikal) festgelegt wurde633.
Diese Struktur verhindert, dass wichtige Schritte der User Journey übersehen werden, was bei einer linearen Priorisierung eines flachen Backlogs leicht geschehen kann und das Produkt unbrauchbar machen würde33.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Vorteile gegenüber Flachem Backlog“ über „Lücken (Gaps) werden sofort visuell ersichtlich“ aussagen.

Die Quellen betonen, dass die sofortige visuelle Erkennbarkeit von Lücken (Gaps) der entscheidende Vorteil des User Story Mapping (USM) gegenüber einem flachen Produkt-Backlog ist. Dieses Resultat wird durch die einzigartige zweidimensionale Struktur der Story Map erzwungen12.
1. Die Begrenzung des Flachen Backlogs
Im Gegensatz zur Story Map ist das traditionelle, flache Backlog eine eindimensionale Liste (eine "To-Do-Liste")34, die Aufgaben linear nach Priorität auflistet5. Da ihr der Kontext der gesamten User Journey fehlt45, wird die Vollständigkeitsprüfung schwierig, und Lücken in der Customer Journey werden oft übersehen3. Jeff Patton beschreibt ein solches Backlog als "einen Sack voller kontextfreiem Mulch"4.
2. Der Mechanismus der USM zur Lückenerkennung
Die Story Map löst dieses Problem, indem sie eine zweidimensionale Matrix einführt, die zwei fundamentale Produktmanagement-Fragen trennt1:
1. Die horizontale Frage (Vollständigkeit): "Haben wir an die gesamte Reise gedacht?" (Sind alle notwendigen Backbone-Schritte vorhanden?)1.
2. Die vertikale Frage (Wichtigkeit): "Was ist der wichtigste Teil jedes Schritts?"1.
Die Story Map zwingt das Team, zuerst die gesamte Benutzerreise horizontal abzubilden, bevor vertikal priorisiert wird2. Dieses zweidimensionale Layout67 und die Fokussierung auf die chronologische Reihenfolge der Benutzeraktivitäten8 machen Lücken und fehlende Funktionalitäten sofort visuell ersichtlich23.
Infolgedessen wird die Vollständigkeitsprüfung, die bei flachen Backlogs schwierig ist, bei der Story Map intuitiv3.
3. Der Prozess der Lückenidentifizierung im Workshop
Der Story Mapping Workshop nutzt die visuelle Struktur aktiv, um Gaps aufzudecken:
• Narrative Abwanderung: Im kritischsten Schritt des Workshops "wandert" das Team die Map als Gruppe narrativ ab, von der ersten Aktivität links bis zur letzten rechts19.
• Gemeinsames Verständnis: Durch das "Erzählen" der Geschichte entlang der Map9 deckt das Team unweigerlich Lücken, Engpässe, fehlende Informationen und Abhängigkeiten auf, die zuvor übersehen wurden9.
• Beispiel für vergessene Funktionalität: Die Quellen führen das Beispiel der vergessenen Passwort-Wiederherstellung an, die in einem flachen Backlog leicht untergehen kann, aber in der visuellen Story Map sofort als fehlender Schritt in der Customer Journey ("Anmelden" / "Zugang erhalten") erkannt wird2.
Das Aufdecken dieser Lücken minimiert somit das Risiko9.
Zusammenfassend lässt sich sagen: Die User Story Map agiert wie ein Röntgenbild der Customer Journey, das transparente Einblicke in die Vollständigkeit des Produkts bietet10. Während das flache Backlog wie eine ungeordnete Einkaufsliste ist, bei der man leicht vergisst, die Milch zu kaufen, sorgt die Story Map durch ihre Landkarten-Analogie dafür, dass jeder notwendige "Ort" auf der Benutzerreise kartografiert ist34.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Vorteile gegenüber Flachem Backlog“ über „Primäres Ziel: Geteiltes Verständnis (Shared Understanding)“ aussagen.

Die Quellen betonen übereinstimmend, dass das primäre Ziel des User Story Mapping (USM) – und damit sein größter Vorteil gegenüber einem flachen Backlog – die Schaffung eines Geteilten Verständnisses (Shared Understanding) im Team ist1....
Im Kontrast dazu dient das flache Product Backlog primär der Arbeitsverwaltung (Work planning)1.
1. Die Priorität des Geteilten Verständnisses
Das ultimative Ziel des Story Mapping liegt nicht in der Erstellung des physischen oder digitalen Artefakts selbst, sondern im Prozess der Erstellung36.
• Prozess vor Artefakt: Das Mapping zielt darauf ab, die Konversation und das gemeinsame Verständnis im Team zu fördern3.
• Wissen kollektivieren: Der Story Mapping Workshop fungiert als Mechanismus zur Kollektivierung des Wissens aller Beteiligten26.
• Kernfrage: Das Team muss zu Beginn ein gemeinsames Verständnis für das Ziel des Produkts oder Features haben6. Eine Story Map beantwortet die Fragen: Warum bauen wir das? Für wen? und Welchen Nutzen liefert es?78.
2. Der Mechanismus: Die kuratierte Konversation
Dieses gemeinsame Verständnis entsteht durch den kollaborativen Prozess im Story Mapping Workshop, der als "kuratierte Konversation" bezeichnet wird2....
In dieser Konversation wird das Shared Understanding in folgenden Momenten geschaffen:
1. Diskussion über Platzierung: Der wahre Wert liegt in der Diskussion darüber, warum eine Story an einer bestimmten Stelle auf der Map platziert werden muss (vertikal in der Priorität oder horizontal in der Customer Journey)2.
2. Lücken identifizieren: Durch das narrative Abwandern der Map deckt die Gruppe unweigerlich Lücken und fehlende Funktionalitäten auf, die zuvor übersehen wurden2.... Diese Lücken zu visualisieren und zu diskutieren, festigt das gemeinsame Wissen2.
3. Hören der Gründe: Die Teilnahme von funktionsübergreifenden Teammitgliedern, insbesondere Entwicklern, ist entscheidend1415. Wenn Teammitglieder teilnehmen, hören sie die zugrundeliegenden Gründe, warum Nutzer und Stakeholder bestimmte Dinge benötigen (Probleme, Frustrationen, Erwartungen)15. Dieses Zuhören kann zu Erkenntnissen führen, die sie sonst verpasst hätten15.
3. Der kognitive Wandel
Die Story Map forciert einen kognitiven Wandel weg von der isolierten Abarbeitung von Tickets, wie sie das flache Backlog fördert, hin zu einem fokussierten, gemeinsamen Ziel16.
Die Umwandlung des "Sacks voller kontextfreiem Mulch" (das flache Backlog)1718 in eine kontextreiche Landkarte19 verankert jede einzelne User Story fest im Kontext der gesamten Customer Journey16.
Dieser Wandel führt zu einer Verschiebung der Denkweise:
• Von Feature zu Wert: Statt einer "Feature-Fabrik"-Mentalität16, die das Abarbeiten von Tickets fördert, erzwingt die Story Map eine "Value-Delivery"-Mentalität16.
• Neue zentrale Frage: Die Prioritätenverschiebung drückt sich in der geänderten zentralen Frage aus: Statt "Was bauen wir als Nächstes?" lautet die Frage nun "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"16. Die gemeinsame Beantwortung dieser Frage ist der Ausdruck des geschaffenen Shared Understandings.

--------------------------------------------------------------------------------
Analogie: Man kann das Story Mapping als den Unterschied zwischen dem Erhalt einer Einkaufsliste (dem flachen Backlog) und dem gemeinsamen Besuch des Supermarkts mit der Familie (dem Story Mapping Workshop) betrachten. Auf der Liste stehen nur die Artikel (Stories) in Prioritätsreihenfolge. Beim gemeinsamen Einkaufen (Mapping) wird aber klar, warum man Mehl vor Eiern kaufen muss (Abhängigkeiten), für wen das Abendessen ist (Persona/Ziel), welche Teile des Rezepts man streichen kann, wenn die Zeit knapp wird (Slicing/MVP), und man vermeidet, wichtige Schritte zu vergessen, die auf der Liste gefehlt haben (Lücken) – weil alle Beteiligten den Gesamtzusammenhang (das "große Ganze") sehen und diskutieren2....

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Definition & Nutzen“ über „Ziele“ aussagen.

Die Quellen definieren die Ziele des User Story Mapping (USM) als weit über die bloße Organisation von Anforderungen hinausgehend und legen den Fokus auf die Schaffung eines gemeinsamen Verständnisses, die Nutzerzentrierung und die konkrete Release-Planung.
Die zentralen Ziele von User Story Mapping sind:
I. Kognitive und Kollaborative Ziele (Shared Understanding)
Das ultimative Ziel des User Story Mapping liegt nicht primär im fertigen Artefakt selbst, sondern im kollaborativen Prozess seiner Erstellung, der eine "kuratierte Konversation" darstellt12.
1. Schaffung eines gemeinsamen Verständnisses (Shared Understanding): Das oberste Ziel des gesamten Mapping-Prozesses ist die Konversation und das gemeinsame Verständnis im Team23. Durch die Einbindung unterschiedlicher Rollen in interaktiven Workshops schafft die Methode ein gemeinsames Verständnis des Produkts45.
2. Kollektivierung von Wissen: Der Workshop zielt darauf ab, das Wissen aller Beteiligten zu kollektivieren12. Um dies zu erreichen, muss der Workshop funktionsübergreifend besetzt sein und Business (Warum?), UX (Für wen?) und Entwicklung (Wie?) an einen Tisch bringen6.
3. Risikominimierung und Lückenidentifikation: Das Story Mapping ist ein Mechanismus zur Risikominimierung2. Es hilft Teams, Lücken (gaps) und fehlende Funktionalitäten (z. B. vergessene Passwort-Wiederherstellung) sofort visuell ersichtlich zu machen7.... Durch das narrative Abwandern der Map deckt das Team unweigerlich Lücken, Engpässe und Abhängigkeiten auf2.
4. Bessere Kommunikation: Die Map ist ein diskursives Werkzeug; sie lebt durch Gespräche411.
II. Strategische und Nutzerzentrierte Ziele
USM erzwingt einen Fokuswechsel weg von der reinen Aufgabenverwaltung hin zur Wertlieferung aus Sicht des Kunden1213.
1. Beantwortung der Kernfragen des Produkts: Eine Story-Map ist darauf ausgelegt, die fundamentalen Fragen der Produktentwicklung zu beantworten: Warum bauen wir das?, Für wen? und Welchen Nutzen liefert es?14....
2. Förderung der Nutzerzentrierung: Das Ziel ist es, die Anforderungen aus Kundensicht zu ordnen14... und den Fokus auf den Nutzer zu behalten16.... Die visuelle Übung soll helfen, die Arbeit zu definieren, die das ansprechendste Benutzererlebnis schafft12.
3. Verschiebung der zentralen Frage: Die Methode erzwingt eine "Value-Delivery"-Mentalität im Gegensatz zur "Feature-Fabrik"-Mentalität eines flachen Backlogs12. Die zentrale Frage verschiebt sich von "Was bauen wir als Nächstes?" zu "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"12.
III. Konkrete Planungsziele
Die visuelle Organisation der Stories in der zweidimensionalen Matrix dient direkt der effektiven agilen Planung1319.
1. MVP-Definition: Ein Hauptziel von USM ist es, Minimum Viable Products (MVPs) zu definieren10.... Dabei soll ein MVP nicht nur eine Liste wichtiger Features, sondern der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt sein, oft als "Walking Skeleton" bezeichnet21....
2. Release- und Roadmap-Planung: Die Map dient dazu, Releases zu planen16.... Durch das "Slicing" (horizontales Schneiden der Map) kann die beabsichtigte Lieferreihenfolge von Features für zukünftige Versionen und Quartale visualisiert werden26....
3. Backlog-Strukturierung und Priorisierung: Story Mapping dient der Produkt-Planung und Backlog-Strukturierung29. Es erleichtert die Priorisierung der Anforderungen45, indem es die Fragen der Vollständigkeit und der Wichtigkeit trennt und somit eine transparente Übersicht über die zu erstellende Software bietet3031.
4. Kontinuierliches Grooming: Ein weiteres Ziel ist die Nutzung der Map als "lebendiges Dokument" und zentrales Werkzeug für das kontinuierliche Backlog Grooming (Refinement)6....
Zusammenfassend lässt sich sagen: Die User Story Map hat das Ziel, die Komplexität eines wachsenden Backlogs zu beherrschen, indem sie das Backlog in eine kontextreiche, zweidimensionale Landkarte verwandelt, die dem Team hilft, nicht nur zu sehen, was es baut, sondern warum es dies aus der Perspektive des Nutzers tut12.... Es ist der Wandel von der einfachen "To-Do-Liste" zur "Landkarte" der User Journey und der Releases13.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Ziele“ über „MVP definieren“ aussagen.

Das Definieren des Minimum Viable Product (MVP) ist eines der zentralen und primären Ziele des User Story Mappings (USM)1.... Die Story Map dient als ein essenzielles Werkzeug, um Releases zu planen und den Umfang des MVP festzulegen2....
Die Quellen beschreiben, dass die USM das Konzept des MVP fundamental neu definiert6.
1. Der Mechanismus: Horizontales "Slicing"
Das Ziel, das MVP zu definieren, wird durch die Technik des "Slicing" (in Scheiben schneiden) der fertigen, priorisierten Map erreicht7....
• Vorgehen: Die vertikal priorisierte Map wird horizontal "geschnitten"8. Der Moderator oder Product Owner zieht hierfür horizontale Linien über die gesamte Breite der Map8.
• Die oberste Scheibe: Der erste und wichtigste "Slice" ist die oberste horizontale Scheibe, welche das Minimum Viable Product (MVP) definiert8....
• Release-Planung: Jede dieser horizontalen Scheiben repräsentiert ein geplantes Release, einen Sprint oder eine Iteration, wobei die Stories oberhalb der ersten Linie das erste Release bilden8....
2. Die Neudefinition des MVP: Der "Walking Skeleton"
Ein durch Slicing entstandenes MVP unterscheidet sich grundlegend von einem MVP, das aus einer flachen Liste abgeleitet wird:
• Vermeidung der "Feature-Liste": Das USM-MVP ist nicht einfach "die 5 wichtigsten Features" aus einer Liste6.
• Funktional vollständiger Weg: Stattdessen ist das MVP der dünnste, aber funktional vollständige End-to-End-Weg durch das gesamte Produkt6. Das Ziel dieses Slices ist es, eine "Complete Product Experience" (CPE) oder zumindest eine durchgehende Benutzererfahrung zu liefern6.
• Das Walking Skeleton: Dieses Ergebnis wird als "Walking Skeleton" (laufendes Skelett) bezeichnet6.... Es handelt sich dabei um einen minimalen, aber nutzbaren Ablauf, der dem Benutzer erlaubt, seine Ziele zu erreichen16....
• Anforderung an die Vollständigkeit: Der MVP-Slice muss (mindestens) eine Story aus jedem kritischen Backbone-Schritt enthalten6. Dies stellt sicher, dass alle notwendigen Schritte der User Journey (horizontal) abgedeckt sind, auch wenn nur in minimaler Form6....
3. Implementierung und Priorisierung
Um den MVP definieren zu können, muss die vertikale Priorisierung der Stories in jeder Spalte klar sein, denn die Stories, die für eine minimale Funktionsfähigkeit unerlässlich sind ("Must-haves"), werden nach oben geschoben und bilden so den MVP-Slice11....
• Kollaborativer Prozess: Stakeholder und das Entwicklungsteam sollten gemeinsam definieren, welche Stories in das MVP gehören1121.
• Methoden: Die Priorisierung, welche die Grundlage für das Slicing bildet, kann methodisch fundiert sein. Wird beispielsweise die MoSCoW-Methode angewendet, so bilden die "Must-have"-Stories kollektiv den natürlichen MVP-Slice20.
• Nachfolgende Releases: Die Slices unterhalb des MVP repräsentieren nachfolgende Releases, die dem "Walking Skeleton" mehr "Fleisch" (zusätzliche Funktionen oder Alternativen) hinzufügen12....
Das finale MVP ist somit ein Produkt, das, obwohl es minimalistisch ist, die Kernfunktionalität in jedem Schritt der Benutzerreise sicherstellt, wie es anhand der Fallstudien (z.B. E-Commerce oder Fitness-App) gezeigt wird24.... Das Ziehen des MVP-Slices ist so kritisch, dass der Workshop erst dann als beendet gilt, wenn der MVP klar definiert und vom Team committet ist27.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Ziele“ über „Releases planen“ aussagen.

Die Planung von Releases ist eines der zentralen Ziele und Hauptanwendungsgebiete des User Story Mappings (USM) im agilen Projektmanagement1.... Die Story Map wird explizit genutzt, um MVPs zu definieren und Releases zu planen1....
Das Ziel der Release-Planung wird durch die Technik des "Slicing" (in Scheiben schneiden) erreicht, welche die vertikal priorisierte Map in einen umsetzbaren Plan verwandelt4....
1. Die Methode: Horizontales "Slicing"
Die Release-Planung erfolgt durch das Hinzufügen von horizontalen Linien (Slices oder Cut-Lines) über die gesamte Breite der Map6....
• Definition der Scheibe: Jede dieser horizontalen „Scheiben“ (Slices) repräsentiert ein geplantes Release, einen Sprint oder eine Iteration6....
• Sequenz der Features: Die Anordnung der Stories in den Slices ermöglicht es dem Product Owner, die beabsichtigte Liefersequenz (delivery sequence) der Features in den kommenden Versionen zu kommunizieren16.
• Patton's Prozess: In Jeff Pattons fünfstufigem Prozess ist das "Slice Out Viable Releases" (Definition von MVP und nachfolgenden Releases) der vierte Schritt7....
2. Das Ziel: Definition des Minimum Viable Product (MVP)
Der wichtigste Planungsschritt ist die Definition des ersten Releases, des Minimum Viable Product (MVP)6....
• Der erste Slice: Die oberste Scheibe (alles oberhalb der ersten horizontalen Linie) definiert das MVP6....
• Neudefinition des MVP: Hier zeigt sich die wahre Stärke des Slicing: Es definiert das Konzept eines MVP fundamental neu6. Das MVP ist nicht nur eine Liste der wichtigsten Features ("die 5 wichtigsten Features")19, sondern der dünnste, aber funktional vollständige End-to-End-Weg durch das gesamte Produkt19....
• Der "Walking Skeleton": Das Ziel dieses MVP-Slices ist es, eine durchgehende Benutzererfahrung (Complete Product Experience, CPE) oder zumindest einen minimalen, aber nutzbaren Ablauf zu liefern19.... Dieses Ergebnis wird als „Walking Skeleton“ (laufendes Skelett) bezeichnet13.... Ein solcher Slice muss mindestens eine Story aus jedem kritischen Backbone-Schritt enthalten19.
• Beispiele: Fallstudien, wie die E-Commerce-Plattform, zeigen, dass der MVP-Slice einen kompletten Kaufzyklus ermöglichen muss, auch wenn er auf erweiterte Funktionen (wie PayPal oder Filter) verzichtet23.
3. Fortgeschrittene und kontinuierliche Release-Planung
Die Release-Planung ist kein einmaliger, abgeschlossener Schritt, sondern ein iterativer Prozess, der das Produktmanagement kontinuierlich unterstützt.
• Nachfolgende Releases: Die Slices unterhalb des MVP repräsentieren nachfolgende Releases (z.B. Version 1.1, Version 2.0)2425. Sie dienen dazu, dem "Walking Skeleton" mehr "Fleisch" hinzuzufügen—etwa durch die Implementierung höher priorisierter Alternativen oder "Nice-to-have"-Funktionen25.
• Roadmap-Funktion: Die Story Map fungiert nach dem Slicing als lebendige, visuelle Produkt-Roadmap25.
• Messung und Risiken: Für jede Release-Slice muss ein Ziel („Outcome“) definiert und es müssen Metriken festgelegt werden, um den Erfolg des Releases zu messen und den Nutzen zu überprüfen8.... Zudem helfen Risikonotizen, unsichere Annahmen oder externe Abhängigkeiten, die den Release gefährden könnten, sichtbar zu machen13....
Wichtiger Hinweis (Fallstrick): Das Ziehen der Release-Linien ist essenziell. Ein häufiger Fehler (Pitfall) ist das fehlende oder falsche "Slicing"32. Ohne diese Linien ist die Map lediglich ein Katalog aller Möglichkeiten, aber es existiert kein klarer Plan, was als Nächstes geliefert wird32. Daher ist der Workshop erst beendet, wenn der erste Slice (das MVP) klar definiert, visualisiert und vom Team committed ist32.

--------------------------------------------------------------------------------
Analogie:
Wenn das flache Backlog eine unübersichtliche Liste aller potenziellen Bauteile in einem Lagerhaus ist, ist die Story Map der Bauplan des Hauses. Das Releases Planen (Slicing) ist vergleichbar mit dem Definieren der Bauabschnitte: Der erste Slice (MVP/Walking Skeleton) garantiert, dass das Fundament, die tragenden Wände und ein funktionierendes Dach vorhanden sind – der Nutzer kann minimal, aber vollständig darin wohnen. Die nachfolgenden Slices fügen dann die Tapeten, Möbel und Extras hinzu, um das Erlebnis zu perfektionieren.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Ziele“ über „Fokus auf Nutzer behalten“ aussagen.

Die Quellen definieren den Fokus auf den Nutzer als eines der Hauptziele und eine grundlegende Anforderung für die erfolgreiche Anwendung des User Story Mapping (USM)1....
Die User Story Map ist eine agile Methode, die darauf abzielt, MVPs zu definieren, Releases zu planen und den Fokus auf den Nutzer zu behalten1....
1. Das Ziel: Nutzerzentrierung und Wertlieferung
Die Story Map ist eine visuelle Übung, die Produktmanagern und Teams hilft, Arbeit zu definieren, die das ansprechendste Benutzererlebnis schafft5.
Die primären Ziele der Methode sind explizit benutzerzentriert:
• Kernfragen beantworten: Eine Story Map beantwortet die grundlegenden Fragen "Warum bauen wir das?", "Für wen?" und "Welchen Nutzen liefert es?"3.... Sie hilft, die Anforderungen aus Kundensicht zu ordnen36.
• Mentalitätswandel: Die Story Map erzwingt einen kognitiven Wandel vom Abarbeiten von Tickets (der "Feature-Fabrik"-Mentalität) hin zu einer "Value-Delivery"-Mentalität5. Die zentrale Frage verschiebt sich zu: "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"5.
• Nutzenbasierte Priorisierung: Das zweidimensionale Layout hilft Teams, Stories nach Nutzen zu priorisieren8.... Die vertikale Achse beantwortet die Frage: "Welche Story in dieser Spalte liefert den meisten Wert?"11.
2. Strukturelle Verankerung in der Customer Journey
Der Fokus auf den Nutzer wird durch die zweidimensionale Struktur der Map festgeschrieben, die das gesamte Backlog im Kontext der Customer Journey verankert3....
• Das Backbone: Die horizontale Achse (das Backbone oder Rückgrat) dient als narrative Klammer14. Sie besteht aus den grobgranularen Benutzeraktivitäten (User Activities) oder "großen Schritten"14... in chronologischer Reihenfolge14.... Diese Aktivitäten bilden in ihrer Gesamtheit eine vereinfachte, aber vollständige Darstellung der User Journey14.
• Stories aus Nutzersicht: Die unter dem Backbone gesammelten Stories müssen als kurz formulierte Aussagen aus Sicht des Nutzers verfasst werden19.... Sie beschreiben, welche konkreten Funktionen gebaut werden müssen, um entdeckte Probleme zu lösen7....
3. Operative Anforderungen (Personas und Workshop-Regeln)
Um den Fokus auf den Nutzer aktiv zu gewährleisten, empfehlen die Quellen spezifische vorbereitende Schritte und Regeln für den Story Mapping Workshop:
• Persona-Definition: Die Definition der Ziel-Personas ist unerlässlich17..., da die Map aus der Perspektive des Benutzers erstellt wird24. Es ist eine Best Practice, den ersten Workshop auf eine primäre Persona zu fokussieren, um die Komplexität zu reduzieren24.
• Formulierung als Nutzeraktivität: Bei den Moderations-Tipps und Regeln wird explizit die User-Zentrierung gefordert: Alle Elemente müssen als Nutzeraktivitäten formuliert werden25....
• Vermeidung technischer Sprache: Im Gegensatz dazu sollten technische Formulierungen vermieden werden28.... Technische Aufgaben (Technical Stories) sollten in separate Spalten ausgelagert werden, um die Sicht des Nutzers auf das Produkt nicht zu stören25....
• Story Mapping Game: Selbst spielerische Übungen, wie das User-Story-Mapping-Spiel ("Morning Routine"), verdeutlichen, wie wichtig Priorisierung und Nutzerfokus sind31....
4. Abgrenzung zur User Journey Map
Der Fokus auf den Nutzer ist ein Unterscheidungsmerkmal der USM, obwohl sie nicht mit der User Journey Map (UJM) verwechselt werden sollte34....
• Die UJM ist ein Werkzeug aus dem UX-Design, das Empathie aufbaut und Probleme diagnostiziert, indem es Emotionen und Schmerzpunkte des Benutzers visualisiert3738.
• Die USM ist hingegen ein Werkzeug der Produktplanung, das die Funktionalität des Produkts fokussiert und die Lösung für die in der UJM identifizierten Probleme plant3738.
Idealerweise dient die UJM als perfekter Input für den USM-Workshop, um sicherzustellen, dass die geplante Funktionalität (USM) auf einem tiefen Verständnis der Nutzerbedürfnisse und -erlebnisse (UJM) basiert37.

--------------------------------------------------------------------------------
Zusammenfassend ist der Fokus auf den Nutzer im Story Mapping nicht nur eine Empfehlung, sondern ein durch die Struktur und Methodik erzwungenes Ziel. Indem die Story Map die gesamte Produktentwicklung an der chronologischen Abfolge der Benutzeraktivitäten ausrichtet, wird sichergestellt, dass das Team nicht in einer "Feature-Fabrik"-Mentalität verfällt, sondern sich stets darauf konzentriert, funktional vollständigen und wertvollen Nutzen für den Benutzer zu liefern.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Ziele“ über „Anforderungen aus Kundensicht ordnen“ aussagen.

Die Anforderungen aus Kundensicht zu ordnen und zu strukturieren, ist ein zentrales Ziel der User Story Mapping (USM) Methode und ein direkter Vorteil gegenüber dem flachen Produkt-Backlog.
Die Quellen beschreiben, dass die USM durch ihren benutzerzentrierten Ansatz und ihre visuelle Struktur eine "Value-Delivery"-Mentalität fördert, um sicherzustellen, dass die Produktentwicklung auf den maximalen Kundennutzen ausgerichtet ist1....
1. Das explizite Ziel: Antworten auf die Kundenfragen finden
Das Ziel einer Story Map ist es, grundlegende Fragen zur Produktentwicklung zu beantworten und dadurch die Anforderungen aus Kundensicht zu ordnen2....
Eine Story Map beantwortet explizit folgende Fragen2...:
• Warum bauen wir das?
• Für wen?
• Welchen Nutzen liefert es?
Dieser Fokus führt dazu, dass die Story Map eine benutzerzentrierte Methode der agilen Produktplanung ist5.... Das Ziel verschiebt sich weg von der Abarbeitung von Features hin zur vollständigen Lösung von Nutzerproblemen1. Die zentrale Frage lautet: "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"1.
2. Die Verankerung in der User Journey (Horizontal)
Die Story Map ordnet die Anforderungen, indem sie diese fest in den Kontext der gesamten Benutzerreise stellt1....
• Orientierung an Schritten: Die Technik orientiert sich an den Schritten des Benutzers bei der Nutzung des Systems, der sogenannten User Journey1112.
• Chronologische Abfolge: Die horizontale Achse der Map (das Backbone) bildet die chronologische Reihenfolge der Benutzeraktivitäten oder "großen Schritte" ab13.... Dieses Backbone fungiert als die narrative Klammer des Produkts und liefert eine vollständige Darstellung der User Journey4....
• Kognitiver Vorteil: Während ein flaches Backlog kontextfrei ist und verhindert, dass man das "große Ganze" sieht519, verankert die Story Map jede einzelne User Story fest im Kontext der gesamten Customer Journey1.
3. Die Priorisierung nach Nutzen (Vertikal)
Die Stories werden vertikal nach ihrer Wichtigkeit und dem Nutzen sortiert, um die Anforderungen im Sinne des Kunden zu strukturieren20....
• Wichtigkeitsachse: Unterhalb jeder Benutzeraktivität (Backbone-Schritt) werden die detaillierten User Stories vertikal angeordnet und nach Priorität sortiert18....
• Nutzen als Kriterium: Die Wichtigkeit der Stories ergibt sich aus einer Kombination von Nutzen, Risiko und technischem Aufwand26.... Die Stories, die für die Kernfunktion unverzichtbar sind ("Must-haves"), werden ganz oben platziert18....
• Gefahrvermeidung: Durch diese Struktur wird verhindert, dass Teams das auswählen, was am einfachsten oder am interessantesten ist, anstatt das, was den höchsten Kundennutzen liefert19.
4. Die Persona-Definition als Voraussetzung
Um Anforderungen aus Kundensicht ordnen zu können, ist die Definition der Ziel-Personas unerlässlich7....
• Perspektive: Die Map wird explizit aus der Perspektive des Benutzers erstellt7....
• Workshop-Regel: Eine Best Practice ist die User-Zentrierung, bei der alle Elemente als Nutzeraktivitäten formuliert werden, während technische Formulierungen vermieden werden32....
• Problemframing: Schon in der Vorbereitung des Workshops müssen die Kernfragen "Welches Problem lösen wir? Für wen? Welchen Nutzen stiftet das Produkt?" definiert werden31.
5. Das Ergebnis: Lieferung eines vollständigen Nutzens (MVP)
Die Ordnung der Anforderungen aus Kundensicht führt direkt zur Definition des Minimum Viable Product (MVP), das einen vollständigen Nutzen liefert:
• Walking Skeleton: Die Story Map wird horizontal "geschnitten" (Slicing), um Releases zu definieren18.... Der wichtigste Slice definiert das MVP. Dieses MVP ist der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt35....
• Complete Product Experience (CPE): Dieses Ergebnis, oft als "Walking Skeleton" bezeichnet, garantiert, dass der minimale, aber nutzbare Ablauf41 und eine durchgehende Benutzererfahrung (Complete Product Experience oder CPE) realisiert wird, da der MVP-Slice mindestens eine Story aus jedem kritischen Backbone-Schritt enthalten muss40. Dies ist die ultimative Form der Organisation von Anforderungen: sicherzustellen, dass der Kunde ein vollständiges Produktziel erreichen kann.
Zusammenfassend: Das Ordnen der Anforderungen aus Kundensicht wird durch die USM erreicht, indem sie die Anforderungen in einen narrativen Kontext (horizontal) setzt und sie dann nach dem maximalen Nutzerwert (vertikal) priorisiert, wodurch der Fokus von "Was bauen wir?" auf "Welchen vollständigen Nutzen liefern wir?" verlagert wird1.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „User Story Mapping (USM)“ über „Anatomie & Struktur“ aussagen.

Die Anatomie und Struktur der User Story Map (USM) ist ihr fundamentalstes Kernkonzept und der entscheidende Vorteil gegenüber dem traditionellen, flachen Produkt-Backlog1. Die Story Map ist eine visuelle Technik zur Organisation und Priorisierung von Produktarbeit2.
Die Quellen beschreiben die Anatomie der Story Map als eine Transformation:
• Vom 1D-Backlog zur 2D/3D-Landkarte: Die USM verwandelt ein eindimensionales, flaches Backlog2..., das oft als "Sack voller kontextfreiem Mulch" bezeichnet wird5, in eine zweidimensionale Matrix2... oder eine dreidimensionale Ansicht7. Diese Darstellung verankert jede einzelne User Story fest im Kontext der gesamten Customer Journey78.
Die Struktur basiert auf zwei Achsen, die es ermöglichen, die Fragen nach Vollständigkeit und Wichtigkeit zu trennen, was ein flaches Backlog nicht leisten kann1.
1. Die Horizontale Achse: Das Backbone (Vollständigkeit)
Die horizontale Achse bildet das "Backbone" (Rückgrat) des Produkts6.... Sie dient als die narrative Klammer des gesamten Produkts89.
• Chronologie: Die Elemente sind von links nach rechts in chronologischer Reihenfolge angeordnet1.... Dies repräsentiert die Abfolge der Schritte, die ein typischer Nutzer ausführt12....
• Inhalt (Hohe Granularität): Das Backbone besteht aus den "großen Schritten"9, den Benutzeraktivitäten (User Activities)8... oder Themen9..., die ein Benutzer durchführt, um sein Ziel zu erreichen9. Diese Aktivitäten sind grobgranulare Epics9.
• Funktion: Die horizontale Achse liefert eine vereinfachte, aber vollständige Darstellung der User Journey89. Sie beantwortet die horizontale Frage: "Haben wir an die gesamte Reise gedacht?" (Sind alle notwendigen Backbone-Schritte vorhanden?)1.
• Leserichtung: Beim Lesen über die Map hinweg fügt man mental das Wort "dann" (then) zwischen den Schritten ein, um die Sequenz darzustellen13.
2. Die Vertikale Achse: Priorität und Detaillierung (Wichtigkeit)
Die vertikale Achse wird unterhalb jedes Backbone-Schritts aufgebaut117. Sie dient der Strukturierung der tatsächlichen Arbeitspakete.
• Inhalt (Detaillierungsgrad): Hier werden die detaillierten Teilschritte, die eigentlichen User Stories und Aufgaben, gesammelt1.... Die Detailtiefe nimmt nach unten zu12.... User Stories sind kurz formulierte Aussagen aus Sicht des Nutzers, die konkrete Funktionen beschreiben14....
• Anordnung und Priorität: Die Stories werden vertikal nach Priorität sortiert14.... Die wichtigsten Stories, die für die Kernfunktion unverzichtbar sind ("Must-haves"), werden ganz oben platziert, direkt unter dem Backbone-Schritt1.... Darunter folgen Stories mit geringerer Priorität, alternative Lösungswege oder "Nice-to-have"-Funktionen1.
• Funktion: Sie beantwortet die vertikale Frage: "Was ist der wichtigste Teil jedes Schritts?" (Welche Story in dieser Spalte liefert den meisten Wert?)1.
• Leserichtung: Die vertikale Dimension zeigt Alternativen13. Beim Lesen nach unten fügt man mental das Wort "oder" (or) zwischen den Karten ein1323.
3. Granularität und Hierarchie der Elemente
Die Story Map nutzt eine klare Hierarchie, die die Abstraktionsebenen organisiert15...:
1. Aktivitäten/Themen (Oberste Zeile): Beschreiben hohe Ziele (z.B. Kontoüberblick erhalten)15.... Sie bilden das Backbone1011.
2. Epics/Schritte (Zweite Zeile): Gruppieren User Stories zu funktionalen Einheiten11.... Sie sind die Unteraufgaben, die für das Ziel nötig sind (z.B. Kontodetails eingeben, Scheck fotografieren)15....
3. User Stories/Tasks (Darunter): Beschreiben konkrete Interaktionen (z.B. Benutzername eingeben, Passwort eingeben)15.... Sie stellen die Implementierungsgröße dar24.
4. Die Struktur zur Release-Planung
Ein weiteres strukturelles Element sind die horizontalen Einteilungen, die die Map in Releases unterteilen25:
• Release-Slices (Cut-Lines): Dies sind horizontale Linien, die über die gesamte Breite der Map gezogen werden12.... Sie unterteilen die Stories in Releases oder MVPs12....
• MVP: Die oberste Reihe bildet das Minimum Viable Product (MVP)22.... Die erste Release-Slice muss eine funktionsfähige Menge von User Stories enthalten, die dem Benutzer erlaubt, seine Ziele zu erreichen1228. Dieses MVP wird oft als "Walking Skeleton" (laufendes Skelett) bezeichnet22....
5. Ergänzende Elemente
• Personas: Fiktive Nutzerprofile mit Zielen und Problemen, die über der Map platziert werden, um die Aktivitäten zuzuordnen12....
• Risiken/Status: Notizen und Risikokarten helfen, unsichere Annahmen oder externe Abhängigkeiten sichtbar zu machen und können den Status der Stories (z.B. todo, in Bearbeitung, erledigt, riskant) vermerken22....
Zusammenfassend lässt sich festhalten, dass die Story Map durch ihre zweidimensionale Anatomie jede einzelne Anforderung kontextreich3 in den narrativen Fluss der Benutzerreise einbettet, bevor deren Detaillierung und Priorität (Wichtigkeit) bestimmt wird1.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Anatomie & Struktur“ über „Horizontale Achse (Backbone)“ aussagen.

Die horizontale Achse, oft als "Backbone" (Rückgrat) bezeichnet, ist das primäre strukturelle Element der User Story Map (USM) und fungiert als narrative Klammer des Produkts12. Sie ist entscheidend, da sie die USM von einem flachen Backlog unterscheidet und den Kontext der gesamten User Journey festlegt2....
Im Kontext von „Anatomie & Struktur“ treffen die Quellen folgende Aussagen über die horizontale Achse:
1. Definition und Chronologischer Fluss
Die horizontale Achse ist die erste Dimension der Story Map und bildet die chronologische Reihenfolge der Benutzeraktivitäten ab1....
• Richtung: Die Achse wird von links nach rechts angeordnet, entsprechend der Reihenfolge, in der ein typischer Nutzer die Schritte ausführt1....
• Narrative: Die horizontale Anordnung erzeugt eine Sequenz von Schritten8. Man kann über die Map hinweglesen, indem man mental das Wort "dann" (then) zwischen den Schritten einfügt11. Diese Abfolge wird als Narrative bezeichnet12.
• Inhalt: Das Backbone besteht aus den "großen Schritten"1, "Benutzeraktivitäten" (User Activities)1... oder "Themen"3.... Diese sind grobgranulare Epics1 und repräsentieren hohe Ziele (z. B. "Kontoüberblick erhalten")10....
• Funktionsbereich: Die Karten in der obersten Zeile des Backbones sind analog zu „Zeichen entlang einer Autobahn“ (signs along a highway), die anzeigen, wann man einen neuen Funktionsbereich (z. B. "Welcome to the checkout process") betritt19.
2. Funktion: Vollständigkeit und Kontext
Die horizontale Achse hat die primäre Funktion, den Kontext zu liefern und die Vollständigkeit der Produktvision zu gewährleisten, was in einem flachen Backlog unmöglich ist5....
• Trennung der Fragen: Die horizontale Achse trennt die Frage der Vollständigkeit von der Frage der Wichtigkeit (die von der vertikalen Achse beantwortet wird)5. Die horizontale Frage lautet: "Haben wir an die gesamte Reise gedacht?" (Sind alle notwendigen Backbone-Schritte vorhanden?)5.
• Das Große Ganze: Die chronologische Anordnung hilft, das "große Ganze" (the big picture) sichtbar zu machen421. Das Backbone bildet in seiner Gesamtheit eine vereinfachte, aber vollständige Darstellung der User Journey1....
• "Mile-wide, inch-deep": Im Prozessschritt "Map the Big Picture" (Teil des fünfstufigen Patton-Prozesses) besteht die Aufgabe darin, den gesamten Prozess des wichtigsten Nutzer-Typs zu skizzieren, was als „mile‑wide, inch‑deep“ (meilenweit, zoll-tief) beschrieben wird2324.
3. Anatomie und Granularität
Die horizontale Achse selbst kann unterschiedliche Abstraktionsebenen innerhalb der obersten Reihen der Map umfassen10...:
• Oberste Ebene (Backbone/Themen): Enthält die höchsten Ziele oder Aktivitäten10....
• Zweite Ebene (Epics/Schritte): Gruppiert User Stories zu funktionalen Einheiten (z. B. "Produkte vergleichen") und bildet eine Brücke zwischen dem Backbone und den Stories14.... Diese Schritte sind Unteraufgaben, die für das übergeordnete Ziel der Aktivität nötig sind10....
4. Rolle im Workshop und Fallstricke
Die Definition des Backbones ist der zweite Schritt im Story Mapping Workshop2627.
• Workshop-Prozess: Ausgehend von den definierten Personas werden die groben Aktivitäten chronologisch gesammelt1328. Ein gängiger Ansatz ist, dass alle Teilnehmer zunächst schweigend (z. B. in 10 Minuten) alle Hauptaktivitäten brainstormen27. Anschließend werden diese kollaborativ in die richtige chronologische Reihenfolge gebracht, um das initiale Backbone zu bilden27.
• Vermeidung von Lücken: Die Story Map zwingt das Team, zuerst die gesamte Reise horizontal abzubilden29. Dieser Prozess macht Lücken (gaps)29 und fehlende Funktionalitäten sofort visuell ersichtlich2129.
• Fallstrick ("Broken Backbone"): Ein häufiger Fehler (Pitfall) ist der "gebrochene" Backbone, bei dem die chronologische Reihenfolge oder die Abstraktionsebene vermischt wird30. Das Backbone muss strenge Disziplin wahren und nur aus Benutzer-Aktivitäten (Verben) bestehen, die die User Journey aus Nutzersicht beschreiben30.
Die horizontale Achse ist somit das Fundament der Story Map und der grundlegende Mechanismus, der das agile Team dazu zwingt, den gesamten Prozess aus der Sicht des Benutzers zu verstehen, bevor einzelne Details oder Prioritäten (vertikale Achse) diskutiert werden.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Horizontale Achse (Backbone)“ über „Narrative Klammer/Chronologische Reihenfolge“ aussagen.

Die horizontale Achse der User Story Map (USM), bekannt als das "Backbone" (Rückgrat)1..., ist das zentrale Element, das die narrative und chronologische Struktur der gesamten Methode festlegt.
I. Definition als Narrative Klammer und Struktur
Die horizontale Achse ist die narrative Klammer des Produkts14. Ihre primäre Funktion ist es, die Produktarbeit als eine zusammenhängende Geschichte zu strukturieren67.
Chronologische Reihenfolge
• Anordnung: Die Aktivitäten auf dieser Achse werden von links nach rechts in chronologischer Reihenfolge angeordnet1....
• Narrativer Fluss: Die Reihenfolge, in der ein typischer Nutzer die Schritte ausführt, wird als Narrative Flow oder Narrative bezeichnet8....
• Leserichtung: Um die Map horizontal zu lesen und den narrativen Ablauf zu verstehen, kann man mental das Wort "dann" (then) zwischen den Karten oder Schritten einfügen1014.
• Visualisierung: Diese Anordnung macht die einzelnen Schritte der Nutzerreise sichtbar und setzt sie in Beziehung zueinander67.
Inhalt und Granularität
Das Backbone besteht aus den großen Schritten1 oder wichtigsten Aktivitäten oder Themen des Nutzers2.... Diese Elemente sind grobgranulare Epics oder Benutzeraktivitäten (User Activities)1....
• Zweck: Diese Aktivitäten zeigen das „Warum“ hinter den folgenden User-Stories2....
• Darstellung der Journey: In ihrer Gesamtheit bilden die chronologisch angeordneten Aktivitäten eine vereinfachte, aber vollständige Darstellung der User Journey14.
• Beispiel: Bei einer E-Commerce-Plattform könnte die chronologische Abfolge lauten: "Produkte erkunden" → "Produkte vergleichen/auswählen" → "Zur Kasse gehen/Bezahlen" → "Bestellung verfolgen/empfangen"115.
II. Ziele und Prozess im Workshop
Die chronologische Anordnung im Backbone ist der erste kritische Schritt im Story Mapping Workshop und dient der Vollständigkeitsprüfung.
1. Backbone definieren: Der Workshop beginnt damit, dass, ausgehend von den Personas, die groben Aktivitäten (Epics/Themen) chronologisch gesammelt werden12.... Anschließend werden diese Aktivitäten kollaborativ in die richtige chronologische Reihenfolge von links nach rechts gebracht18.
2. Vollständigkeitsfrage: Die horizontale Achse beantwortet die Frage: "Haben wir an die gesamte Reise gedacht?"419. Die Story Map zwingt das Team, zuerst die gesamte Reise horizontal abzubilden420.
3. Vermeidung von Fehlern: Ein häufiger Fallstrick (Pitfall) ist der "gebrochene" Backbone (Broken Backbone), bei dem die horizontale Achse nicht chronologisch ist oder verschiedene Abstraktionsebenen vermischt. In diesem Fall bricht die narrative Struktur zusammen und die Map wird unlesbar21.
Die chronologische Anordnung ermöglicht es somit, jede einzelne User Story fest im Kontext der gesamten Customer Journey zu verankern422, was die Story Map zu einer kontextreichen Landkarte macht23.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Horizontale Achse (Backbone)“ über „Besteht aus 'Großen Schritten' / 'Benutzeraktivitäten' (Epics)“ aussagen.

Die horizontale Achse, bekannt als das "Backbone" (Rückgrat)1..., ist das strukturelle Fundament der User Story Map und dient als "narrative Klammer" des gesamten Produkts14. Die Quellen sagen aus, dass diese Achse primär aus groben, benutzerzentrierten Komponenten besteht.
I. Zusammensetzung: Große Schritte und Aktivitäten
Das Backbone setzt sich aus Elementen zusammen, die die höchste Abstraktionsebene der Produktfunktionalität darstellen:
• Große Schritte und Aktivitäten: Das Backbone besteht aus den "großen Schritten"1 oder "Benutzeraktivitäten" (User Activities)1.... Diese Aktivitäten beschreiben hohe Ziele des Nutzers6....
• Themen (Themes): Die horizontale Achse kann auch als Themen1... bezeichnet werden. Sie enthält die wichtigsten Aktivitäten oder Themen des Nutzers in chronologischer Reihenfolge2....
• Grobgraulare Epics: Diese Aktivitäten sind grobgraulare Epics1. Sie stellen eine Sammlung von Schritten dar, die ein Benutzer durchführt, um sein übergeordnetes Ziel mit dem Produkt zu erreichen1. In einigen Modellen werden Epics/Schritte als die zweite Zeile unter den Themen/Backbone einsortiert, um eine Brücke zu den detaillierteren User Stories zu schlagen3....
II. Funktion und Narrative
Die Anordnung dieser groben Schritte definiert den narrativen Fluss und den Kontext der gesamten Map:
• Chronologische Reihenfolge: Die Elemente im Backbone werden strikt von links nach rechts in chronologischer Reihenfolge angeordnet1.... Diese Sequenz zeigt die Schritte, die ein typischer Nutzer ausführt711.
• Narrative Klammer: Das Backbone ist die narrative Klammer des Produkts14. Die horizontale Dimension repräsentiert eine Sequenz, die beim Lesen durch das mentale Einfügen des Wortes "dann" (then) zwischen den Schritten verstanden wird1012.
• User Journey: Die Aktivitäten bilden in ihrer Gesamtheit eine vereinfachte, aber vollständige Darstellung der User Journey14. Die Map soll den gesamten Prozess des wichtigsten Nutzer-Typs skizzieren ("mile-wide, inch-deep")13....
• "Warum" und "Big Picture": Die Aktivitäten oder Themen zeigen das „Warum“ hinter den folgenden detaillierten User-Stories2... und helfen, das "große Ganze" (the big picture)1617 zu visualisieren, was bei flachen Backlogs unmöglich ist18.
III. Beispiele für Backbone-Aktivitäten
Konkrete Anwendungsbeispiele verdeutlichen, dass das Backbone die Hauptphasen der Nutzerinteraktion darstellt:
• E-Commerce: Ein Backbone für eine E-Commerce-Plattform könnte lauten: "Produkte erkunden" → "Produkte vergleichen/auswählen" → "Zur Kasse gehen/Bezahlen" → "Bestellung verfolgen/empfangen"1....
• Mobile Banking: Bei einer Banking-App bilden Aktivitäten wie "Kontostand anzeigen", "Geld überweisen" und "Rechnungen bezahlen" das Backbone2122.
• Elektroauto Online-Präsenz: Bei einer Online-Präsenz für Elektroautos könnten die Schritte "Marke und Modell kennenlernen", "Ausstattung konfigurieren", "Kaufentscheidung treffen" und "Bestellung tätigen" das Backbone bilden23.
Das Backbone ist somit die strategische Ebene der Story Map24. Es definiert die Abfolge, bevor die detaillierten User Stories (die eigentlichen Teilschritte und Aufgaben) in der vertikalen Achse darunter gesammelt und priorisiert werden1....

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Horizontale Achse (Backbone)“ über „Stellt vereinfachte User Journey dar“ aussagen.

Die horizontale Achse, bekannt als das "Backbone" (Rückgrat), ist das Kernelement der User Story Map (USM) und erfüllt die Funktion, eine vereinfachte, aber vollständige Darstellung der User Journey abzubilden12. Diese Struktur ist der entscheidende Unterschied zum eindimensionalen, flachen Backlog, das den Gesamtzusammenhang (the big picture) nicht sichtbar macht3....
1. Definition und Chronologischer Fluss der Journey
Das Backbone ist die narrative Klammer des gesamten Produkts12. Die gesamte horizontale Achse ist darauf ausgelegt, die Schritte der Nutzerreise sichtbar zu machen und in Beziehung zueinander zu setzen5....
• Inhalt: Das Backbone besteht aus den wichtigsten Aktivitäten oder Themen des Nutzers in chronologischer Reihenfolge8.... Diese werden als "große Schritte"12, "Benutzeraktivitäten" (User Activities)1... oder grobgranulare Epics1 bezeichnet.
• Reihenfolge: Die Aktivitäten und Schritte verlaufen in einer Story Map von links nach rechts in der Reihenfolge, in der ein typischer Nutzer sie ausführt12....
• Leserichtung (Narrative): Weil die horizontale Dimension eine Abfolge (sequence) repräsentiert, kann man die Map über diese Achse hinweg lesen, indem man mental das Wort "dann" (then) zwischen die Karten oder Schritte einfügt1617. Beispielsweise im Kontext des E-Mail-Versands: Empfänger auswählen, dann Betreff eingeben, dann Nachricht verfassen, dann E-Mail senden1617.
2. Vereinfachte, aber Vollständige Darstellung
Die Story Map hat das Ziel, den gesamten Prozess des wichtigsten Nutzer-Typs zu skizzieren18.... Die grobgranularen Epics definieren dabei das "Rückgrat" des Produkts1.
• Vereinfachung: Die Aktivitäten/Themen auf dieser Ebene beschreiben hohe Ziele (z. B. "Kontoüberblick erhalten")12.... Die vertikale Achse fügt dann die Details und konkreten Interaktionen hinzu12.... Diese Struktur ermöglicht es dem Team, den Überblick ("Das große Ganze") zu behalten4....
• Umfang: Jeff Patton beschreibt diese Ebene des Mapping-Prozesses als "mile-wide, inch-deep" (meilenweit, zoll-tief)18....
Beispiele für die vereinfachte User Journey:
Die Quellen illustrieren dies anhand konkreter Fallstudien:
• E-Commerce-Plattform: Das Backbone bildet die Reise ab: "Produkte erkunden" → "Produkte vergleichen/auswählen" → "Zur Kasse gehen/Bezahlen" → "Bestellung verfolgen/empfangen"123.
• Online-Lieferdienst: Die simplifizierte Journey umfasst: "Restaurant/Küche wählen" → "Speisen auswählen/Warenkorb" → "Bestellen/Bezahlen" → "Bestellung verfolgen/empfangen"24.
• Mobile-Banking-App: Das Backbone könnte Aktivitäten wie "Kontostand anzeigen", "Geld überweisen" und "Rechnungen bezahlen" umfassen25....
3. Strategischer Nutzen (Frage der Vollständigkeit)
Die vereinfachte Darstellung der User Journey auf der horizontalen Achse ist entscheidend, um die Vollständigkeit des Produkts sicherzustellen, eine Funktion, die einem flachen Backlog fehlt2829.
• Die horizontale Frage: Die Story Map trennt die horizontale Frage der Vollständigkeit von der vertikalen Frage der Wichtigkeit28. Die horizontale Frage lautet: "Haben wir an die gesamte Reise gedacht?" (Sind alle notwendigen Backbone-Schritte vorhanden?)28.
• Lückenerkennung: Die Story Map zwingt das Team, zuerst die gesamte Reise horizontal abzubilden29. Dies macht Lücken (gaps) und fehlende Funktionalitäten sofort visuell ersichtlich15....
Die Darstellung der vereinfachten User Journey auf der horizontalen Achse ist somit der Mechanismus, der es dem Team ermöglicht, benutzerzentriert zu arbeiten4..., indem er sicherstellt, dass alle geplanten Features (die Stories darunter) im richtigen Kontext der gesamten Customer Journey verankert sind231.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Horizontale Achse (Backbone)“ über „Frage: 'Haben wir an die gesamte Reise gedacht?' (Vollständigkeit)“ aussagen.

Die horizontale Achse, bekannt als das Backbone (Rückgrat), bildet die narrative Klammer des User Story Mappings (USM) und ist fundamental dafür verantwortlich, die Frage der Vollständigkeit zu beantworten1....
Die Quellen stellen klar, dass die primäre Funktion der horizontalen Achse darin besteht, die Frage zu klären: "Haben wir an die gesamte Reise gedacht?"2.
1. Die Rolle der Horizontalen Achse als Strukturgeber
Das Story Mapping trennt als zweidimensionale Matrix zwei Fragen, die in einem flachen Backlog, das oft als "Sack voller kontextfreiem Mulch" empfunden wird, vermischt werden: die horizontale Frage der Vollständigkeit und die vertikale Frage der Wichtigkeit12.
• Das Backbone: Die horizontale Achse bildet das "Backbone"13. Sie ist chronologisch von links nach rechts angeordnet1....
• Der Inhalt: Das Backbone besteht aus den "großen Schritten"1, Benutzeraktivitäten (User Activities)1... oder Themen1..., die ein Benutzer durchführen muss, um sein übergeordnetes Ziel zu erreichen1. Diese Aktivitäten sind grobgranulare Epics1.
• Narrative Klammer: Die horizontale Anordnung stellt eine vereinfachte, aber vollständige Darstellung der User Journey dar und definiert das "Rückgrat" des Produkts13. Die Abfolge wird gelesen, indem man mental das Wort "dann" (then) zwischen die Schritte einfügt5.
2. Die Vollständigkeitsprüfung (Gaps)
Durch die Verpflichtung, die gesamte Reise horizontal abzubilden, zwingt die Story Map das Team, über den gesamten Prozess nachzudenken9.
• Der Vorteil: Die horizontale Achse beantwortet die Frage der Vollständigkeit, indem sie prüft, ob alle notwendigen Backbone-Schritte vorhanden sind2.
• Visuelle Erkennbarkeit: Dieses zweidimensionale Layout hilft Teams, Lücken (gaps) und fehlende Funktionalitäten sofort visuell ersichtlich zu machen9.... Im Gegensatz dazu ist die Vollständigkeitsprüfung bei einem flachen Backlog schwierig, und Lücken werden oft übersehen13.
• Risikominimierung: Die Lückenidentifikation, die im Rahmen des Story Mapping Workshops durch das narrative Abwandern der Map erfolgt, ist der kritischste Schritt, in dem der eigentliche Wert entsteht1415. Dabei werden unweigerlich Lücken, Engpässe und Abhängigkeiten aufgedeckt, die in einer einfachen Liste verborgen geblieben wären14.... Ein Beispiel hierfür ist die vergessene Passwort-Wiederherstellung9.
3. Das strategische Ergebnis
Die Antwort auf die Frage der Vollständigkeit ist essenziell für die agile Planung und die Lieferung von Nutzerwert.
• End-to-End-Weg: Das Ziel der horizontalen Achse ist es, sicherzustellen, dass die geplante Entwicklung, insbesondere das Minimum Viable Product (MVP), einen funktional vollständigen End-to-End-Weg durch das Produkt darstellt1819.
• Walking Skeleton: Die oberste horizontale Scheibe (Slice), die das MVP definiert, muss (mindestens) eine Story aus jedem kritischen Backbone-Schritt enthalten1819. Dadurch wird gewährleistet, dass das Ergebnis, das oft als "Walking Skeleton" (laufendes Skelett) bezeichnet wird, eine minimale, aber durchgängig funktionsfähige Version des gesamten Systems ist18....
Indem die Story Map das Team dazu zwingt, zunächst die gesamte User Journey horizontal abzubilden, bevor vertikal über die Wichtigkeit einzelner Stories diskutiert wird, stellt sie sicher, dass der Kontext des "großen Ganzen" (the big picture) erhalten bleibt13... und die Frage "Haben wir an die gesamte Reise gedacht?" jederzeit beantwortet werden kann2.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Anatomie & Struktur“ über „Vertikale Achse (Priorität & Details)“ aussagen.

Die vertikale Achse ist das zweite fundamentale Strukturelement der User Story Map (USM) und ergänzt das horizontale Backbone durch die Dimensionen Priorität und Detaillierung12. Diese Achse ist entscheidend, um das traditionelle, flache Backlog zu überwinden, indem sie die Frage der Wichtigkeit klar von der Frage der Vollständigkeit trennt23.
Im Kontext von „Anatomie & Struktur“ treffen die Quellen folgende Aussagen über die vertikale Achse:
1. Definition und Zweck
• Vertikale Anordnung: Die vertikale Achse wird unterhalb jedes Schritts im Backbone (der horizontalen Achse) aufgebaut2.
• Inhalt: Hier werden die detaillierten Teilschritte2, also die eigentlichen User Stories und Aufgaben, gesammelt2....
• Detaillierungsgrad: Die Detailtiefe des Produkts nimmt nach unten zu9.... Die Stories selbst beschreiben konkrete Interaktionen des Nutzers (z. B. "Benutzername eingeben", "Passwort eingeben")11....
2. Priorität als Ordnungsprinzip
Die vertikale Achse dient primär der Priorisierung der Arbeitspakete in jeder Spalte2....
• Wichtigkeitsachse: Die vertikale Anordnung repräsentiert die Priorität24.
• Sortierung: Die User Stories werden vertikal nach Priorität sortiert4....
• Platzierung der Must-haves: Die wichtigsten4..., für die Kernfunktion unverzichtbaren Stories ("Must-haves")2... werden direkt unter dem Backbone-Schritt platziert (also ganz oben in der Spalte)2....
• Niedrige Priorität: Darunter folgen Stories mit geringerer Priorität2, alternative Lösungswege2, "Nice-to-have"-Funktionen2 oder Ideen für spätere Versionen2.
3. Die Vertikale Frage und der Nutzen
Die vertikale Achse trennt die Prioritätsfrage von der chronologischen Frage des Backbones und fokussiert auf den Wert2.
• Die Frage der Wichtigkeit: Die vertikale Achse beantwortet die vertikale Frage des Story Mappings2: "Was ist der wichtigste Teil jedes Schritts?"2.
• Wert als Kriterium: Die Wichtigkeit ergibt sich dabei aus einer Kombination von Nutzen, Risiko und technischem Aufwand15....
• Alternativen: Beim Lesen der vertikalen Achse wird mental das Wort "oder" (or) zwischen den Karten eingefügt, da sie alternative Möglichkeiten zur Erreichung des Ziels des Backbone-Schritts darstellen können1920.
4. Beziehung zur horizontalen Achse und Granularität
Die vertikale Achse steht in direkter Beziehung zur horizontalen Achse, da sie die groben Aktivitäten (Backbone) in implementierbare Einheiten zerlegt.
• Epics/Schritte als Brücke: Die User Stories werden Epics/Schritten zugeordnet (die zweite Zeile unterhalb des Backbones), die als funktionale Einheiten die Brücke zwischen dem Backbone und den detaillierten Stories bilden5....
• Granularität: Die Stories in der vertikalen Achse sind typischerweise kleine, implementierungsfähige User Stories23. Größere Tasks können in kleinere Tasks oder UI-Details heruntergebrochen werden2425.
• Abgrenzung: Im Gegensatz zu den Cards im Backbone, die selbst meist nicht direkt implementiert werden, werden die Cards in der vertikalen Achse in den Sprint übernommen2026.
5. Priorisierungsmethoden
Die Strukturierung der vertikalen Achse kann durch verschiedene methodische Frameworks unterstützt werden, um eine fundierte Priorisierung zu gewährleisten27.
• MoSCoW: "Must-have"-Stories werden in den Spalten ganz nach oben sortiert und bilden kollektiv den natürlichen MVP-Slice27.
• Value vs. Complexity: Stories mit hohem Wert und geringer Komplexität ("Quick Wins") werden am höchsten platziert27.
• WSJF: Stories mit dem höchsten WSJF-Score werden am höchsten priorisiert, um den ökonomischen Wertfluss zu optimieren27.
Die vertikale Achse der Story Map erfüllt somit den Zweck, alle Anforderungen für einen bestimmten Schritt der User Journey zu sammeln und diese transparent und nachvollziehbar nach Wichtigkeit zu ordnen1517. Dies ist der Grundstein für die spätere Release-Planung durch das horizontale "Slicing"6....

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Vertikale Achse (Priorität & Details)“ über „Enthält detaillierte Teilschritte / User Stories / Tasks“ aussagen.

Die vertikale Achse der User Story Map (USM) ist strukturell darauf ausgelegt, die Arbeitspakete zu detaillieren und zu priorisieren, indem sie die dem horizontalen Backbone (Rückgrat) zugeordneten detaillierten Teilschritte, User Stories und Aufgaben enthält12.
1. Inhalt und Definition der Elemente
Die vertikale Achse wird unterhalb jedes Schritts im Backbone (der horizontalen Achse) aufgebaut12. Sie enthält die eigentlichen Arbeitseinheiten, die entwickelt werden müssen:
• Detaillierte Teilschritte/Aufgaben: Hier werden die detaillierten Teilschritte gesammelt, die zur Durchführung der übergeordneten Benutzeraktivität im Backbone notwendig sind12.
• User Stories: Die User Stories sind das Herzstück dieses Abschnitts. Sie sind kurz formulierte Aussagen aus Sicht des Nutzers3..., oft in der klassischen Formulierung ("Als [Typ] will ich [Ziel], um [Mehrwert]")3.... Diese Stories beschreiben konkrete Funktionen3.... Vereinfacht gesagt, ist eine User Story ein Feature, welches für die Software entwickelt werden soll6.
• Granularität: Diese Elemente sind die kleineren Tasks und UI-Details, in die größere Aufgaben heruntergebrochen werden78. Auf dieser Ebene beschreiben die Details konkrete Interaktionen (z. B. "Benutzername eingeben" oder "Passwort eingeben")9.... Die Stories sind typischerweise kleinere, implementierungsfähige (small implementation sized) User Stories, die gut in Sprints passen12.
2. Detaillierung und Hierarchie
Die vertikale Anordnung erfüllt nicht nur die Funktion der Priorisierung, sondern auch die des Detaillierungsgrads1.
• Zunehmende Detailtiefe: Die Detailtiefe nimmt nach unten zu10.... Die wichtigsten Stories stehen ganz oben, während alternative oder weniger wichtige Stories weiter unten folgen1.
• Epics als Brücke: Die Zeile der Epics/Schritte (die zweite Zeile, direkt unter dem Backbone) dient als Brücke zwischen dem grobgranularen Backbone und den detaillierten User Stories4.... Diese Epics gruppieren User Stories zu funktionalen Einheiten (z. B. "Produkte vergleichen" in einem Shop)4....
3. Der Sammlungsprozess im Workshop
Die Sammlung dieser detaillierten Stories findet im Schritt 2 ("Detaillierung der Stories") des Story Mapping Workshops statt2:
• Brain Dump: Nachdem das Backbone feststeht, führt das Team einen "Brain Dump" durch216.
• Fokus auf Vollständigkeit: Für jede Aktivität im Backbone sammelt das Team nun alle Teilschritte, Aufgaben und User Stories, die zur Durchführung dieser Aktivität notwendig sind217.
• Unsotiert und Ideenreich: Die Stories werden (zunächst unsortiert) unter die jeweilige Backbone-Aktivität gehängt217. In dieser Phase hat die Vollständigkeit der gesammelten Ideen, Alternativen und Bedenken Priorität vor der Priorisierung218.
Anschließend, in Schritt 3 ("Strukturierung und Priorisierung"), werden diese gesammelten User Stories innerhalb ihrer vertikalen Spalte nach Wichtigkeit sortiert219, um die Basis für das Slicing (Release-Planung) zu schaffen20.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Vertikale Achse (Priorität & Details)“ über „Priorisierung: Wichtigste Stories oben (Must-haves)“ aussagen.

Die vertikale Achse der User Story Map (USM) ist primär dafür konzipiert, die Priorität und den Detaillierungsgrad der User Stories zu organisieren1. Im Kontext der Priorisierung besagen die Quellen eindeutig, dass die wichtigsten Stories ganz oben in ihrer jeweiligen Spalte platziert werden müssen, da sie die unverzichtbaren "Must-haves" darstellen.
1. Positionierung der Wichtigsten Stories
Die Anordnung der Stories entlang der vertikalen Achse erfolgt in absteigender Reihenfolge der Priorität2...:
• Höchste Priorität (Ganz Oben): Die Stories, die für die Kernfunktion unverzichtbar sind16 oder die für eine minimale Funktionsfähigkeit dieses Schritts unerlässlich sind ("Must-haves")7, werden direkt unter dem Backbone-Schritt platziert (also ganz oben in der Spalte)17.
• Absteigende Priorität: Darunter folgen Stories mit geringerer Priorität17, alternative Implementierungen oder "Nice-to-have"-Funktionen17.
Beim Lesen der vertikalen Achse ist die oberste Karte die wichtigste2.
2. Kriterien für die Priorisierung
Die vertikale Sortierung der Stories basiert auf dem Kriterium der Wichtigkeit, die sich aus verschiedenen Faktoren ableitet:
• Nutzen, Risiko und technischer Aufwand: Die Wichtigkeit wird vertikal sortiert89 und ergibt sich aus einer Kombination von Nutzen, Risiko und technischem Aufwand89.
• Methoden: Spezifische Methoden wie die MoSCoW-Methode werden zur Priorisierung herangezogen10. Bei MoSCoW werden die "Must-have"-Stories in den Spalten ganz nach oben sortiert10.
• Gemeinsame Definition: Stakeholder sollten diesen Prozess nutzen, um gemeinsam zu definieren, welche Stories in das MVP gehören89.
3. Konsequenzen der Priorisierung (MVP-Definition)
Die Platzierung der "Must-haves" ganz oben ist der direkte Mechanismus zur Definition des Minimum Viable Product (MVP) durch das horizontale "Slicing"10.
• MVP-Slice: Die Stories, die als "Must-haves" nach oben geschoben wurden7, bilden kollektiv den natürlichen MVP-Slice10.
• Walking Skeleton: Diese Priorisierung stellt sicher, dass die oberste horizontale Scheibe (der MVP-Slice) den dünnsten, aber funktional vollständigen End-to-End-Weg durch das Produkt darstellt – den sogenannten "Walking Skeleton"9....
Beispiele verdeutlichen dies:
• In einer Mobile-Banking-App muss die Anzeige des Kontostands in der ersten Release-Slice enthalten sein, da sie eine Kernfunktion darstellt (Must-have), während komplexere Funktionen wie das Einrichten von Daueraufträgen in einer späteren Version folgen können1314.
• Für eine E-Commerce-Plattform sind die grundlegenden Schritte, wie die Stichwortsuche und die Bezahlung mit Kreditkarte, als Prio 1 Stories ganz oben platziert, um den minimalen Kaufzyklus im MVP zu gewährleisten1516.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Vertikale Achse (Priorität & Details)“ über „Darunter: Geringere Priorität / Nice-to-haves / Alternativen“ aussagen.

Die vertikale Achse der User Story Map (USM) ist die Achse der Priorität und Detaillierung1. Im Kontext dieser Achse definieren die Quellen klar, dass Elemente, die unterhalb der obersten Prioritätsreihe (den "Must-haves") platziert werden, geringere Wichtigkeit, Alternativen oder Funktionen für spätere Ausbaustufen repräsentieren.
1. Position und Priorität
Die Anordnung der Stories entlang der vertikalen Achse ist ein direktes visuelles Priorisierungsinstrument1.
• Absteigende Priorität: Die vertikale Achse zeigt, dass die wichtigsten und für die Kernfunktion unverzichtbaren Stories direkt unter dem horizontalen Backbone (ganz oben in der Spalte) platziert werden12. Darunter folgen Stories mit geringerer Priorität1.
• "Nice-to-haves" wandern nach unten: Stories, die weniger wichtig sind, werden weiter nach unten geschoben3. Dazu gehören "Nice-to-have"-Funktionen13 oder Ideen für spätere Versionen1.
• Minimal Nützliches: Die Stories, die für eine minimale Funktionsfähigkeit eines Schritts unerlässlich sind ("Must-haves"), werden nach oben geschoben3. Dies impliziert, dass alle darunter liegenden Stories nicht zum minimal Nützlichen4 gehören und somit sekundär sind.
2. Darstellung von Alternativen
Die vertikale Dimension dient nicht nur der Priorisierung, sondern auch der Darstellung von Alternativen5.
• Das mentale "Oder": Beim Lesen von oben nach unten durch eine Spalte von Stories fügt man mental das Wort "oder" (or) zwischen den Karten ein5. Dies verdeutlicht, dass die darunter liegenden Stories alternative Lösungswege zur Erreichung des übergeordneten Backbone-Ziels darstellen15.
• Priorisierung von Alternativen: Karten, die Alternativen enthalten, sollten in absteigender Reihenfolge der Priorität platziert werden: die wichtigste oben und die am wenigsten wichtige unten2. Beispielsweise gibt es mehrere Möglichkeiten, Empfänger einer E-Mail auszuwählen (Adresse eingeben oder Name eingeben oder aus Kontakten wählen)25.
3. Rolle in nachfolgenden Releases
Die Stories mit geringerer Priorität bilden die Grundlage für die nachfolgenden Releases, die durch horizontales "Slicing" definiert werden.
• Aufbau auf dem MVP: Die Slices unterhalb der MVP-Linie (der ersten horizontalen Trennlinie) repräsentieren nachfolgende Releases (z.B. Version 1.1, 2.0)6.
• "Mehr Fleisch": Diese nachfolgenden Releases haben das Ziel, dem "Walking Skeleton" (dem funktional vollständigen MVP) mehr "Fleisch" hinzuzufügen67.
• Beispiele für nachgelieferte Funktionen: Dies kann durch die Implementierung von höher priorisierten Alternativen geschehen (z.B. das Hinzufügen von PayPal als zweite Zahlungsoption zur Kreditkartenzahlung im E-Commerce-Shop68) oder durch die Ergänzung von "Nice-to-have"-Funktionen (z.B. das Anwenden von Gutscheincodes6).
• Abstufung des Details: Das Beispiel der Konfiguration eines Elektroautos zeigt die absteigende Priorität der Ausbaustufen: Die erste einfache Umsetzung ist eine Liste von Ausstattungsmerkmalen9. Später folgen eine Innen- und Außendarstellung, dann eine 3D-Ansicht und schließlich Augmented Reality10. Ähnlich werden bei Fitness-Apps GPS-Tracking oder Kalorien-Scanning in späteren Releases realisiert1112.
Somit stellt die vertikale Achse sicher, dass das Team zwar die gesamte Palette an potenziellen Funktionen und Alternativen erfasst, aber klar visuell trennt, welche davon minimal notwendig (oben) und welche optional oder für spätere Produktverbesserungen (darunter) sind1.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Vertikale Achse (Priorität & Details)“ über „Frage: 'Was ist der wichtigste Teil jedes Schritts?' (Wichtigkeit)“ aussagen.

Die vertikale Achse der User Story Map (USM) ist das strukturgebende Element, das sich primär der Frage der Wichtigkeit und Priorität widmet. Sie ist der Mechanismus, der das USM-System von einem eindimensionalen, flachen Backlog unterscheidet, indem sie die Frage der Vollständigkeit (horizontal) von der Frage der Priorität (vertikal) trennt1.
Im Kontext der vertikalen Achse besagen die Quellen:
1. Die zentrale Frage der Wichtigkeit
Die vertikale Anordnung in der Story Map repräsentiert die Priorität und den Detaillierungsgrad1. Die Story Map ist so konzipiert, dass die vertikale Achse eine spezifische Produktmanagement-Frage beantwortet:
• Die vertikale Frage lautet: "Was ist der wichtigste Teil jedes Schritts?"1.
• Diese Frage kann auch formuliert werden als: "Welche Story in dieser Spalte liefert den meisten Wert?"1.
Diese Fokussierung auf die Wichtigkeit steht im direkten Gegensatz zum flachen Backlog, das diese Trennung nicht leisten kann1. In einem flachen Backlog konkurrieren Stories unterschiedlicher Wichtigkeit und Kontext miteinander (z.B. eine wichtige Story für den Bezahlvorgang mit einer weniger wichtigen Story für die Passwort-Wiederherstellung)2.
2. Priorisierung und Wert als Kriterium
Die Beantwortung dieser Frage führt zur klaren Sortierung der User Stories in der jeweiligen Spalte (unterhalb des horizontalen Backbones):
• Sortierung nach Priorität: Die gesammelten User Stories werden innerhalb ihrer jeweiligen vertikalen Spalte nach Priorität sortiert34.
• Platzierung der Must-haves: Die wichtigsten Stories, die für die Kernfunktion unverzichtbar sind ("Must-haves"), werden direkt unter dem Backbone-Schritt platziert (ganz oben in der Spalte)15. Darunter folgen Stories mit geringerer Priorität, alternative Lösungswege, "Nice-to-have"-Funktionen oder Ideen für spätere Versionen1.
• Wichtigkeitskriterien: Die Wichtigkeit der Stories ergibt sich aus einer Kombination von Nutzen, Risiko und technischem Aufwand6....
3. Der Fokus auf Kundennutzen und "Value-Delivery"
Die Frage nach dem "wichtigsten Teil" zielt darauf ab, die Produktentwicklung auf den maximalen Kundennutzen auszurichten810.
• Vermeidung von Fehlpriorisierung: Durch diese Struktur wird verhindert, dass Teams das auswählen, was am einfachsten oder am interessantesten ist, anstatt das, was den höchsten Kundennutzen liefert811.
• Mentalitätswandel: Die Struktur erzwingt eine "Value-Delivery"-Mentalität12. Die zentrale Frage verschiebt sich hin zu: "Welches Problem des Nutzers lösen wir als Nächstes vollständig?"1213.
4. Verbindung zur Release-Planung
Die vertikale Sortierung basierend auf der Wichtigkeit ist die Grundlage für die Planung von Releases, insbesondere des MVP (Minimum Viable Product).
• Slicing-Grundlage: Die Stories, die für eine minimale Funktionsfähigkeit unerlässlich sind ("Must-haves"), werden nach oben geschoben und bilden so kollektiv den natürlichen MVP-Slice514.
• Definition des MVP: Das MVP ist dann der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt1516. Die Priorisierung (Wichtigkeit) stellt sicher, dass in jedem Schritt der User Journey (horizontal) mindestens die wichtigste Story enthalten ist, um einen minimalen, aber nutzbaren Ablauf (den "Walking Skeleton") zu schaffen15....
Zusammenfassend lässt sich sagen, dass die vertikale Achse die Stories nach ihrem Beitrag zum Nutzerwert (Wichtigkeit) ordnet und somit sicherstellt, dass die Entwicklungsteams immer die Stories zuerst angehen, die den größten Nutzen für den jeweiligen Schritt der Benutzerreise bieten119.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Anatomie & Struktur“ über „Elemente“ aussagen.

Die User Story Map (USM) transformiert das traditionelle, eindimensionale Backlog in eine zweidimensionale Matrix12 oder eine dreidimensionale Ansicht3. Diese Anatomie ist darauf ausgelegt, das "große Ganze" (the big picture) sichtbar zu machen und Kontext zu liefern3.
Die Struktur gliedert die Anforderungen hierarchisch in verschiedene Elemente, die entlang der horizontalen Achse (Vollständigkeit/Sequenz) und der vertikalen Achse (Priorität/Details) angeordnet sind4....
I. Die Hauptstruktur: Hierarchie und Granularität
Die Kernstruktur der Map umfasst drei Hauptgranularitätsebenen, wobei die Detailtiefe nach unten zunimmt5...:
1. Backbone/Themen (Oberste Zeile – Horizontale Achse)
Das Backbone (Rückgrat) bildet die horizontale Achse28 und dient als die narrative Klammer des Produkts29.
• Inhalt: Es enthält die wichtigsten Aktivitäten oder Themen des Nutzers10... in chronologischer Reihenfolge2.... Diese werden als "große Schritte"2 oder "Benutzeraktivitäten" (User Activities)2... bezeichnet und sind grobgranulare Epics2.
• Zweck: Sie zeigen das „Warum“ hinter den folgenden User-Stories10... und beschreiben hohe Ziele (z. B. Kontoüberblick erhalten1415).
• Lesart: Die horizontale Dimension repräsentiert eine Sequenz8. Man liest über die Achse, indem man mental das Wort "dann" (then) zwischen den Karten einfügt1316. Die Karten in der obersten Zeile sind analog zu Verkehrsschildern entlang einer Autobahn (signs along a highway), die anzeigen, wann man einen neuen Funktionsbereich betritt17.
2. Epics/Schritte (Zweite Zeile)
Diese Elemente bilden eine mittlere Abstraktionsebene, die die Verbindung zwischen dem Backbone und den detaillierten Stories herstellt:
• Inhalt: Sie gruppieren User Stories zu funktionalen Einheiten10... (z. B. Produkte vergleichen10...).
• Funktion: Sie dienen als Unteraufgaben, die für das Ziel nötig sind5... (z. B. Kontodetails eingeben, Scheck fotografieren, Scheck einreichen1415). In manchen Kontexten kann der Begriff Schritt (step) auch verwendet werden, um jede Karte auf der Map zu bezeichnen19.
3. User Stories/Tasks (Vertikale Achse)
Diese Elemente bilden die tatsächlichen Arbeitspakete, die implementiert werden sollen:
• Inhalt: Es sind kurz formulierte Aussagen aus Sicht des Nutzers7... („Als [Typ] will ich [Ziel], um [Mehrwert]“7...), die konkrete Interaktionen1415 oder Funktionen beschreiben7.... Beispiele für Details sind: Benutzername eingeben, Passwort eingeben1415.
• Vertikale Achse: Diese Stories werden unter den jeweiligen Backbone-Aktivitäten gesammelt4... und vertikal nach Priorität sortiert7.... Die wichtigsten Stories kommen nach oben7....
• Lesart: Die vertikale Dimension zeigt Alternativen13. Man liest sie, indem man mental das Wort "oder" (or) zwischen den Karten einfügt21.
II. Elemente der Release-Planung und des Kontextes
Zusätzlich zu den hierarchisch angeordneten Stories enthält die Map Elemente, die für die Planung, den Kontext und die Priorisierung erforderlich sind:
• Release-Slices (Cut-Lines): Dies sind horizontale Linien, die über die gesamte Breite der Map gezogen werden6.... Sie unterteilen die User-Stories in Releases/MVPs6... und legen die Versions- oder Release-Reihenfolge fest2324. Die oberste Reihe bildet dabei das Minimum Viable Product (MVP)22....
• Personas: Dies sind fiktive Nutzerprofile mit Zielen und Problemen6.... Sie werden über der Map platziert6... und sind unerlässlich6..., da die Map aus der Perspektive des Benutzers erstellt wird2627.
• Risiken und Status: Notizen und Risikokarten23... dienen dazu, unsichere Annahmen oder externe Abhängigkeiten sichtbar zu machen24.... Stories können mit Status wie todo, in Bearbeitung, erledigt, riskant markiert werden23....
• Technische Stories: Obwohl alle Elemente als Nutzeraktivitäten formuliert werden sollen und technische Formulierungen vermieden werden30..., müssen "unsichtbare" technische Stories (z. B. "Datenbank-Schema anlegen") von den Entwicklern an den richtigen Stellen in die Map eingefügt werden, um sie zu einer realistischen Planungsgrundlage zu machen3334.
Zusammenfassend lässt sich sagen, dass die Story Map ein visuelles Frontend für das gesamte Product Backlog wird35. Sie organisiert die Elemente nicht nur als Liste, sondern ordnet sie nach Benutzerziel (horizontal) und Wert (vertikal)436.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Elemente“ über „Personas (Fiktive Nutzerprofile)“ aussagen.

Personas (Fiktive Nutzerprofile) sind ein unerlässliches Element der User Story Map (USM)-Methode und dienen als Fundament, um die benutzerzentrierte Perspektive während der gesamten Produktplanung zu gewährleisten12.
Die Quellen sagen im Kontext von „Elemente“ und dem Nutzen von Personas Folgendes aus:
1. Definition und Platzierung
Personas sind definierte Artefakte, die direkt in die Struktur der Story Map integriert werden:
• Definition: Personas sind fiktive Nutzerprofile mit Zielen und Problemen34.
• Platzierung: Personas werden über der Map platziert34. Ihre primäre Funktion dort ist es, die Aktivitäten zuzuordnen34.
• Visualisierung: Im Kontext der visuellen Ordnung ist es eine empfohlene Praxis, Farben zur Unterscheidung von Personas (neben Priorität oder Status) zu verwenden5....
2. Die Persona als Voraussetzung für den Prozess
Die Definition von Personas ist keine optionale Ergänzung, sondern ein entscheidender Schritt in der Vorbereitung des Story Mapping Workshops. Sie verankert den Fokus auf den Nutzer von Anfang an:
• Unerlässlichkeit: Die Definition der Ziel-Personas ist unerlässlich1.... Jede Map muss mit einem tiefen Verständnis des Benutzers und seines Ziels beginnen10.
• Perspektive: Die gesamte Story Map wird explizit aus der Perspektive des Benutzers erstellt12.
• Problem-Framing: In der Vorbereitungsphase des Workshops, dem sogenannten Problem-Framing, muss das Team die Kernfragen definieren, wozu auch die Frage "Für wen?" gehört1....
• Backbone-Definition: Der eigentliche Workshop zur Erstellung des Backbones (der horizontalen Achse) beginnt ausgehend von Personas12.... Das Backbone wird durch das chronologische Sammeln der groben Aktivitäten definiert, die die Persona zur Erreichung ihres Ziels durchführen muss12....
3. Umgang mit multiplen Personas und Skalierung
Obwohl die Story Map idealerweise auf einer Hauptpersona aufbaut, bieten die Quellen Anweisungen für den Umgang mit komplexeren Produkten, die mehrere Nutzergruppen bedienen:
• Fokus auf Primärpersona: Es ist eine etablierte Best Practice, den ersten Workshop auf eine primäre Persona zu fokussieren, um die Komplexität zu reduzieren1.
• Mehrere Personas (Beispiele): Sobald das Produkt reift und weitere Nutzergruppen adressiert werden müssen16, müssen diese berücksichtigt werden. Beispielsweise werden beim Story Mapping für eine Mobile-Banking-App oft zwei Personas betrachtet: die Kontoinhaber*innen und das Bankpersonal17....
• Anpassung der Struktur: Anstatt für jede Persona eine komplett neue Map zu erstellen, passen fortgeschrittene Teams die bestehende Map an. Sie fügen neue horizontale Zeilen (Swimlanes) hinzu, um die spezifischen Stories der neuen Persona unterzubringen16. Dies hilft, die Unterschiede im Nutzerverhalten sichtbar zu machen16.
Zusammenfassend lässt sich sagen, dass Personas nicht nur ein dekoratives Element sind, sondern die Basis für die gesamte Entscheidungsfindung und Strukturierung der Story Map darstellen. Sie sind das Werkzeug, das gewährleistet, dass die Anforderungen konsistent aus der Perspektive des Endnutzers geordnet werden, bevor die Arbeit an den Funktionen beginnt2.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Elemente“ über „Backbone/Themen (Hohe Ziele)“ aussagen.

Die Elemente Backbone und Themen bilden die horizontale Achse der User Story Map (USM) und sind das Fundament der gesamten Struktur12. Sie definieren das Produkt nicht als eine Liste von Aufgaben, sondern als eine zusammenhängende Geschichte und sind der zentrale Mechanismus, um den Kontext des "großen Ganzen" (the big picture) sichtbar zu machen34.
Im Kontext der Anatomie und Struktur der USM sagen die Quellen Folgendes über das Backbone/Themen (Hohe Ziele) aus:
1. Definition, Position und Zweck
Das Backbone oder die Themen bilden die oberste Zeile der Story Map2....
• Horizontale Achse: Das Backbone ist die horizontale Achse der Map17.
• Narrative Klammer: Es fungiert als die narrative Klammer des Produkts18.
• Chronologische Reihenfolge: Die Elemente des Backbones sind von links nach rechts in chronologischer Reihenfolge angeordnet1.... Diese Sequenz repräsentiert die Schritte, die ein typischer Nutzer ausführt1011.
• Leserichtung: Man liest über die Map hinweg, indem man mental das Wort "dann" (then) zwischen den Schritten einfügt11.
• Analogie: Die Karten in der obersten Zeile sind analog zu "Schildern entlang einer Autobahn" (signs along a highway), die anzeigen, wann man einen neuen Funktionsbereich (z. B. "Welcome to the checkout process") betritt12.
2. Inhalt und Abstraktion ("Hohe Ziele")
Das Backbone beschreibt die Produktfunktionalität auf einem sehr hohen Abstraktionsgrad10....
• Inhalt: Es besteht aus den wichtigsten Aktivitäten oder Themen des Nutzers2... bzw. den "großen Schritten"1 oder Benutzeraktivitäten (User Activities)1.
• Hohe Ziele: Die Aktivitäten/Themen beschreiben hohe Ziele10.... Beispielsweise ist das "Kontoüberblick erhalten" ein solches hohes Ziel10....
• Granularität: Diese Aktivitäten sind grobgraulare Epics1.
• Funktion: Sie zeigen das „Warum“ hinter den folgenden detaillierten User-Stories2... und bilden in ihrer Gesamtheit eine vereinfachte, aber vollständige Darstellung der User Journey18.
3. Rolle im Planungsprozess
Die Definition des Backbones ist der zweite Schritt im Story Mapping Workshop15.
• Vollständigkeitsfrage: Die horizontale Achse beantwortet die Frage der Vollständigkeit: "Haben wir an die gesamte Reise gedacht?" (Sind alle notwendigen Backbone-Schritte vorhanden?)816.
• Implementierung: Karten im Backbone sind generell keine Stories, die direkt implementiert werden17. Sie dienen als Kontextgeber und werden später in kleinere, implementierbare Stories unterteilt1218.
• Patton's Prozess: Im Prozessschritt Frame werden die hohen Aktivitäten definiert19. Im Schritt Map the Big Picture wird der gesamte Prozess des wichtigsten Nutzer-Typs skizziert, was als „mile‑wide, inch‑deep“ (meilenweit, zoll-tief) beschrieben wird2021.
4. Beispiele für Backbone-Strukturen
Die Quellen liefern konkrete Beispiele für Backbone-Aktivitäten:
• E-Commerce: "Produkte erkunden" → "Produkte vergleichen/auswählen" → "Zur Kasse gehen/Bezahlen" → "Bestellung verfolgen/empfangen"122.
• Mobile Banking: Aktivitäten wie "Kontostand anzeigen", "Geld überweisen" und "Rechnungen bezahlen" bilden das Backbone2324.
• Elektroauto-Präsenz: Schritte wie "Marke und Modell kennenlernen", "Ausstattung konfigurieren", "Kaufentscheidung treffen" und "Bestellung getätigt"25.
Die kontextreiche Struktur, die durch das Backbone geschaffen wird, ist essenziell. Sie stellt sicher, dass das Team nicht nur an einzelnen Details arbeitet, sondern stets den vollständigen Ablauf im Blick hat, um ein funktional vollständiges Minimum Viable Product (MVP) definieren zu können2627.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Elemente“ über „Epics/Schritte (Unteraufgaben)“ aussagen.

Die Quellen definieren Epics/Schritte als ein spezifisches Hierarchieelement innerhalb der User Story Map (USM), das eine Brücke zwischen den grobgranularen Backbone-Aktivitäten (Themen) und den detaillierten User Stories (Tasks) bildet. Sie stellen die Ebene der Unteraufgaben dar.
Hier ist eine Diskussion darüber, was die Quellen im Kontext der Anatomie über Epics/Schritte aussagen:
1. Definition und Platzierung in der Struktur
Epics/Schritte sind als die zweite Zeile in der Struktur der Story Map definiert1....
• Einsortierung: Sie werden unter den jeweiligen Themen (den Backbone-Aktivitäten der obersten Zeile) einsortiert1....
• Funktionale Gruppierung: Ihre Hauptfunktion ist es, User Stories zu funktionalen Einheiten zu gruppieren1....
• Hierarchische Brücke: Epics/Schritte bilden eine Brücke zwischen dem Backbone und den Stories1....
2. Granularität und Rolle als Unteraufgaben
Epics/Schritte stellen eine mittlere Abstraktionsebene dar und sind explizit als Unteraufgaben charakterisiert:
• Unteraufgaben: Schritte/Epics sind die Unteraufgaben, die für das Erreichen des Ziels der übergeordneten Aktivität/des Themas nötig sind4....
• Detaillierung: Die Story Map ist hierarchisch aufgebaut, wobei die Detailtiefe nach unten zunimmt4...:
    ◦ Die Aktivitäten/Themen (Backbone) beschreiben hohe Ziele (z. B. Kontoüberblick erhalten)4....
    ◦ Die Schritte/Epics sind die Unteraufgaben auf der nächsten Ebene (z. B. Kontodetails eingeben, Scheck fotografieren, Scheck einreichen)4....
    ◦ Die Details/User Stories beschreiben konkrete Interaktionen (z. B. Benutzername eingeben, Passwort eingeben)4....
• Größe: Allgemein wird ein Epic als eine größere Einheit betrachtet9. Wenn man eine Aktivität in das Backlog aufnimmt, wird sie wahrscheinlich später in kleinere Steps oder User Stories aufgeteilt, damit diese Arbeitseinheiten gut in Sprints passen9.
3. Konkrete Beispiele
Die Quellen liefern spezifische Beispiele, wie Epics/Schritte User Stories gruppieren und Unteraufgaben darstellen:
• E-Commerce: Ein Beispiel für eine solche funktionale Einheit ist „Produkte vergleichen“ in einem Shop1....
• Banking: In einer Fallstudie zum Feature "Scheck einzahlen" werden die Aktivitäten (wie Scheck einzahlen) in Schritte zerlegt, die als Epics/Unteraufgaben fungieren, zum Beispiel: Mobil-Einzahlung starten, Scheck fotografieren und Überweisung bestätigen810.
Epics/Schritte sind somit das Element, das sicherstellt, dass die hochgranularen Ziele des Backbones in überschaubare, funktionsfähige Blöcke unterteilt werden, die wiederum die Basis für die eigentliche Entwicklung bilden.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Elemente“ über „User Stories/Tasks (Konkrete Interaktionen)“ aussagen.

Die User Stories/Tasks stellen das detaillierteste und implementierungsfähigste Element der User Story Map (USM) dar. Sie sind entlang der vertikalen Achse angeordnet und bilden die konkrete Arbeit, die das Entwicklungsteam leisten muss.
Hier ist eine Diskussion, was die Quellen im Kontext der „Elemente“ über „User Stories/Tasks (Konkrete Interaktionen)“ aussagen:
1. Definition und Anatomie
User Stories/Tasks sind die Elemente der Map, die sich unterhalb des horizontalen Backbones (Rückgrats) befinden1....
• Definition: Sie sind kurz formulierte Aussagen aus Sicht des Nutzers3.... Diese Aussagen folgen oft der klassischen Formulierung „Als [Typ] will ich [Ziel], um [Mehrwert]“ und beschreiben konkrete Funktionen3....
• Feature-Abbildung: Vereinfacht gesagt, ist eine User Story ein Feature, welches für die Software entwickelt werden soll6.
• Implementierungsgröße: Die Stories sind typischerweise kleine, implementierungsfähige (small implementation sized) User Stories7.
• Hierarchie: Sie stellen die höchste Detailtiefe dar. Die Detailtiefe nimmt nach unten zu8.... In der Granularitätshierarchie beschreiben die Details/User-Stories konkrete Interaktionen8..., während die oberen Ebenen (Aktivitäten/Themen und Epics/Schritte) hohe Ziele oder Unteraufgaben darstellen8....
2. Fokus auf Konkrete Interaktionen
User Stories fokussieren sich auf die tatsächlichen Interaktionen, die der Nutzer mit dem System durchführen wird, um die in den Epics definierten Ziele zu erreichen.
• Beispiele für Interaktionen: Wenn das Backbone die Aktivität "Scheck einzahlen" umfasst, fallen darunter die detaillierten Stories oder Tasks wie „Benutzername eingeben“ und „Passwort eingeben“8....
• Weitere Beispiele:
    ◦ Unter der Aktivität "Produkte erkunden" (E-Commerce) fallen Stories wie "Nach Stichwort suchen", "Nach Kategorie navigieren" oder "Ergebnisse nach Preis filtern"14.
    ◦ Unter der Aktivität "Tägliche Aktivitäten erfassen" (Fitness-App) fallen Stories wie "Schritte manuell eingeben" oder "Laufstrecke via GPS tracken"15.
    ◦ Für eine Mobile-Banking-App umfassen User Stories beispielsweise „Transaktionshistorie ansehen“ oder „Daueraufträge einrichten“1617.
3. Rolle in der Vertikalen Achse (Priorisierung)
Die User Stories bilden die Basis für die Priorisierung und Release-Planung auf der vertikalen Achse.
• Prioritätsordnung: Die gesammelten User Stories werden innerhalb ihrer jeweiligen Spalte vertikal nach Priorität sortiert1819. Die wichtigsten Stories (die "Must-haves") werden ganz oben platziert3.... Stories mit geringerer Priorität, alternative Implementierungen oder "Nice-to-have"-Funktionen wandern nach unten119.
• Alternativen: Die vertikale Dimension zeigt Alternativen; beim Lesen nach unten kann mental das Wort "oder" eingefügt werden, um anzuzeigen, dass diese Stories alternative Möglichkeiten darstellen2021.
4. Rolle im Workshop-Prozess
Die Sammlung der User Stories erfolgt in Schritt 2: Detaillierung der Stories22.
• Brain Dump: Sobald das Backbone steht, führt das Team einen "Brain Dump" durch2223.
• Sammlung: Für jede Backbone-Aktivität sammelt das Team alle Teilschritte, Aufgaben und User Stories, die zur Durchführung dieser Aktivität notwendig sind22....
• Vollständigkeit: In dieser Phase ist die Vollständigkeit wichtiger als Priorisierung1927.
5. Technische Stories
Neben den benutzer-sichtbaren Stories müssen auch technische Anforderungen (Technical Stories) berücksichtigt werden1828.
• Platzierung: Das Entwicklungsteam fügt "unsichtbare" technische Stories (z.B. "Datenbank-Schema anlegen", "Zahlungs-API integrieren") an den richtigen Stellen in die Map ein29.
• Regel: Es ist eine Best Practice, technische Aufgaben in separate Spalten (z.B. technische Epics) auszulagern, um die User-Zentrierung der Map nicht zu stören28....

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Elemente“ über „Release-Slices (Horizontale Schnittlinien)“ aussagen.

Die Release-Slices (oder Cut-Lines) sind ein essentielles Element der User Story Map (USM) und dienen als Mechanismus, um die zweidimensionale, priorisierte Map in einen konkreten, umsetzbaren Produktplan zu überführen12.
Die Quellen beschreiben die Release-Slices wie folgt:
1. Definition und Mechanismus des Slicing
Release-Slices sind horizontale Linien3..., die über die gesamte Breite der Map gezogen werden, nachdem die Stories vertikal nach Priorität sortiert wurden1.
• Zweck: Sie dienen dazu, die User Stories in Releases, MVPs, Sprints oder Iterationen zu unterteilen1....
• Release-Reihenfolge: Die Slices legen eine Versions- oder Release-Reihenfolge fest5.... Jede Scheibe (Slice) repräsentiert ein geplantes Release1.
• Kommunikation: Das Hinzufügen dieser Linien erlaubt es dem Product Owner, die beabsichtigte Liefersequenz von Features in den kommenden Releases visuell zu kommunizieren7.
• Meilensteine: Die Slices definieren Meilensteine in der Produktentwicklung, wie beispielsweise den Zeitpunkt der Erstellung eines MVP oder der Fertigstellung von Version 112.
2. Der Erste Slice: MVP und der "Walking Skeleton"
Der erste und wichtigste Slice ist die oberste Scheibe der Map, welche das Minimum Viable Product (MVP) definiert1....
• Neudefinition des MVP: Das Slicing definiert das Konzept des MVP fundamental neu13. Ein Story-Map-MVP ist nicht einfach eine Liste der wichtigsten Features ("die 5 wichtigsten Features")13.
• Walking Skeleton: Stattdessen bildet der erste Slice den "Walking Skeleton" (laufendes Skelett)6.... Das ist ein minimaler, aber nutzbarer Ablauf1014 und der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt1315.
• Anforderung an Stories: Der MVP-Slice muss (mindestens) eine Story aus jedem kritischen Backbone-Schritt enthalten1315, um sicherzustellen, dass Nutzer ihr Ziel mit der kleinsten Menge von Aufgaben erreichen können3....
3. Nachfolgende Releases und fortgeschrittene Planung
Die Stories, die unterhalb des MVP-Slices liegen, sind für nachfolgende Releases vorgesehen und werden durch weitere horizontale Linien strukturiert.
• Zusätzliche Funktionen: Die Slices unterhalb des MVP repräsentieren nachfolgende Releases (z.B. Version 1.1 oder Version 2.0)5....
• "Fleisch hinzufügen": Jeder nachfolgende Slice fügt dem "Walking Skeleton" mehr "Fleisch" hinzu17, indem er höher priorisierte Alternativen (z.B. PayPal als zweite Zahlungsoption) oder "Nice-to-have"-Funktionen hinzufügt17.
• Kontinuierliche Planung: Die Story Map fungiert nach dem Slicing als lebendige, visuelle Produkt-Roadmap17.
• Metriken und Ziele: Für jede Release-Slice wird ein Ziel ("Outcome") definiert und es werden Metriken festgelegt, um den Erfolg des Releases zu messen18.... Zudem sollten weitere Releases testbar bleiben14....
4. Prozess und Vermeidung von Fallstricken
Das Slicing ist ein formaler Schritt im Story Mapping Workshop (Schritt 4: Slice Out Viable Releases24...).
• Durchführung: Im Workshop werden die Slices mithilfe von Klebeband oder farbigen Linien gezogen5....
• Wichtigkeit der Definition: Ein häufiger Fehler (Pitfall) ist das fehlende oder falsche "Slicing"2. Wird das Slicing versäumt, bleibt die Map lediglich ein Katalog aller Möglichkeiten und es entsteht kein klarer Plan für die Lieferung2.
• Abschluss des Workshops: Der Workshop gilt erst dann als beendet, wenn der erste Slice (das MVP) klar definiert, visualisiert und vom Team committet ist2. Es wird empfohlen, kleine Releases zu planen und sich dabei auf das minimal Nützliche zu konzentrieren2728.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down