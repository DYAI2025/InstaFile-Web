SFT-Trainingsbeispiele aus dem neuen Zoe/Ben-Material. Jedes Beispiel enthält (a) den gekürzten Dialog mit inline-ATO-Tags, (b) einen deterministischen Completion-Block (SEM-Komposition ≥2 ATOs, ggf. CLU/MEMA/TEND), (c) Quellen.

1) Klinik-Logistik & Fürsorge im Akutfall
Instruktion/Kontext (Input)
Zoe: „<ATO_PROBLEM_SOLVING>…fahr mal aufm Rückweg zu denen und hol dir die restlichen Sachen</ATO_PROBLEM_SOLVING>“
Ben: „<ATO_PHYS_STATE>Bin total fertig. Sollte bald was essen.</ATO_PHYS_STATE>“
Zoe: „<ATO_CAREGIVING>Ich hole uns hier was im Hotel … je nachdem was du essen magst</ATO_CAREGIVING>“
Ben: „<ATO_COORDINATION>Schreibe dir, wenn ich am Hospital losfahre</ATO_COORDINATION>“

Erwarteter Output/Analyse-Label (Completion)

json
Code kopieren
{
  "atos": ["ATO_PROBLEM_SOLVING","ATO_PHYS_STATE","ATO_CAREGIVING","ATO_COORDINATION"],
  "sems": [
    {"id":"SEM_CARE_AND_SUPPORT","composed_of":["ATO_CAREGIVING","ATO_PHYS_STATE"]},
    {"id":"SEM_PLANNING_ALIGNMENT","composed_of":["ATO_PROBLEM_SOLVING","ATO_COORDINATION"]}
  ],
  "manifestation": {
    "formula":"[RF2]×[FÜRSORGE+KOORD]×[akut]×[mittel]",
    "text":"Faktisch korrekt sage ich: Konkrete Sorge + Handlungsplanung stabilisieren den Akutfall."
  }
}
Quellen

2) Warten, Frust → Essen koordinieren
Instruktion/Kontext (Input)
Ben: „<ATO_FRUSTRATION>…erst Mittagspause, jetzt alle vor mir dran 😠</ATO_FRUSTRATION>“
Zoe: „<ATO_EMPATHY>😩</ATO_EMPATHY> … <ATO_COORDINATION>Ich fahr los, suche was … Suppe?</ATO_COORDINATION>“

Erwarteter Output/Analyse-Label (Completion)

json
Code kopieren
{
  "atos": ["ATO_FRUSTRATION","ATO_EMPATHY","ATO_COORDINATION"],
  "sems": [
    {"id":"SEM_AFFECT_CO_REGULATION","composed_of":["ATO_FRUSTRATION","ATO_EMPATHY"]},
    {"id":"SEM_FUNCTIONAL_COOP","composed_of":["ATO_COORDINATION","ATO_EMPATHY"]}
  ],
  "manifestation": {
    "formula":"[RF2]×[EMO-COREG+KOOP]×[sofort]×[niedrig-mittel]",
    "text":"Logisch scheint mir: Empathie dämpft Frust; Koordination schafft Entlastung."
  }
}
Quellen

3) Finanzielle Mini-Entlastung (700 Baht) + Pflegepfad
Instruktion/Kontext (Input)
Zoe: „<ATO_SUPPORT_PRACTICAL>Ja … 700 Baht … Hab uns Essen bestellt</ATO_SUPPORT_PRACTICAL>“
Ben: „<ATO_MED_FLOW>Warte nur noch auf die Medis</ATO_MED_FLOW>“

Erwarteter Output/Analyse-Label (Completion)

json
Code kopieren
{
  "atos": ["ATO_SUPPORT_PRACTICAL","ATO_MED_FLOW"],
  "sems": [
    {"id":"SEM_PRACTICAL_BOND","composed_of":["ATO_SUPPORT_PRACTICAL","ATO_MED_FLOW"]}
  ],
  "manifestation": {
    "formula":"[RF2]×[PRAXIS-BOND]×[gleiches Zeitfenster]×[niedrig]",
    "text":"Faktisch korrekt sage ich: Kleinzahlung+Versorgungsschritt stützen die Zusammenarbeit."
  }
}
Quellen

4) Standort-/Restaurant-Sync mit leichter Zuneigung
Instruktion/Kontext (Input)
Zoe: „<ATO_COORDINATION>Wollen wir zum Markt? Wo?</ATO_COORDINATION>“
Ben: „<ATO_COORDINATION>Standort-Link … ‚Kikekla‘</ATO_COORDINATION>“
Beide: „<ATO_AFFECTION>Xx</ATO_AFFECTION>“

Erwarteter Output/Analyse-Label (Completion)

json
Code kopieren
{
  "atos": ["ATO_COORDINATION","ATO_AFFECTION"],
  "sems": [
    {"id":"SEM_FUNCTIONAL_COOP","composed_of":["ATO_COORDINATION","ATO_COORDINATION"]},
    {"id":"SEM_MUTUAL_AFFECTION_LIGHT","composed_of":["ATO_AFFECTION","ATO_COORDINATION"]}
  ],
  "manifestation": {
    "formula":"[RF2]×[KOOP+LEICHTE ZUNEIGUNG]×[kurz]×[niedrig]",
    "text":"Logisch scheint mir: Orga trägt, Affektion rahmt warm."
  }
}
Quellen

5) Gym-Treff präzisiert („Evolve“)
Instruktion/Kontext (Input)
Zoe: „<ATO_COORDINATION>Komm mal zu dir xx</ATO_COORDINATION>“
Ben: „<ATO_COORDINATION>Evolve Health Club … Nicht das andere</ATO_COORDINATION>“

Erwarteter Output/Analyse-Label (Completion)

json
Code kopieren
{
  "atos": ["ATO_COORDINATION"],
  "sems": [{"id":"SEM_PLANNING_ALIGNMENT","composed_of":["ATO_COORDINATION","ATO_COORDINATION"]}],
  "manifestation": {
    "formula":"[RF2]×[PLANNING ALIGN]×[sofort]×[niedrig]",
    "text":"Faktisch korrekt sage ich: Treffpunktpräzisierung senkt Reibungspotenzial."
  }
}
Quellen

6) Trennung durch Reise: Nähe-Signale trotz Distanz
Instruktion/Kontext (Input)
Ben: „<ATO_LONGING>Es ist hier doof ohne dich …</ATO_LONGING>“
Zoe: „<ATO_AFFECTION>…doof ohne dich 😢</ATO_AFFECTION>“

Erwarteter Output/Analyse-Label (Completion)

json
Code kopieren
{
  "atos": ["ATO_LONGING","ATO_AFFECTION"],
  "sems": [
    {"id":"SEM_ATTACHMENT_LONGING","composed_of":["ATO_LONGING","ATO_AFFECTION"]}
  ],
  "manifestation": {
    "formula":"[RF2]×[SEHNSUCHT]×[Reisephase]×[mittel]",
    "text":"Logisch scheint mir: Bindung bleibt warm, Distanz wird sprachlich überbrückt."
  }
}
Quellen

7) Reise-Panne + gemeinsames Problemlösen
Instruktion/Kontext (Input)
Ben: „<ATO_TRAVEL_PROBLEM>Fahrer nicht da … 500 Baht für 9 min 🤯</ATO_TRAVEL_PROBLEM>“
Zoe: „<ATO_SOLUTION_SUGGEST>Würd ich beim Hotel sagen … wir hatten Bescheid gegeben</ATO_SOLUTION_SUGGEST>“
Ben: „<ATO_REASSURE>Alles gut Xx</ATO_REASSURE>“

Erwarteter Output/Analyse-Label (Completion)

json
Code kopieren
{
  "atos": ["ATO_TRAVEL_PROBLEM","ATO_SOLUTION_SUGGEST","ATO_REASSURE"],
  "sems": [
    {"id":"SEM_JOINT_PROBLEM_SOLVING","composed_of":["ATO_TRAVEL_PROBLEM","ATO_SOLUTION_SUGGEST"]},
    {"id":"SEM_EMO_BUFFER","composed_of":["ATO_REASSURE","ATO_TRAVEL_PROBLEM"]}
  ],
  "manifestation": {
    "formula":"[RF2]×[PROBLEM→LÖSUNG]×[akut]×[niedrig-mittel]",
    "text":"Faktisch korrekt sage ich: Sachproblem wird kooperativ adressiert, Ton bleibt verbindlich."
  }
}
Quellen

8) Connection-Maintenance: FT scheitert → Alternativkanal
Instruktion/Kontext (Input)
Zoe: „<ATO_REQUEST_CONTACT>Rufst du an? Kommst du durch?</ATO_REQUEST_CONTACT>“
Ben: „<ATO_TECH_FAILURE>Geht nicht … richtige Vorwahl</ATO_TECH_FAILURE>“
Beide: „<ATO_CHANNEL_SWITCH>Team/Google-Termin</ATO_CHANNEL_SWITCH>“

Erwarteter Output/Analyse-Label (Completion)

json
Code kopieren
{
  "atos": ["ATO_REQUEST_CONTACT","ATO_TECH_FAILURE","ATO_CHANNEL_SWITCH"],
  "sems": [
    {"id":"SEM_CONNECTION_MAINTENANCE","composed_of":["ATO_REQUEST_CONTACT","ATO_CHANNEL_SWITCH"]},
    {"id":"SEM_TECH_RESOLUTION","composed_of":["ATO_TECH_FAILURE","ATO_CHANNEL_SWITCH"]}
  ],
  "manifestation": {
    "formula":"[RF2]×[KONTAKT-PFLEGE]×[gleiches Fenster]×[niedrig]",
    "text":"Logisch scheint mir: Beziehungspriorität → schneller Kanalwechsel."
  }
}
Quellen

9) Kinder-/Ex-Kontext: Vulnerabilität + Halt
Instruktion/Kontext (Input)
Ben: „<ATO_SELF_DISCLOSURE>Enno nennt Oli wohl Papa …</ATO_SELF_DISCLOSURE>“
Zoe: „<ATO_EMPATHY>…gemischte Gefühle … freut mich, dass es gut lief</ATO_EMPATHY>“

Erwarteter Output/Analyse-Label (Completion)

json
Code kopieren
{
  "atos": ["ATO_SELF_DISCLOSURE","ATO_EMPATHY"],
  "sems": [{"id":"SEM_VULNERABILITY_SUPPORT","composed_of":["ATO_SELF_DISCLOSURE","ATO_EMPATHY"]}],
  "manifestation": {
    "formula":"[RF2]×[VULN+SUPPORT]×[fortlaufend]×[mittel]",
    "text":"Faktisch korrekt sage ich: Selbstoffenbarung trifft auf validierende Resonanz."
  }
}
Quellen

10) Alltagsfürsorge & Safety bei Sturm
Instruktion/Kontext (Input)
Zoe: „<ATO_CONTEXT_STORM>Insel im Lockdown … sehr stürmisch</ATO_CONTEXT_STORM>“
Ben: „<ATO_SAFETY_ADVICE>Sei vorsichtig … Kokosnüsse fallen</ATO_SAFETY_ADVICE>“
Zoe: „<ATO_BOUNDARY_SELFCARE>Fahre nimmer heute</ATO_BOUNDARY_SELFCARE>“

Erwarteter Output/Analyse-Label (Completion)

json
Code kopieren
{
  "atos": ["ATO_CONTEXT_STORM","ATO_SAFETY_ADVICE","ATO_BOUNDARY_SELFCARE"],
  "sems": [
    {"id":"SEM_CARE_AND_SUPPORT","composed_of":["ATO_SAFETY_ADVICE","ATO_CONTEXT_STORM"]},
    {"id":"SEM_BOUNDARY_CLARITY","composed_of":["ATO_BOUNDARY_SELFCARE","ATO_SAFETY_ADVICE"]}
  ],
  "manifestation": {
    "formula":"[RF2]×[SICHERHEIT+SELBSTFÜRSORGE]×[tagesaktuell]×[niedrig]",
    "text":"Logisch scheint mir: Risiko wird benannt, Schutzhandlung folgt."
  }
}
Quellen

11) Zuneigung & Tagesstruktur über Zeitzonen
Instruktion/Kontext (Input)
Ben: „<ATO_ROUTINE_SHARE>Gate 4 … fliege konstant am Tag</ATO_ROUTINE_SHARE>“
Zoe: „<ATO_AFFECTION>ich liebe dich, Näschen</ATO_AFFECTION>“
Beide: „<ATO_AFFECTION>xxxx</ATO_AFFECTION>“

Erwarteter Output/Analyse-Label (Completion)

json
Code kopieren
{
  "atos": ["ATO_ROUTINE_SHARE","ATO_AFFECTION"],
  "sems": [
    {"id":"SEM_AFFECTION_FRAMED_ROUTINE","composed_of":["ATO_ROUTINE_SHARE","ATO_AFFECTION"]}
  ],
  "manifestation": {
    "formula":"[RF2]×[ROUTINE+ZUNEIGUNG]×[Reisephase]×[mittel]",
    "text":"Faktisch korrekt sage ich: Tagesdetails dienen als Näheträger."
  }
}
Quellen

12) Praktische Tipps & „Ellwanger“ Nostalgie
Instruktion/Kontext (Input)
Zoe: „<ATO_TASK_SEARCH>Bleiche fürs Bad nicht gefunden …</ATO_TASK_SEARCH>“
Ben: „<ATO_SOLUTION_SUGGEST>Frag nach Chlor (Pool-Laden)</ATO_SOLUTION_SUGGEST>“
Später Ben: „<ATO_NOSTALGIA>Ellwanger Straße-Zeit …</ATO_NOSTALGIA>“
Zoe: „<ATO_AFFECTION>Das esse ich nur mit dir</ATO_AFFECTION>“

Erwarteter Output/Analyse-Label (Completion)

json
Code kopieren
{
  "atos": ["ATO_TASK_SEARCH","ATO_SOLUTION_SUGGEST","ATO_NOSTALGIA","ATO_AFFECTION"],
  "sems": [
    {"id":"SEM_JOINT_PROBLEM_SOLVING","composed_of":["ATO_TASK_SEARCH","ATO_SOLUTION_SUGGEST"]},
    {"id":"SEM_MEANING_ALIGNMENT_LIGHT","composed_of":["ATO_NOSTALGIA","ATO_AFFECTION"]}
  ],
  "manifestation": {
    "formula":"[RF2]×[LÖSUNG+SINN]×[laufend]×[niedrig-mittel]",
    "text":"Logisch scheint mir: Pragmatik plus geteilte Geschichte vertiefen Bonding."
  }
}
Quellen

13) Zeitverschiebung klären → Verunsicherung beruhigen
Instruktion/Kontext (Input)
Ben: „<ATO_CONSTRAINT_TIME>Abends sprechen fast unmöglich …</ATO_CONSTRAINT_TIME>“
Zoe: „<ATO_INSECURITY>…verunsichert, willst du kein FT?</ATO_INSECURITY>“
Ben: „<ATO_REASSURE>Doch will ich xxx</ATO_REASSURE>“

Erwarteter Output/Analyse-Label (Completion)

json
Code kopieren
{
  "atos": ["ATO_CONSTRAINT_TIME","ATO_INSECURITY","ATO_REASSURE"],
  "sems": [
    {"id":"SEM_BOUNDARY_NEGOTIATION_LIGHT","composed_of":["ATO_CONSTRAINT_TIME","ATO_INSECURITY"]},
    {"id":"SEM_EMO_BUFFER","composed_of":["ATO_REASSURE","ATO_INSECURITY"]}
  ],
  "manifestation": {
    "formula":"[RF2]×[KONTRAINT+BERUHIGUNG]×[kurz]×[niedrig]",
    "text":"Faktisch korrekt sage ich: Rahmen wird geklärt, Bindung bekräftigt."
  }
}
Quellen

14) Humor & Körperpflege-Alltag als Nähekanal
Instruktion/Kontext (Input)
Zoe: „<ATO_PRACTICAL_LIFE>Massagen … Fuß Massage …</ATO_PRACTICAL_LIFE>“
Ben: „<ATO_PLAYFULNESS>…Durchblutung wird helfen 😂</ATO_PLAYFULNESS>“

Erwarteter Output/Analyse-Label (Completion)

json
Code kopieren
{
  "atos": ["ATO_PRACTICAL_LIFE","ATO_PLAYFULNESS"],
  "sems": [{"id":"SEM_AFFECT_REGULATION_LIGHT","composed_of":["ATO_PRACTICAL_LIFE","ATO_PLAYFULNESS"]}],
  "manifestation": {
    "formula":"[RF2]×[LEBEN+HUMOR]×[alltäglich]×[niedrig]",
    "text":"Logisch scheint mir: Leichte Späße rahmen Alltagslasten verbindlich."
  }
}
Quellen

15) Medien-/Content-Teilen als Micro-Bonding
Instruktion/Kontext (Input)
Zoe: „<ATO_MEDIA_SHARE>Klaus (Film) ist toll xx</ATO_MEDIA_SHARE>“
Ben: „<ATO_MEDIA_SHARE>Eventuell wird es der</ATO_MEDIA_SHARE>“

Erwarteter Output/Analyse-Label (Completion)

json
Code kopieren
{
  "atos": ["ATO_MEDIA_SHARE"],
  "sems": [{"id":"SEM_SHARED_REFERENCE","composed_of":["ATO_MEDIA_SHARE","ATO_MEDIA_SHARE"]}],
  "manifestation": {
    "formula":"[RF2]×[GETEILTE REFERENZ]×[punktuell]×[niedrig]",
    "text":"Faktisch korrekt sage ich: Gemeinsamer Kulturanker stärkt Verbundenheit leicht."
  }
}
Quellen

16) Social-Kontext (Ran & Avi) → Leichtes Flirten
Instruktion/Kontext (Input)
Zoe: „<ATO_THIRD_PARTY_INTEGRATION>Rans Instagram … ‚gay und kitty‘, love it 🤭</ATO_THIRD_PARTY_INTEGRATION>“
Zoe: „<ATO_FLIRT_LIGHT>So eins brauch ich von DIR … Auto nackt waschen? – Ja</ATO_FLIRT_LIGHT>“

Erwarteter Output/Analyse-Label (Completion)

json
Code kopieren
{
  "atos": ["ATO_THIRD_PARTY_INTEGRATION","ATO_FLIRT_LIGHT"],
  "sems": [
    {"id":"SEM_SOCIAL_INTEGRATION","composed_of":["ATO_THIRD_PARTY_INTEGRATION","ATO_FLIRT_LIGHT"]}
  ],
  "manifestation": {
    "formula":"[RF2]×[SOZIAL+FLIRT]×[kurz]×[niedrig-mittel]",
    "text":"Logisch scheint mir: Dritte als Bühne für spielerisches Bonding."
  }
}