Der Vier-Phasen-Prozess des KI-begleiteten Coachings: Ein Leitfaden für Einsteiger
Einleitung: Was ist KI-begleitetes Coaching?
Stellen Sie sich vor, Sie treten einem neuen Team bei, das eine komplexe Aufgabe mit agilen Methoden lösen soll. Statt eines menschlichen Coaches, der vielleicht nur zeitweise verfügbar ist, wird Ihr Team von einem autonomen KI Agile Lead geführt. Das ist die Kernidee des KI-begleiteten Coachings. Es ist ein hochstrukturierter Prozess, der darauf ausgelegt ist, einem Team zu helfen, agile Arbeitsweisen nicht nur oberflächlich zu erlernen, sondern sie tiefgreifend zu beherrschen und dabei kontinuierlich echten Geschäftswert zu schaffen.
Viele Teams verlieren sich in endlosen Meetings, produzieren Features ohne messbaren Nutzen oder lassen die methodische Disziplin nach kurzer Zeit schleifen. KI-begleitetes Coaching ist die Antwort auf diese Probleme – ein System, das Klarheit erzwingt und an echten Wert gekoppelt ist. Man kann sich diesen Prozess am besten als eine Art Lernakademie mit Pflichtanwesenheit und strengen Abschlussprüfungen vorstellen. Der KI-Agent ist dabei der Ausbilder, der das Team konsequent durch einen Lehrplan führt, die Qualität sichert und es zum Erfolg leitet.
Dieser Leitfaden gibt Ihnen eine klare Roadmap durch die vier zentralen Phasen dieses Prozesses:
1. Ideenfindung & Emergenz
2. Backlog Refinement & Segmentierung
3. Wertbasierte Priorisierung & Iterative Umsetzung
4. Meisterschaft & Übernahme der Methodik
Lassen Sie uns mit der ersten Phase beginnen, in der alles mit der Suche nach den richtigen Fragen startet.
--------------------------------------------------------------------------------
Phase 1: Ideenfindung & Emergenz (Divergenz)
1. Ziel & Leitprinzip: Das Hauptziel dieser Phase ist die Divergenz. Anstatt sich auf die erstbeste Lösung zu stürzen, wird das Team angeleitet, den Problemraum kreativ und breit zu erforschen. Es geht darum, bessere und tiefere Fragen zu stellen, um wirklich innovative Lösungsansätze zu finden.
2. Das Leitprinzip dieser Phase lautet:
3. Hauptaktivitäten – Vom Problem zur validierten Idee: Der Weg von einer vagen Problemstellung zu einer vielversprechenden Idee folgt drei klaren Schritten, die der KI-Agent orchestriert:
    1. Problemraum schärfen: Der KI-Agent und der menschliche Architekt definieren gemeinsam das Kernproblem, die übergeordneten Ziele und die bestehenden Rahmenbedingungen (Constraints). Dieser Schritt schafft eine unmissverständliche Grundlage für die gesamte weitere Arbeit.
    2. Kreativität entfalten: Hier kommt ein zweigleisiger Ansatz zum Einsatz. Zuerst generiert die KI verschiedene Szenarien und Denkansätze ("AI Seeding"). Darauf aufbauend entwickelt das menschliche Team eigene Ideen ("Human Divergence"). Diese Kombination aus KI-Impuls und menschlicher Kreativität maximiert das Spektrum möglicher Lösungen.
    3. Ideen validieren: Im "Challenge & Discard"-Prozess werden alle generierten Ideen kritisch hinterfragt. Unbrauchbare oder wenig vielversprechende Ansätze werden konsequent verworfen. Dieser Schritt ist entscheidend, um zu verhindern, dass das Team wertvolle Zeit mit schlechten Ideen verschwendet.
4. Das Ergebnis: Das 'Ideation Gate' Am Ende jeder Phase steht ein formeller Qualitätsscheck, ein sogenanntes Review Gate. Für Phase 1 ist dies das Ideation Gate. Hier prüfen der Architekt und der Agent gemeinsam, ob die erarbeiteten Ideen klar, durchdacht und vielversprechend genug sind, um in die nächste Phase überführt zu werden.
Nachdem die besten Ideen dieses Tor passiert haben, geht es darum, sie in konkrete, umsetzbare Arbeitspakete zu verwandeln.
--------------------------------------------------------------------------------
Phase 2: Backlog Refinement & Segmentierung (Konvergenz)
1. Ziel & Leitprinzip: Nach der kreativen Weitung in Phase 1 folgt nun die Konvergenz. Das Ziel ist es, die abstrakten Ideen in kleine, glasklare und vor allem umsetzbare Arbeitspakete zu zerlegen. Oberflächlichkeit wird hier systematisch eliminiert.
2. Das Leitprinzip dieser Phase erzwingt Klarheit:
3. Hauptaktivitäten – Von der Idee zum testbaren "Chunk": Um aus einer Idee ein greifbares Arbeitspaket zu machen, leitet der KI-Agent das Team durch zwei Kernaktivitäten:
    1. Ideen schneiden: Die validierten Ideen werden in "testbare, wertschöpfende Chunks" zerlegt. Dies geschieht nicht willkürlich, sondern nach systematischen Mustern ("Story Cutting Patterns"), wie zum Beispiel nach Arbeitsabläufen (Workflow), Operationen (Operation), Schnittstellen (Interface), Geschäftsregeln (Rule), Datentypen (Data) oder zur Erkundung (Spike). So entstehen kleine, in sich geschlossene Aufgaben.
    2. Klarheit schaffen: Für jeden einzelnen "Chunk" müssen drei Dinge exakt definiert werden: sein Zweck (Warum tun wir das?), seine Akzeptanzkriterien (Wann ist es fertig? – auch "Definition of Done" oder DoD genannt) und der zugehörige Leistungskennwert (Woran messen wir den Erfolg? – KPI). Dieser Schritt stellt sicher, dass jedes Teammitglied genau weiß, was zu tun ist und warum.
4. Das Ergebnis: Das 'Backlog Gate' Der Meilenstein am Ende dieser Phase ist das Backlog Gate. Die Reviewer für dieses Gate sind der Handwerker (Virtuoso-Craftsman) und der Kritiker (Steve-Critic). Diese Rollen, die der Agent an Teammitglieder zuweist, repräsentieren eine essenzielle Spannung: Der Handwerker prüft die technische Exzellenz und Umsetzbarkeit („Können wir das richtig bauen?“). Gleichzeitig hinterfragt der Kritiker den Geschäftswert und die Notwendigkeit („Sollten wir das überhaupt bauen?“). Dieser Mechanismus verhindert, dass technisch perfekte, aber nutzlose Features entwickelt werden.
Mit einem sauber vorbereiteten und geprüften Backlog ist das Team nun bereit, die Aufgaben zu priorisieren und mit der Umsetzung zu beginnen.
--------------------------------------------------------------------------------
Phase 3: Wertbasierte Priorisierung & Iterative Umsetzung
1. Ziel & Leitprinzip: In dieser Phase geht es darum, die richtigen Dinge zuerst zu tun und in kurzen, schnellen Zyklen sichtbare Ergebnisse zu liefern. Der Fokus liegt nicht darauf, einfach nur Aufgaben abzuschließen, sondern darauf, den größtmöglichen Wert für das Projekt zu schaffen.
2. Das Leitprinzip macht diesen Fokus unmissverständlich klar:
3. Hauptaktivitäten – Vom "Chunk" zum ausgelieferten Wert: Die Umsetzung erfolgt in zwei disziplinierten Schritten, die kontinuierlich wiederholt werden:
    1. Wertbasiert priorisieren: Anstatt nach Bauchgefühl zu entscheiden, welche Aufgabe als Nächstes dran ist, werden objektive Methoden wie WSJF (Weighted Shortest Job First) oder RICE (Reach, Impact, Confidence, Effort) angewendet. Für einen Anfänger bedeutet das: Anstatt sich vom Bauchgefühl leiten zu lassen, stellt man für jede Aufgabe systematisch Fragen wie: „Wie viele Nutzer betrifft das? Welchen Nutzen bringt es ihnen? Wie sicher sind wir uns dabei? Und wie hoch ist der Aufwand?“ Methoden wie RICE und WSJF fassen diese Antworten in einem Score zusammen, der die Aufgaben mit dem größten „Return on Investment“ an die Spitze der Liste setzt.
    2. In kurzen Zyklen umsetzen: Die Arbeit selbst findet in sehr kurzen Iterationen statt: Code → Test → Critique → Refactor. Das bedeutet, ein kleines Stück wird entwickelt, sofort getestet, kritisch bewertet und bei Bedarf verbessert. Jeder dieser kleinen Schritte wird durch ein eigenes Execution Gate qualitätsgesichert, bevor der nächste begonnen wird.
4. Das Ergebnis: Das 'Execution Gate' Das Execution Gate findet nach jedem kleinen Arbeitsinkrement statt. Die Reviewer sind hier das Team selbst und der Kritiker. Sie prüfen, ob das gelieferte Ergebnis den Qualitätsstandards entspricht und tatsächlich den erwarteten Wertbeitrag leistet.
Nachdem das Team gelernt hat, wertorientiert zu arbeiten, folgt die letzte Phase: die Verankerung dieses Wissens zur echten Meisterschaft.
--------------------------------------------------------------------------------
Phase 4: Meisterschaft & Übernahme der Methodik
1. Ziel & Leitprinzip: Das finale Ziel ist, dass das Team die agilen Methoden so tief verinnerlicht, dass es sie selbstständig und souverän anwenden kann. Der entscheidende Punkt dabei ist: Diese Autonomie wird innerhalb der vom KI-Agenten geführten Struktur erreicht. Der professionelle Rahmen bleibt bestehen, um Qualität und Disziplin dauerhaft zu sichern.
2. Das Leitprinzip dieser Phase definiert Meisterschaft neu:
3. Das Kernprinzip: "Kein Rückzug des Agenten" Ein zentrales Merkmal dieses Modells ist, dass der KI-Agent dauerhaft als Lead im Prozess verbleibt. "Meisterschaft" bedeutet hier nicht, dass der Coach überflüssig wird und verschwindet. Es bedeutet vielmehr, dass das Team lernt, innerhalb eines stabilen und professionell geführten Rahmens autonom und hocheffektiv zu agieren. Im Gegensatz zu menschlichen Coaches, deren temporäre Anwesenheit oft dazu führt, dass Teams nach kurzer Zeit in alte, ineffektive Muster zurückfallen, garantiert der permanent präsente KI-Agent die nachhaltige Verankerung der disziplinierten Arbeitsweise.
4. Hauptaktivitäten – Vom Anwenden zum Beherrschen: Die Verankerung der Fähigkeiten erfolgt durch zwei systematische Aktivitäten:
    1. Systematisch lernen mit "Lehr-Loops": Für jede agile Methode (z.B. Story Cutting) durchläuft das Team einen Fünf-Schritte-Prozess: Explain → Demonstrate → Practice → Feedback → Certify. Der Agent erklärt das Konzept, zeigt ein Beispiel, lässt das Team an einer echten Aufgabe üben, gibt gezieltes Feedback und "zertifiziert" die Fähigkeit, sobald sie beherrscht wird. Dieser Loop sorgt für nachhaltiges und anwendbares Wissen.
    2. Fortschritt messen mit dem "Skill-Ledger": Der Lernfortschritt jedes Teammitglieds wird in einem einfachen Verzeichnis, dem "Skill-Ledger", festgehalten. Hier wird pro Methode vermerkt, ob eine Person die Methode nur gesehen, bereits geübt oder zertifiziert beherrscht.
5. Das Ergebnis: Das 'Final Gate' Das Final Gate ist die abschließende Prüfung am Ende des Coaching-Prozesses. Hier muss das Team zwei Dinge gleichzeitig nachweisen:
    ◦ Die methodische Autonomie des Teams bei der Problemlösung.
    ◦ Die Stabilität der vom Agenten geführten Struktur, die sicherstellt, dass die Qualität auch in Zukunft hoch bleibt.
6. Die Reviewer dieser finalen Prüfung sind der Agent und der Sponsor/Owner des Projekts.
--------------------------------------------------------------------------------
Zusammenfassung: Der Wert des strukturierten Coachings
Der Weg führt ein Team von einer vagen Idee (Phase 1), über klare Arbeitspakete (Phase 2) und eine wertorientierte Umsetzung (Phase 3) bis hin zur methodischen Meisterschaft innerhalb eines professionellen Rahmens (Phase 4).
Die folgende Tabelle fasst die vier Phasen und ihre Hauptziele noch einmal zusammen:
Phase
Hauptziel
1. Ideenfindung
Die richtigen Fragen stellen und vielversprechende Ideen finden (Divergenz).
2. Backlog Refinement
Ideen in klare, umsetzbare Arbeitspakete zerlegen (Konvergenz).
3. Umsetzung
Wertorientiert arbeiten und in kurzen Zyklen Ergebnisse liefern.
4. Meisterschaft
Methodische Autonomie innerhalb einer stabilen Führungsstruktur erreichen.
Letztlich stellt der Prozess sicher, dass ein Team nicht nur agile Methoden anwendet, sondern eine Kultur der Klarheit, des Werts und der kontinuierlichen Verbesserung verinnerlicht – geführt von einer Instanz, die keine Kompromisse bei der Qualität eingeht.