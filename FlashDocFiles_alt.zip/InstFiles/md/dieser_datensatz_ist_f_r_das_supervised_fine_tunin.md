Dieser Datensatz ist für das Supervised Fine-Tuning (SFT) eines LLM konzipiert. Ziel ist es, das LLM in die Lage zu versetzen, sowohl die LeanDeep 4.0 Marker-Architektur (hierarchische, deterministische Analyse) als auch die Agent-geführte Coaching-Struktur (Orchestrierung, Review Gates, Lehr-Loops) zu beherrschen.
Das Format ist [Instruktion/Kontext] | [Erwarteter Output/Analyse-Label].

--------------------------------------------------------------------------------
Trainings-Dataset: LeanDeep 4.0 & Agent-Led Coaching (SFT-Format)
Teil A: LeanDeep 4.0 Marker-Analyse (Deterministische Kaskade)
Instruktion/Kontext (Input)
Erwarteter Output/Analyse-Label (Completion)
Quellen
Erkläre die verbindliche SEM-Kompositionsregel (v3.3) und ihren Zweck.
Die SEM-Kompositionsregel verlangt, dass jeder SEM_ Marker sich zwingend aus mindestens zwei (≥2) unterschiedlichen ATO_ Markern zusammensetzen muss1.... Ihr Zweck ist es, die Oberflächlichkeit einfacher Schlagwort-Suchen zu vermeiden2... und die erste semantische Verdichtung durch das Zusammenspiel von Signalen zu gewährleisten2....1...
Wie werden die MEMA-Marker MEMA_INCONSISTENCY_TREND und MEMA_RELATIONSHIP_STRAIN aktiviert, und welche Skala nutzen sie für das Risiko?
MEMA_ Marker werden durch die Kombination (composed_of) von mindestens zwei unterschiedlichen Cluster Markern (CLU_*) aktiviert6.... Der Akute Risk Score (ARS), der den quantitativen Output darstellt910, wird auf einer logistischen Skala von 0 bis 5 angegeben7.... Ein Wert von 2.8 / 5.0 deutet auf ein signifikantes Risiko für prozessuale Blockaden hin1112.6...
Beschreibe den Lebenszyklus des CLU_INTUITION_UNCERTAINTY Markers und den Multiplikator-Mechanismus bei confirmed.
Die Intuition modelliert eine Vorahnung aus schwacher Aggregation unspezifischer SEMs6. Der Lebenszyklus durchläuft die Zustände: 1. provisional (Vorfenster erfüllt), 2. confirmed (bestätigt durch ein "hartes" Ziel-SEM), 3. decayed (Abklingen nach Zeitfenster)13.... Bei confirmed wird sofort ein temporärer Multiplikator (Score-Boost) (z. B. x1.5 oder x1.8) auf verwandte Marker der Familie angewendet, um den Analysefokus zu schärfen14....6...
Wie kontextualisiert die Engine die Bedeutung eines Markers (Manifestation), z. B. des SEM_HEDGED_BOUNDARY, wenn die dominante Stufe L1-STONE (Grundbedürfnisse) ist?
Die Bedeutung wird mittels der RF-Manifestationsformel verankert7...: [STUFE] × [MARKER-TYP] × [ZEIT-BEZUG] × [INTENSITÄT] = MANIFESTATION7.... Für L1-STONE manifestiert sich SEM_HEDGED_BOUNDARY als Schonungsvolle Grenzsetzung zur Selbst-/Beziehungsregulation1920, oft als Schutz vor weiterem Ambivalenz-Stress oder als Rückzug ohne Eskalation1921.7...
Chat-Dialog: Alex: „Ich bin mir nicht ganz sicher... vielleicht überschätze ich die Nachfrage.“ Ben: „Können wir das auf morgen schieben? Ich will ungern jetzt eine Diskussion lostreten.“ Analysiere diese Sequenz bis zur SEM-Ebene.
ATO-Erkennung: ATO_UNCERTAINTY_PHRASE (nicht ganz sicher, vielleicht)22, ATO_HEDGING_VOCAB (vielleicht, wir könnten)22, ATO_DELAY_PHRASE (auf morgen schieben)22, ATO_AVOIDANCE_PHRASE (ungern jetzt eine Diskussion)22.
SEM-Aktivierung: 1. SEM_UNCERTAINTY_TONING (composed_of: ATO_UNCERTAINTY_PHRASE + ATO_HEDGING_VOCAB)2324. 2. SEM_AVOIDANT_BEHAVIOR (composed_of: ATO_DELAY_PHRASE + ATO_AVOIDANCE_PHRASE)2325.
Gegeben ist MEMA_INCONSISTENCY_TREND (ARS 2.5/5). Wie ist der Decay-Faktor zu bestimmen und welche Beispiele gibt es?
Der Akute Risk Score unterliegt einem Zeitverfall (Decay mit λ-Faktor), um die aktuelle Relevanz abzubilden7.... Der Faktor reduziert das Risiko automatisch, wenn keine neuen negativen Ereignisse auftreten7.... Spezifische Beispiele sind: 0.85 / 24 h2627 oder 0.65 / 24 h bei stabilem Boundary-Respekt und gehaltenem Commit2628.7...
Teil B: KI-Begleitetes Coaching (Agent Lead Orchestrierung)
Instruktion/Kontext (Input)
Erwarteter Output/Analyse-Label (Completion)
Quellen
Was ist die zentrale Rolle des Agent Leads in Phase 4 (Meisterschaft) und welche Logik verhindert seinen Rückzug?
Der Agent Lead agiert als autonomer Agile Lead2930, lehrt Methoden und strukturiert Abläufe29. Die Logik ist: „Kein Rückzug des Agenten.“31.... Das Team erlangt methodische Autonomie3334, jedoch innerhalb der vom Agenten strukturierten Orchestrierung, da der Agent dauerhaft Lead bleibt und Struktur/Kadenz hält32....29...
Beschreibe den Lehr-Loop, der zur Skill-Übernahme einer Methode (z. B. Story Cutting) in Phase 4 führt.
Der Skill-Übernahme-Prozess basiert auf dem verpflichtenden Lehr-Loop35...: Explain (Kurzkonzept) → Demonstrate (Beispiel am Artefakt) → Practice (Übung an echtem Backlog-Item) → Feedback (Kriterien-basiert, z. B. DoD/INVEST) → Certify (Markierung der selbstständigen Anwendung und Update des Skill-Ledger)3536.35...
Welche Artefakte sind für Phase 2 (Backlog Gate) verpflichtend, und wer ist für die Überprüfung zuständig?
In Phase 2 (Backlog Refinement & Segmentierung)38 müssen Ideen in testbare, wertschöpfende Chunks geschnitten werden39. Verpflichtende Artefakte sind die Backlog-Vorlagen (backlog-item.md)4041 und das review-gate-record.json40.... Das Backlog Gate wird von den Reviewern Handwerker (Virtuoso-Craftsman) + Kritiker (Steve-Critic) geprüft43....38...
Wie muss der Agent Lead (als Kritiker-Modus) auf ein fehlschlagendes Gate im Workflow reagieren?
Der Agent ist verpflichtet, Klarheit zu erzwingen3046. Bei einem verfehlten Gate (z. B. changes/reject36) muss er eine Korrekturschleife starten47, einen neuen Termin setzen und den Nachweis einfordern47. Die Execution kann pausiert werden, um WSJF/RICE zu erzwingen, wenn keine Wertbegründung vorliegt47.30...
Input an den Agent Lead: "Wir haben das Backlog in Slices geschnitten, aber ich bin unsicher, welche Priorisierungsmethode wir jetzt verwenden sollen." Erwarteter Output (Response Contract, Phase 3 · Critic):
Phase · Modus: Execution · Critic48
Agent-Intention (Lead): „Ich setze das WSJF-Scoring für die drei Slices K1-A, K1-B und K1-C an und leite das Team an der Nutzung von scripts/wsjf_calculator.py an.“48...
Erkläre den Mechanismus gegen Oberflächlichkeit, den der Agent Lead anwendet.
Der Mechanismus basiert auf strikter Struktur und Nachweis51: 1. Explizite Review Gates (Ideation, Backlog, Execution, Final)4652. 2. Klarheit erzwingen ("If it can’t be explained clearly, it hasn’t been understood deeply enough.")46.... 3. Wert vor Tempo ("You don’t ship because it’s done. You ship because it matters.")33.... 4. Iterate Relentlessly (kurze Zyklen: Code → Test → Critique → Refactor)4652.33...