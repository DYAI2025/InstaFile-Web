Release-Planung" (häufig als "Slicing" oder das Ziehen von "Release-Slices" bezeichnet) als den kritischen Schritt, der die User Story Map (USM) von einem strukturierten Anforderungskatalog in einen konkreten, umsetzbaren Produktentwicklungsplan überführt12.
Hier ist eine detaillierte Diskussion dessen, was die Quellen im Kontext der USM über das Slicing aussagen:

--------------------------------------------------------------------------------
1. Definition und Mechanismus des Slicing
Slicing ist die Technik des horizontalen Schneidens der User Story Map23.
• Horizontale Linien: Release-Slices sind horizontale Linien ("Cut-Lines"), die über die gesamte Breite der Map gezogen werden2....
• Voraussetzung: Das Slicing erfolgt immer, nachdem die Stories vertikal nach Priorität sortiert wurden23. Die vertikale Anordnung der Stories ist die Grundlage für das Slicing9.
• Segmentierung: Jede dieser horizontalen "Scheiben" (Slices) repräsentiert ein geplantes Release, einen Sprint oder eine Iteration3.... Die Slices legen somit eine Versions- oder Release-Reihenfolge fest1011.
• Visuelle Kommunikation: Diese Linien ermöglichen es dem Product Owner, die beabsichtigte Liefersequenz von Features in den kommenden Releases visuell zu kommunizieren1012.
2. Die zentrale Rolle des MVP: Der "Walking Skeleton"
Der wichtigste Aspekt der Release-Planung durch Slicing ist die Definition des Minimum Viable Product (MVP)3....
• Der Erste Slice: Der erste Slice ist die oberste Scheibe der Map, welche das MVP definiert3.... Diese Stories sollten die "Must-have"-Stories (z.B. nach der MoSCoW-Methode) umfassen9.
• Neudefinition des MVP: Durch das Slicing wird das Konzept des MVP fundamental neu definiert313. Es ist nicht bloß eine Liste der wichtigsten Features aus einem flachen Backlog313, sondern ein funktional vollständiges Enderlebnis15.
• Der Walking Skeleton: Der erste Slice bildet den "Walking Skeleton" (laufendes Skelett)13.... Dies ist der dünnste, aber funktional vollständige End-to-End-Weg durch das gesamte Produkt13....
• Anforderung an die Vollständigkeit: Das Ziel des MVP-Slices ist die Lieferung einer durchgehenden Benutzererfahrung (Complete Product Experience, CPE)1518. Um dies zu gewährleisten, muss der MVP-Slice mindestens eine Story aus jedem kritischen Backbone-Schritt enthalten13.... Dies stellt sicher, dass Nutzer ihr Ziel mit der kleinsten Menge von Aufgaben erreichen können4....
• Vorteil gegenüber flachen Backlogs: Während ein traditionelles Backlog dazu führen könnte, dass ein Team nur die "5 wichtigsten Features" liefert (z.B. ein hartgekochtes, ungewürztes Ei, das unbrauchbar ist), erzwingt die Story Map, dass der MVP eine minimale Version aller notwendigen Schritte (z.B. Suchen, Auswählen, Bezahlen, Empfangen) enthält15.
3. Fortlaufende Planung und Metriken
Die Release-Slices strukturieren nicht nur das MVP, sondern dienen als lebendige, visuelle Produkt-Roadmap2021.
• Nachfolgende Releases: Die Slices unterhalb des MVP repräsentieren nachfolgende Versionen (z.B. Version 1.1, 2.0)2021.
• "Fleisch hinzufügen": Jeder nachfolgende Slice dient dazu, dem "Walking Skeleton" mehr "Fleisch" hinzuzufügen2021. Dies geschieht entweder durch die Implementierung höher priorisierter Alternativen (z.B. Hinzufügen von PayPal als Zahlungsoption) oder durch das Ergänzen von "Nice-to-have"-Funktionen2021.
• Strategische Gliederung: Der Story Mapping Prozess nach Jeff Patton beinhaltet den Schritt, Releases durch Slicing zu unterteilen ("Slice Out Viable Releases") und eine Entwicklungsstrategie festzulegen ("Slice Out a Development Strategy"), wobei jede Release-Slice in Opening-Game, Mid-Game und End-Game unterteilt wird22....
• Messbarkeit und Ziele: Für jede Release-Slice sollen Ziele ("Outcome") und Metriken definiert werden, um den Erfolg des jeweiligen Releases zu messen21.... Die zusätzlichen Releases sollten außerdem testbar bleiben16....
4. Prozessuale Integration und Fallstricke
Die Durchführung des Slicing ist ein formaler und wichtiger Schritt im Story Mapping Workshop22....
• Vermeidung des Pitfalls: Ein häufiger Fehler ist das fehlende oder falsche Slicing3031. Wenn dieser Schritt versäumt wird, bleibt die Map lediglich ein Katalog aller Möglichkeiten und es entsteht kein klarer Lieferplan3031.
• Workshop-Abschluss: Der Story Mapping Workshop gilt erst dann als beendet, wenn der erste Slice (das MVP) klar definiert, visualisiert und vom Team committet ist3031.
• Planungsmethode: Es wird allgemein empfohlen, kleine Releases zu planen und sich dabei auf das minimal Nützliche zu konzentrieren31....
Zusammenfassend lässt sich sagen, dass das Slicing in der User Story Map als Übersetzungswerkzeug fungiert: Es nimmt die Struktur der User Journey (horizontal) und die Priorisierung nach Kundennutzen (vertikal) und erstellt daraus einen inkrementellen, aber durchgängig nutzbaren Lieferplan, der sicherstellt, dass das Team nicht in einer "Feature-Fabrik"-Mentalität verfällt, sondern stets einen vollständigen Nutzen (Walking Skeleton) liefert13.... Das Slicing überführt die Landkarte der Möglichkeiten in eine tatsächliche Roadmap12....

--------------------------------------------------------------------------------
Analogie: Man könnte sich das Slicing wie das Zeichnen von Stockwerken in einem Bauplan vorstellen: Das Fundament (das Backbone) steht, und die Priorisierung (vertikale Achse) entscheidet, welche Einrichtungsgegenstände in welchem Raum am wichtigsten sind. Das Slicing ist die Entscheidung, wo genau die Decken eingezogen werden. Der erste Slice (das MVP) definiert das Erdgeschoss – es muss eine Tür, eine Küche, ein Bad und ein Schlafzimmer in ihrer einfachsten Form enthalten, damit es sofort bewohnbar ist (Walking Skeleton). Die nachfolgenden Slices fügen dann die luxuriösen Möbel und zusätzlichen Stockwerke hinzu2021.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Release-Planung (Slicing)“ über „Slicing-Mechanismus“ aussagen.

Der „Slicing-Mechanismus“ (in den Quellen auch als Release-Slices oder Cut-Lines bezeichnet)1... ist der entscheidende Schritt in der User Story Map (USM) Methode, der die fertiggestellte, vertikal priorisierte Karte in einen umsetzbaren Produkt- und Release-Plan umwandelt1....
Die Quellen beschreiben den Slicing-Mechanismus detailliert in Bezug auf seine Definition, seinen Zweck und seine Rolle bei der Definition des Minimum Viable Product (MVP).
1. Definition und Mechanismus des Slicing
Der Slicing-Mechanismus wird durch das Ziehen horizontaler Linien (Release-Slices oder Cut-Lines) über die gesamte Breite der Story Map realisiert1....
1. Horizontale Unterteilung: Nachdem die User Stories innerhalb ihrer jeweiligen Spalte (unter den Backbone-Schritten) vertikal nach Priorität sortiert wurden1..., wird die Map horizontal "geschnitten"512.
2. Repräsentation von Releases: Jede horizontale Scheibe (Slice) repräsentiert ein geplantes Release, einen Sprint oder eine Iteration2....
3. Festlegung der Sequenz: Die Slices legen die Versions- oder Release-Reihenfolge fest8.... Alle User Stories oberhalb der obersten Linie bilden das erste Release (z. B. das MVP)5.
4. Kommunikation: Der Mechanismus ermöglicht es dem Product Owner, die beabsichtigte Liefersequenz von Features für die kommenden Releases visuell zu kommunizieren913. Die Slices definieren Meilensteine in der Produktentwicklung13.
2. Die zentrale Rolle des MVP und des „Walking Skeleton“
Der erste und wichtigste Slice ist die oberste Scheibe, die das Minimum Viable Product (MVP) definiert5....
Das Slicing definiert das Konzept des MVP fundamental neu, indem es sicherstellt, dass das Ergebnis keine beliebige Liste der wichtigsten Features ist1416:
• Walking Skeleton: Der erste Slice bildet den „Walking Skeleton“ (laufendes Skelett)7....
• Minimaler, vollständiger Weg: Der "Walking Skeleton" ist der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt12.... Er repräsentiert einen minimalen, aber nutzbaren Ablauf14....
• Vollständige Benutzererfahrung: Um diese durchgehende Benutzererfahrung (Complete Product Experience oder CPE) zu gewährleisten, muss der MVP-Slice mindestens eine Story aus jedem kritischen Backbone-Schritt enthalten12.... Dies stellt sicher, dass der Nutzer sein übergeordnetes Ziel mit der kleinsten Menge von Aufgaben erreichen kann3....
3. Fortgeschrittene Planung und Roadmap
Die Slices unterhalb des MVP strukturieren die zukünftige Produktentwicklung und fungieren als lebendige, visuelle Produkt-Roadmap2324.
• Inkrementelle Erweiterung: Jeder nachfolgende Slice fügt dem „Walking Skeleton“ mehr „Fleisch“ hinzu2324. Dies geschieht entweder durch die Implementierung von höher priorisierten Alternativen (z. B. Hinzufügen einer zweiten Zahlungsoption wie PayPal) oder durch „Nice-to-have“-Funktionen2324.
• Strategische Unterteilung: Im Rahmen des fünften Schritts des Patton-Prozesses (Slice Out a Development Strategy) kann jede Release-Slice weiter in Opening-Game, Mid-Game und End-Game unterteilt werden25....
• Erfolgsmessung: Für jede Release-Slice sollte ein Ziel (Outcome) definiert und Metriken festgelegt werden, um den Erfolg des Releases zu messen24....
4. Prozessuale Integration und Fallstricke
Das Slicing ist der formale Abschluss der Planungsphase und somit ein kritischer Teil des Story Mapping Workshops2533.
• Abschluss des Workshops: Der Workshop ist erst dann beendet, wenn der erste Slice (das MVP) klar definiert, visualisiert und vom Team committet ist633.
• Vermeidung des häufigsten Fehlers: Das Versäumnis, die horizontalen Release-Linien zu ziehen (das fehlende oder falsche „Slicing“), ist ein häufiger Fallstrick633. Ohne diese Schnitte bleibt die Map lediglich ein umfassender Katalog aller Möglichkeiten, aber es existiert kein klarer Plan für die Lieferung633.

--------------------------------------------------------------------------------
Der Slicing-Mechanismus ist in diesem Kontext wie das Schneiden eines Kuchens: Anstatt nur die oberflächlichsten oder die am leichtesten zugänglichen Schichten (Features) zu wählen, garantiert die horizontale Schnittführung (der Slice), dass jedes Stück (Release) eine vollständige, wenn auch minimale, Version aller Schichten (Backbone-Aktivitäten) enthält, wodurch der Kunde immer eine vollständige und nutzbare End-to-End-Erfahrung erhält (den "Walking Skeleton")12....

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Slicing-Mechanismus“ über „Horizontale Linien (Cut-Lines) über die gesamte Breite“ aussagen.

Die Quellen beschreiben die "Horizontalen Linien (Cut-Lines) über die gesamte Breite" als den zentralen Mechanismus des "Slicing"12, der die User Story Map von einem priorisierten Katalog aller Ideen in einen konkreten, umsetzbaren Produktplan transformiert1....
Hier ist eine detaillierte Diskussion, was die Quellen über diesen Mechanismus aussagen:
1. Definition und Rolle der horizontalen Linien
Die horizontalen Linien, auch als Release-Slices2... oder Cut-Lines2... bezeichnet, sind das Werkzeug zur horizontalen Release-Planung1.
• Implementierung: Die Linien werden vom Moderator oder Product Owner über die gesamte Breite der Map gezogen1.... Im physischen Workshop können dafür Klebebänder oder farbige Linien verwendet werden10....
• Ablauf: Das Slicing findet erst statt, nachdem die User Stories vertikal nach Priorität (Wichtigkeit) sortiert wurden12.
• Zweck: Sie dienen dazu, die vertikal priorisierten User Stories in abgrenzbare Einheiten zu unterteilen15. Jede Scheibe (Slice) repräsentiert ein geplantes Release, einen Sprint, eine Iteration oder einen Versionsstand1....
• Kommunikation: Die Linien ermöglichen es, die beabsichtigte Liefersequenz von Features in den kommenden Releases visuell zu kommunizieren1115 und definieren Meilensteine in der Produktentwicklung1516.
2. Die zentrale Bedeutung des ersten Slice (MVP)
Der wichtigste Einsatz der horizontalen Linie ist die Definition des Minimum Viable Product (MVP)1....
• Der oberste Schnitt: Der erste und wichtigste "Slice" ist die oberste Scheibe der Map, welche das MVP definiert1....
• Der "Walking Skeleton": Dieser erste Schnitt definiert das MVP fundamental neu: Es ist nicht einfach eine Liste der wichtigsten Features1718. Stattdessen bildet der erste Slice den sogenannten "Walking Skeleton" (laufendes Skelett)5....
• Funktionale Vollständigkeit: Der Walking Skeleton ist der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt17.... Um dies zu gewährleisten, muss der MVP-Slice mindestens eine Story aus jedem kritischen Backbone-Schritt enthalten17.... Dies stellt sicher, dass der Nutzer eine durchgehende Benutzererfahrung (Complete Product Experience, CPE) erhält und sein übergeordnetes Ziel mit der kleinsten Menge an notwendigen Aufgaben erreichen kann4....
3. Nachfolgende Releases und Roadmapping
Die horizontalen Linien strukturieren nicht nur das MVP, sondern dienen der gesamten Release-Planung:
• Zusätzlicher Wert: Die Slices unterhalb des MVP repräsentieren nachfolgende Releases (z.B. Version 1.1 oder Version 2.0)2122.
• "Fleisch hinzufügen": Jeder folgende Slice fügt dem bereits funktionsfähigen "Walking Skeleton" mehr "Fleisch" hinzu2122, beispielsweise indem höher priorisierte Alternativen (z.B. eine zweite Zahlungsoption) oder "Nice-to-have"-Funktionen hinzugefügt werden2122.
• Roadmap: Nach dem Slicing fungiert die Story Map als eine lebendige, visuelle Produkt-Roadmap11....
4. Prozess und die Vermeidung von Fallstricken
Das Slicing durch die horizontalen Linien ist ein essenzieller formaler Schritt im Story Mapping Workshop12....
• Workshop-Abschluss: Ein häufiger Fallstrick ist das fehlende oder falsche "Slicing"312. Wenn dieses Versäumnis auftritt, bleibt die Map lediglich ein Katalog aller Möglichkeiten, es fehlt jedoch ein klarer Plan, was als Nächstes geliefert wird312.
• Commitment: Der Workshop gilt erst dann als beendet, wenn der erste Slice (das MVP), definiert durch die horizontale Linie, klar visualisiert und vom Team committet ist312.
Zusammenfassend lässt sich sagen: Die horizontalen Linien sind das Werkzeug zur Timebox-Projektion in der User Story Map. Nachdem das Team die User Journey horizontal (Backbone) abgebildet und die Details vertikal (Priorität) geordnet hat, legen die horizontalen Linien fest, welche vollständige End-to-End-Reise in welcher Version tatsächlich ausgeliefert wird119. Es ist, als würde man ein hoch priorisiertes, mehrschichtiges Produkt – beispielsweise einen Schichtkuchen – nicht Schicht für Schicht von oben nach unten, sondern in dünnen, aber vollständigen Querschnitten liefern, wobei jeder Querschnitt eine essenzielle Geschmacksrichtung (Funktionalität) aus jeder Ebene enthält18.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Slicing-Mechanismus“ über „Unterteilt Stories in Releases, MVPs, Sprints“ aussagen.

Das „Slicing“ (in Scheiben schneiden) ist der zentrale Mechanismus der User Story Map (USM) zur Überführung des priorisierten Funktionskatalogs in einen konkreten, umsetzbaren Produktplan12. Dieser Mechanismus ist direkt verantwortlich für die Unterteilung der Stories in Releases, MVPs und Sprints13.
Die Quellen beschreiben diesen Prozess und dessen Resultate im Detail:
1. Definition des Slicing und die Funktion der Unterteilung
Das Slicing, oder die Release-Slices2..., besteht aus horizontalen Linien1..., die über die gesamte Breite der Story Map gezogen werden12. Diese Linien werden auch als "Cut-Lines" bezeichnet2....
Der Hauptzweck dieser horizontalen Unterteilung ist es, die User Stories in folgende umsetzbare Einheiten zu gliedern:
• Releases/Versionen: Die Slices legen eine klare Versions- oder Release-Reihenfolge fest3... und jede Scheibe repräsentiert ein geplantes Release13.
• MVPs (Minimum Viable Products): Die oberste Scheibe definiert das erste und wichtigste Release, das MVP1....
• Sprints/Iterationen: Die Slices können Stories auch in Iterationen3... oder Sprints unterteilen13.
Durch das Hinzufügen dieser Linien kann der Product Owner die beabsichtigte Liefersequenz von Features visuell kommunizieren312.
2. Die zentrale Unterteilung: Das MVP und der „Walking Skeleton“
Der erste Slice ist von entscheidender Bedeutung, da er das MVP definiert1516. Die Story Map definiert das Konzept des MVP fundamental neu1519:
• Funktionale Vollständigkeit: Ein MVP, das durch Slicing entsteht, ist nicht nur eine Liste der "5 wichtigsten Features"1519, sondern der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt15....
• Walking Skeleton: Dieses Ergebnis wird oft als „Walking Skeleton“ (laufendes Skelett) bezeichnet5.... Es stellt einen minimalen, aber nutzbaren Ablauf dar5....
• Anforderung an die Unterteilung: Der MVP-Slice muss mindestens eine Story aus jedem kritischen Backbone-Schritt enthalten15.... Dies stellt sicher, dass der Nutzer sein übergeordnetes Ziel mit der geringsten Menge an Aufgaben erreichen kann und eine durchgehende Benutzererfahrung (Complete Product Experience) geliefert wird15....
3. Unterteilung in nachfolgende Releases
Die horizontalen Linien unterhalb des MVP definieren die nachfolgenden Releases (z. B. Version 1.1 oder 2.0)1121.
• Jeder nachfolgende Slice fügt dem initialen "Walking Skeleton" mehr „Fleisch“ hinzu2122.
• Dies geschieht durch die Implementierung von höher priorisierten Alternativen oder die Hinzufügung von „Nice-to-have“-Funktionen2122.
• Die Slices repräsentieren Meilensteine in der Produktentwicklung, wie den Abschluss von Version 1323.
4. Slicing im Kontext von Sprints
Obwohl Slicing primär zur Definition von größeren Releases und MVPs dient, spielt es auch eine Rolle bei der operativen Planung:
• Roadmap und Kontext: Durch die Unterteilung in Slices dient die Story Map als lebendige, visuelle Produkt-Roadmap2122. Sie kann auf einer operativen Ebene als Kontextgeber zu Beginn jedes Sprint Plannings verwendet werden24.
• Entwicklungsstrategie: Im fünfstufigen Prozess von Jeff Patton folgt dem Schritt Slice Out Viable Releases der Schritt Slice Out a Development Strategy, bei dem für jede Release Ziele und Metriken festgelegt werden25....
Die vertikale Priorisierung der Stories (Must-haves oben, Nice-to-haves unten) bildet die notwendige Grundlage, bevor das Slicing horizontal angewendet wird1.... Wird das Slicing versäumt, bleibt die Story Map lediglich ein Katalog aller Möglichkeiten und es entsteht kein klarer Lieferplan1430.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Slicing-Mechanismus“ über „Visualisiert die beabsichtigte Liefersequenz“ aussagen.

Der Slicing-Mechanismus in der User Story Map (USM) ist die zentrale Technik, um die beabsichtigte Liefersequenz von Features zu visualisieren12. Die Quellen betonen, dass diese Visualisierung die Map von einem bloßen Anforderungskatalog in einen konkreten, zeitlich strukturierten Produktentwicklungsplan überführt3.
Hier wird diskutiert, was die Quellen über die Visualisierung der Liefersequenz durch den Slicing-Mechanismus aussagen:
1. Definition des Mechanismus als Visualisierungswerkzeug
Slicing (oder das Ziehen von "Cut-Lines") ist die Methode, die Story Map horizontal zu schneiden, nachdem die Stories vertikal nach Priorität sortiert wurden2....
• Horizontale Linien: Die beabsichtigte Liefersequenz wird durch das Ziehen von horizontalen Linien (oder farbigen Linien/Klebeband bei physischen Maps) über die gesamte Breite der Map dargestellt3....
• Segmentierung der Lieferung: Jede dieser horizontalen "Scheiben" (Slices) repräsentiert eine geplante Versions- oder Release-Reihenfolge1.... Die Scheiben unterteilen die User Stories in Releases, MVPs, Sprints oder Iterationen1.
• Roadmap-Funktion: Da die Map vertikal nach Priorität geordnet ist, wird es durch das Hinzufügen der Slices sehr einfach, die Story Map zur Vermittlung einer Roadmap zu nutzen2. Nach dem Slicing fungiert die Map als lebendige, visuelle Produkt-Roadmap89.
2. Die Kommunikation der Sequenz
Der primäre Zweck der Slices in Bezug auf die Liefersequenz liegt in der Kommunikation und dem Schaffen eines gemeinsamen Verständnisses10.
• Explizite Sequenz: Das Hinzufügen dieser Linien ermöglicht es dem Product Owner, die vorgesehene Liefersequenz von Features in einem oder mehreren kommenden Releases visuell zu kommunizieren12.
• Meilenstein-Definition: Die horizontalen Einteilungen definieren Meilensteine in der Produktentwicklung, wie beispielsweise den Zeitpunkt der Erstellung eines MVP oder die Fertigstellung von Version 11....
• MVP als erste Sequenz: Die oberste Scheibe (der erste Slice) ist der wichtigste Teil dieser Sequenz und definiert das Minimum Viable Product (MVP)2.... Diese Darstellung garantiert, dass das Team nicht nur an den wichtigsten Features arbeitet, sondern einen funktional vollständigen End-to-End-Weg (den "Walking Skeleton") durch das Produkt liefert13.
3. Logik der sequenziellen Visualisierung
Die Visualisierung der Liefersequenz folgt der vertikalen Priorisierung, sodass die am höchsten bewerteten Stories in den ersten Releases erscheinen.
• MVP-Slice: Um die Vollständigkeit der ersten Sequenz zu gewährleisten, muss der MVP-Slice mindestens eine Story aus jedem kritischen Backbone-Schritt enthalten1314. Dies stellt sicher, dass die Nutzer ihr Ziel mit der kleinsten Menge von Aufgaben erreichen können13.
• Nachfolgende Releases: Die Slices unterhalb des MVP repräsentieren die nachfolgenden Releases (z.B. Version 1.1 oder 2.0)8.... Diese Sequenz fügt dem anfänglichen, lauffähigen Skelett (Walking Skeleton) mehr "Fleisch" hinzu89.
• Flexibilität: Der Product Owner kann zusätzliche Linien hinzufügen, um weitere Meilensteine (z.B. das Q3 Release) zu kennzeichnen11.
Zusammenfassend erlaubt der Slicing-Mechanismus der USM die Visualisierung der Liefersequenz, indem er die vertikal nach Wert geordneten Features horizontal in zeitliche Stufen zerlegt. Diese visuellen "Cut-Lines" transformieren die Map von einer statischen Landkarte aller Möglichkeiten in eine dynamische, chronologische Roadmap der beabsichtigten Produktentwicklung29.
Analogie: Man könnte den Slicing-Mechanismus als die Zeitleiste eines Films auf der Story Map sehen. Die vertikale Priorisierung legt fest, welche Szenen am wichtigsten sind. Das Slicing zieht dann horizontale Linien, um zu definieren, welche dieser Szenen in der ersten Vorschau (MVP), in der offiziellen Kinopremiere (Release 1.0) und im Director's Cut (Release 2.0) enthalten sein werden. Es visualisiert klar, in welcher Reihenfolge der Inhalt den Zuschauern (Nutzern) präsentiert wird.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Slicing-Mechanismus“ über „Definiert Meilensteine“ aussagen.

Der Slicing-Mechanismus ist der zentrale Vorgang innerhalb des User Story Mapping (USM), der die Priorisierung in konkrete Pläne überführt und somit explizit Meilensteine in der Produktentwicklung definiert.
Die Quellen betonen, dass die Release-Slices (oder Cut-Lines) ein essentielles Element der USM sind und als Mechanismus dienen, die zweidimensionale, priorisierte Map in einen umsetzbaren Produktplan zu transformieren1.
Hier wird diskutiert, was die Quellen über die Definition von Meilensteinen durch diesen Mechanismus aussagen:
1. Direkte Definition von Meilensteinen durch Slices
Die primäre Funktion des Slicing ist die Definition von Meilensteinen23.
• Horizontale Einteilung: Release-Slices sind horizontale Linien1..., die über die gesamte Breite der Map gezogen werden und als Einteilungen dienen3.
• Festlegung des Zeitpunkts: Diese horizontalen Einteilungen definieren Meilensteine, welche beispielsweise den Zeitpunkt der Erstellung eines MVP (Minimum Viable Product) oder die Fertigstellung von Version 1 festlegen können23.
• Unterteilung: Die Slices dienen dazu, die User Stories in Releases, MVPs, Sprints oder Iterationen zu unterteilen2. Jede Scheibe, die durch die Cut-Lines entsteht, repräsentiert ein geplantes Release26.
2. Der MVP-Slice als erster und wichtigster Meilenstein
Der erste Meilenstein, der durch das Slicing definiert wird, hat eine herausragende Bedeutung und eine spezielle Bezeichnung:
• Der Erste Slice: Der erste und wichtigste Slice ist die oberste Scheibe der Map, welche das Minimum Viable Product (MVP) definiert2.
• Das Walking Skeleton: Dieser MVP-Meilenstein bildet das "Walking Skeleton" (laufendes Skelett)7.... Das Walking Skeleton stellt einen minimalen, aber nutzbaren Ablauf und den dünnsten, aber funktional vollständigen End-to-End-Weg durch das Produkt dar7.... Das Erreichen dieses Zustands ist somit der erste große Meilenstein in der Produktentwicklung.
• Workshop-Abschluss: Die Definition dieses ersten Slices ist so kritisch, dass der Story Mapping Workshop als Prozessschritt ("Slice Out Viable Releases")14... erst dann als beendet gilt, wenn der erste Meilenstein (das MVP) klar definiert, visualisiert und vom Team committet ist1718.
3. Fortlaufende Meilensteine und Roadmap-Funktion
Das Slicing hört nicht beim MVP auf, sondern dient dazu, eine gesamte Kette von Meilensteinen zu definieren, die die zukünftige Produktentwicklung strukturiert:
• Nachfolgende Releases: Die Slices unterhalb des MVP definieren nachfolgende Releases1920, beispielsweise Version 1.1 oder Version 2.01920.
• Visuelle Kommunikation: Um zusätzliche Meilensteine auf der Story Map anzuzeigen, werden einfach weitere horizontale Linien hinzugefügt21. Die Quellen nennen als Beispiel die Indikation eines Quarter 3 Release21.
• Versions- und Liefersequenz: Die Slices legen eine Versions- oder Release-Reihenfolge fest2... und erlauben dem Product Owner, die beabsichtigte Liefersequenz von Features in den kommenden Releases visuell zu kommunizieren221.
• Produkt-Roadmap: Auf diese Weise fungiert die Story Map nach dem Slicing als eine lebendige, visuelle Produkt-Roadmap1920.
Die horizontale Einteilung (Slicing) ermöglicht es somit, die vertikal priorisierten Anforderungen in eine chronologische Abfolge von erreichbaren Zielen (Meilensteinen) zu überführen2....

--------------------------------------------------------------------------------
Analogie zur Veranschaulichung:
Stellen Sie sich die User Story Map als einen hohen Kuchen vor, bei dem die Zutaten (Stories) nach ihrer Wichtigkeit von oben nach unten geschichtet wurden. Der Slicing-Mechanismus ist das horizontale Durchschneiden des Kuchens in Scheiben. Jede dieser Scheiben repräsentiert einen abgeschlossenen Meilenstein (Release). Der oberste, dünnste Slice ist das MVP (das "Walking Skeleton"), das sofort essbar ist. Die nachfolgenden Slices definieren die nächsten, größeren Meilensteine, die hinzugefügt werden, um den Kuchen im Laufe der Zeit zu vervollständigen.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Release-Planung (Slicing)“ über „MVP (Walking Skeleton)“ aussagen.

Die Quellen beschreiben das MVP (Minimum Viable Product), das durch den Slicing-Mechanismus definiert wird, nicht als eine bloße Liste von Features, sondern als ein "Walking Skeleton" (laufendes Skelett). Dies stellt die Essenz der Release-Planung in der User Story Map (USM) dar, da es die durchgängige Nutzbarkeit des ersten Produkts sicherstellt.
Hier ist eine Diskussion dessen, was die Quellen im Kontext des Slicing über das MVP und den "Walking Skeleton" aussagen:
1. Definition des MVP durch den ersten Slice
Der MVP wird durch den ersten und wichtigsten "Slice" definiert, welcher die oberste Scheibe der Story Map bildet1....
• Fundamentale Neudefinition: Das Slicing definiert das Konzept des MVP fundamental neu12. Es wird betont, dass ein MVP, das durch das Slicing einer Story Map entsteht, nicht einfach die "5 wichtigsten Features" aus einer flachen Liste ist12.
• Resultat der Priorisierung: Die Stories, die für eine minimale Funktionsfähigkeit unerlässlich sind ("Must-haves"), werden nach der vertikalen Priorisierung ganz oben platziert und bilden kollektiv den natürlichen MVP-Slice56.
2. Die Essenz: Der „Walking Skeleton“
Das Ergebnis des ersten Slice wird als "Walking Skeleton" (laufendes Skelett) bezeichnet2....
• Funktional vollständiger Weg: Der "Walking Skeleton" ist definiert als der dünnste, aber funktional vollständige End-to-End-Weg durch das gesamte Produkt2.... Er repräsentiert einen minimalen, aber nutzbaren Ablauf2....
• Complete Product Experience (CPE): Das Ziel dieses MVP-Slices ist die Lieferung einer durchgehenden Benutzererfahrung (Complete Product Experience, CPE)2....
• Die strukturelle Anforderung: Um diese Vollständigkeit zu garantieren, muss der MVP-Slice mindestens eine Story aus jedem kritischen Backbone-Schritt enthalten2.... Dies stellt sicher, dass Nutzer ihr übergeordnetes Ziel mit der kleinsten Menge von Aufgaben erreichen können2....
3. Abgrenzung zum traditionellen Backlog
Die Quellen nutzen das Konzept des Walking Skeleton, um den entscheidenden Vorteil der Story Map gegenüber dem flachen Backlog zu demonstrieren:
• Vermeidung von Unbrauchbarkeit: Ein Beispiel illustriert, dass ein flaches Backlog dazu führen könnte, dass ein Team zwar die "wichtigsten" Stories liefert (z.B. ein hartgekochtes, ungewürztes Ei), aber Stories niedrigerer Priorität (z.B. "gut gewürzt sein") fehlen, was das Produkt unbrauchbar macht7.
• Erzwungene Vollständigkeit: Die Story Map erzwingt durch den Slicing-Mechanismus, dass der MVP-Slice eine minimale Version aller notwendigen Schritte entlang der User Journey enthält (z.B. Suchen, Auswählen, Bezahlen, Empfangen)7.
4. Rolle in nachfolgenden Releases
Der "Walking Skeleton" bildet die Grundlage, auf der alle nachfolgenden Releases aufbauen.
• Inkrementelle Erweiterung: Die Slices, die unterhalb des MVP liegen, repräsentieren nachfolgende Versionen (z.B. Version 1.1 oder 2.0)1516.
• "Fleisch hinzufügen": Jeder nachfolgende Slice fügt dem bereits funktionsfähigen "Walking Skeleton" mehr "Fleisch" hinzu1516, indem höher priorisierte Alternativen (z.B. die Option, mit PayPal zu bezahlen) oder "Nice-to-have"-Funktionen hinzugefügt werden1516.
5. Prozessuale Relevanz
Die Definition des MVP als Walking Skeleton ist ein kritischer Schritt im Story Mapping Workshop:
• Workshop-Abschluss: Der Workshop gilt erst dann als beendet, wenn der erste Slice (das MVP) klar definiert, visualisiert und vom Team committet ist1718. Das Versäumnis, diesen Slice zu definieren, wird als häufiger Fehler (Pitfall) genannt1718.
Der "Walking Skeleton" gewährleistet somit, dass das Team von Anfang an ein vollständiges Produktziel erreicht und den Fokus von der Abarbeitung einzelner Features hin zur vollständigen Lösung von Nutzerproblemen verlagert10....

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „MVP (Walking Skeleton)“ über „Walking Skeleton: Minimaler, aber funktional vollständiger End-to-End-Weg“ aussagen.

Der Begriff „Walking Skeleton“ (laufendes Skelett)12 ist das zentrale Konzept zur Definition des Minimum Viable Product (MVP) innerhalb des User Story Mapping2.... Die Quellen sind sich einig, dass es sich dabei um eine neue und bessere Definition des MVP handelt, die garantiert, dass ein minimaler, aber funktional vollständiger End-to-End-Weg durch das Produkt geliefert wird.
Hier wird diskutiert, was die Quellen zu dieser spezifischen Charakterisierung des Walking Skeleton aussagen:
1. Definition als Minimaler, vollständiger Weg
Der "Walking Skeleton" ist das direkte Ergebnis des ersten Slicings (der obersten horizontalen Scheibe) der User Story Map25. Diese Scheibe definiert das erste Release, das sofort ausgeliefert werden soll5.
• Kernmerkmale: Das "Walking Skeleton" ist der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt12.
• Funktion: Es handelt sich um eine minimale, aber durchgängig funktionsfähige Version des gesamten Systems1 und stellt einen minimalen, aber nutzbaren Ablauf dar2....
• Ziel: Die Story Map definiert das Konzept des MVP fundamental neu12. Das Ziel des resultierenden MVP-Slices ist es, eine durchgehende Benutzererfahrung oder eine „Complete Product Experience“ (CPE) zu liefern18.
2. Die End-to-End-Anforderung
Die Eigenschaft, "End-to-End" (vom Start bis zum Ziel des Nutzers) funktionsfähig zu sein, ist entscheidend und unterscheidet das Story-Map-MVP von einem traditionellen Backlog-MVP.
• Garantie durch das Backbone: Der End-to-End-Weg wird garantiert, da der erste Slice Stories aus jedem kritischen Backbone-Schritt enthalten muss1....
• Zusammenhang mit der Journey: Das Backbone (die horizontale Achse der Map) ist als chronologische Abfolge der Benutzeraktivitäten (User Journey) strukturiert1011. Wenn der Walking Skeleton Stories von links nach rechts aus allen diesen Schritten enthält (z. B. Suchen, Auswählen, Bezahlen, Empfangen1), ist sichergestellt, dass der Nutzer sein übergeordnetes Ziel mit der kleinsten Menge von Aufgaben erreichen kann2.
• Vermeidung des Feature-Fabrik-Ansatzes: Die Quellen nutzen ein Beispiel, um den Fehler eines flachen Backlogs zu illustrieren: Wenn ein Team nur die wichtigsten, aber unzusammenhängenden Stories liefert (z. B. ein ungewürztes, hartgekochtes Ei, das unbrauchbar ist), hat es nur die wichtigsten Features geliefert, aber keinen vollständigen Nutzen1. Der Walking Skeleton erzwingt, dass die zentrale Frage beantwortet wird: „Welches Problem des Nutzers lösen wir als Nächstes vollständig?“1213.
3. Kontinuierlicher Aufbau auf dem Walking Skeleton
Der Walking Skeleton ist der erste Meilenstein14, auf dem die gesamte weitere Produktentwicklung basiert.
• Basis für Releases: Die Slices unterhalb des MVP repräsentieren nachfolgende Releases15.
• Inkrementelle Erweiterung: Jeder nachfolgende Slice fügt dem bereits funktionsfähigen „Walking Skeleton“ mehr „Fleisch“ hinzu1516, beispielsweise durch das Hinzufügen von höher priorisierten Alternativen oder „Nice-to-have“-Funktionen1516.
Zusammenfassend ist der „Walking Skeleton“ der Beweis dafür, dass die Story Map erfolgreich die Priorisierung (vertikal) mit der Benutzerreise (horizontal) verbunden hat, um ein funktionsfähiges Produktfundament zu schaffen, das sofort End-to-End getestet und genutzt werden kann12.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „MVP (Walking Skeleton)“ über „Nicht nur 'die 5 wichtigsten Features'“ aussagen.

Die Quellen legen großen Wert darauf, dass die Release-Planung mittels User Story Mapping (USM) das Konzept des Minimum Viable Product (MVP) fundamental neu definiert und explizit die Falle vermeidet, das MVP als bloße Zusammenstellung der "5 wichtigsten Features" aus einer flachen Liste zu verstehen1....
Dieser Unterschied ist das Kernergebnis des Slicing-Mechanismus und der zweidimensionalen Struktur der Story Map.
1. Das Problem des „Flachen Backlogs“
Die Notwendigkeit, das MVP neu zu definieren, ergibt sich aus dem fundamentalen Problem traditioneller, flacher Backlogs.
• Fehlender Kontext: Ein flaches Backlog ist im Wesentlichen eine eindimensionale „To-Do-Liste“45, die den Gesamtzusammenhang nicht sichtbar macht6.... Es fehlt der Kontext jeder einzelnen Aufgabe4.
• Wettstreit der Stories: In einem flachen Backlog konkurrieren Stories direkt miteinander, unabhängig davon, welchen Teil der Benutzerreise sie betreffen (z. B. konkurriert eine "wichtige" Story für den Bezahlvorgang direkt mit einer "weniger wichtigen" Story für die Passwort-Wiederherstellung)9.
• Feature-Fabrik-Mentalität: Diese Struktur fördert eine "Feature-Fabrik"-Mentalität10. Teams neigen dazu, Features auszuwählen, die am einfachsten oder am interessantesten sind, anstatt das zu liefern, was den höchsten Kundennutzen erzeugt411.
2. Die Neudefinition: Der „Walking Skeleton“
Durch das Slicing der Story Map wird sichergestellt, dass das MVP nicht nur die höchste Priorität berücksichtigt, sondern auch die Vollständigkeit der Benutzerreise (User Journey).
• Explizite Ablehnung der Liste: Die Quellen stellen klar, dass ein MVP, das durch das Slicing einer Story Map entsteht, nicht einfach "die 5 wichtigsten Features" aus einer Liste ist23.
• Der "Walking Skeleton": Stattdessen bildet der erste und wichtigste Slice den „Walking Skeleton“ (laufendes Skelett)2....
• Funktional vollständige Reise: Der Walking Skeleton ist definiert als der dünnste, aber funktional vollständige End-to-End-Weg durch das gesamte Produkt2.... Er repräsentiert einen minimalen, aber nutzbaren Ablauf3....
3. Erzwingen der End-to-End-Nutzbarkeit
Das Story Mapping erzwingt die Lieferung einer durchgehenden Benutzererfahrung (Complete Product Experience oder CPE)215, wodurch verhindert wird, dass nur isolierte, aber hoch priorisierte Features geliefert werden, die am Ende nutzlos sind.
• Die Backbone-Anforderung: Um die Vollständigkeit zu garantieren, muss der MVP-Slice (mindestens) eine Story aus jedem kritischen Backbone-Schritt enthalten2.... Das Backbone bildet die chronologische Abfolge der notwendigen Benutzeraktivitäten1819.
• Vermeidung des unbrauchbaren Produkts: Ein Beispiel illustriert dies: Wenn ein Team einfach nur die „wichtigsten“ Stories aus einem flachen Backlog liefert (z. B. eine Mahlzeit soll sättigend und fest sein), erhält der Kunde möglicherweise nur ein hartgekochtes, ungewürztes Ei, das unbrauchbar ist, weil eine Story mit niedrigerer Priorität (z. B. „Mahlzeit soll gut gewürzt sein“) fehlt2.
• Garantierte Zielerreichung: Die Story Map erzwingt stattdessen, dass der MVP-Slice eine minimale Version aller notwendigen Schritte enthält (z. B. Suchen, Auswählen, Bezahlen, Empfangen), damit der Kunde sein übergeordnetes Ziel mit der kleinsten Menge an Aufgaben erreichen kann2....
Zusammenfassend sorgt der Slicing-Mechanismus dafür, dass die Auswahl der Features für das MVP nicht nur der vertikalen Wichtigkeit folgt (der Falle der "5 wichtigsten Features"), sondern auch der horizontalen Vollständigkeit der User Journey.

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „MVP (Walking Skeleton)“ über „Muss mindestens eine Story aus jedem kritischen Backbone-Schritt enthalten“ aussagen.

Die Anforderung, dass das MVP (Minimum Viable Product) oder der "Walking Skeleton" (laufendes Skelett) mindestens eine Story aus jedem kritischen Backbone-Schritt enthalten muss, ist die wichtigste Regel im Slicing-Mechanismus und definiert die Kernstärke der User Story Map (USM) gegenüber traditionellen Backlogs1....
Diese Bedingung stellt sicher, dass das erste ausgelieferte Produkt sofort einen vollständigen Nutzen für den Anwender bietet.
1. Die Notwendigkeit der Vollständigkeit
Die Quellen heben hervor, dass diese zwingende Anforderung aus der Natur der Story Map und dem Ziel der Produktentwicklung resultiert:
• Vollständige Benutzererfahrung (CPE): Das Hauptziel des MVP-Slices ist die Lieferung eines "Complete Product Experience" (CPE)1 oder zumindest einer durchgehenden Benutzererfahrung13.
• Erreichung des Nutzerziels: Da das Backbone die chronologische User Journey (die "narrative Klammer" des Produkts) von links nach rechts darstellt45, muss der erste Slice jeden Schritt dieser Kette umfassen. Dadurch wird sichergestellt, dass die Nutzer ihr übergeordnetes Ziel mit der kleinsten Menge von Aufgaben erreichen können2....
• Vermeidung von Lücken: Die horizontale Achse beantwortet die horizontale Frage der Vollständigkeit ("Haben wir an die gesamte Reise gedacht?")8. Indem der MVP-Slice mindestens eine Story aus jedem Schritt enthalten muss, wird vermieden, dass notwendige Funktionalitäten für einen vollständigen Ablauf fehlen1.
2. Das Ergebnis: Der "Walking Skeleton"
Wenn der Slicing-Mechanismus so angewendet wird, dass er jeden kritischen Backbone-Schritt streift, entsteht der sogenannte "Walking Skeleton"1....
• Definition: Der Walking Skeleton ist der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt1.... Er repräsentiert einen minimalen, aber nutzbaren Ablauf des gesamten Systems1....
• Die erste Release-Slice: Der erste Slice ist die oberste Scheibe der Map, die dieses MVP definiert2. Das Team ist "committet", diesen ersten Meilenstein zu liefern1314.
3. Kontrast zum traditionellen Backlog
Die Notwendigkeit, alle kritischen Backbone-Schritte abzudecken, ist der entscheidende Unterschied zum Priorisieren mit einem flachen Backlog:
• Priorisierung des Nutzens, nicht der Einfachheit: Die Story Map erzwingt, dass der MVP-Slice eine minimale Version aller notwendigen Schritte enthält (z.B. Suchen, Auswählen, Bezahlen, Empfangen)1.
• Vermeidung unbrauchbarer Produkte: Ein flaches Backlog könnte dazu führen, dass Teams zwar die Stories mit der höchsten Einzelpriorität liefern, aber kritische Schritte vergessen werden (z. B. Bezahlvorgang oder Bestellbestätigung). Dies würde das Produkt im Sinne eines End-to-End-Nutzens unbrauchbar machen1.
4. Beispiele für die Umsetzung
Die Fallstudien verdeutlichen diese Regelung:
• E-Commerce-Plattform: Obwohl Funktionen wie Filter, Wunschlisten oder PayPal für den Minimalbetrieb nicht zwingend erforderlich sind, muss der potenzielle MVP-Slice einen kompletten Kaufzyklus ermöglichen15. Das bedeutet, er muss Stories für alle kritischen Backbone-Schritte abdecken: (1) Stichwortsuche muss enthalten sein, (2) Produkt zum Warenkorb hinzufügen muss enthalten sein, (3) Bezahlen (z.B. mit Kreditkarte) muss enthalten sein und (4) Bestellbestätigungs-E-Mail erhalten muss enthalten sein15.
• Mobile Fitness-App: Das MVP konzentriert sich auf die reine Schrittzähler-Funktion, muss aber die Schritte (1) Basisprofil einrichten, (2) Schritte manuell eingeben und (4) Tägliche Schrittzahl anzeigen umfassen, um einen kompletten, wenn auch minimalen, Nutzungsablauf zu gewährleisten16.
Die Forderung, mindestens eine Story aus jedem kritischen Backbone-Schritt in den MVP-Slice aufzunehmen, ist somit der Mechanismus, der die vertikale Priorität mit der horizontalen Chronologie verbindet und die Lieferung eines funktionierenden, wenn auch einfachen, End-to-End-Produkts garantiert1....

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „MVP (Walking Skeleton)“ über „Liefert Complete Product Experience (CPE)“ aussagen.

Die Quellen betonen, dass der Slicing-Mechanismus in der User Story Map (USM) das Konzept des MVP (Minimum Viable Product) fundamental neu definiert, um sicherzustellen, dass es eine "Complete Product Experience" (CPE) liefert1....
Der "Walking Skeleton" (laufendes Skelett) ist die Bezeichnung für das MVP, das diese vollständige Benutzererfahrung garantiert1....
Hier wird diskutiert, was die Quellen über die Lieferung der Complete Product Experience (CPE) durch den Walking Skeleton aussagen:
1. Das explizite Ziel des MVP-Slicing
Das Hauptziel der Definition des MVP durch den obersten Slice ist die Lieferung einer durchgehenden Benutzererfahrung13.
• Kernziel: Das Ziel des MVP-Slices ist es, ein "Complete Product Experience" (CPE)1... oder zumindest eine durchgehende Benutzererfahrung zu liefern1.
• Funktional vollständiger Weg: Dies wird dadurch erreicht, dass der Walking Skeleton per Definition der dünnste, aber funktional vollständige End-to-End-Weg durch das Produkt ist12. Er stellt einen minimalen, aber nutzbaren Ablauf dar2.
2. Der Mechanismus zur Gewährleistung der CPE
Die Story Map gewährleistet die CPE durch ihre zweidimensionale Struktur und die spezifischen Anforderungen an den MVP-Slice.
• Backbone-Anforderung: Um die Vollständigkeit der Benutzererfahrung zu garantieren, muss der MVP-Slice (mindestens) eine Story aus jedem kritischen Backbone-Schritt enthalten1....
• Zielerreichung: Diese strukturelle Anforderung stellt sicher, dass Nutzer ihr übergeordnetes Ziel mit der kleinsten Menge von Aufgaben erreichen können, ohne dass notwendige Schritte fehlen24.
• Vermeidung von Lücken: Die Story Map erzwingt1 durch den Slicing-Mechanismus, dass die minimale Version aller notwendigen Schritte (z. B. Suchen, Auswählen, Bezahlen, Empfangen im E-Commerce-Beispiel1) enthalten ist.
3. Kontrast zur traditionellen MVP-Definition
Die Notwendigkeit, eine CPE zu liefern, unterscheidet den Story-Map-MVP fundamental von einem traditionellen, flachen Backlog:
• Abgrenzung: Ein MVP, das durch Slicing entsteht, ist nicht einfach "die 5 wichtigsten Features"12.
• Vermeidung der Unbrauchbarkeit: Die Quellen illustrieren, dass ein flaches Backlog dazu führen könnte, dass die wichtigsten Stories geliefert werden, während Stories niedrigerer Priorität, die für die Brauchbarkeit des Produkts essentiell sind (wie z. B. "gut gewürzt sein" im Lebensmittel-Beispiel1), weggelassen werden. Die USM verhindert dies, indem sie die vollständige, durchgängige Erfahrung (CPE) in den Vordergrund stellt.
Zusammenfassend lässt sich sagen: Die "Complete Product Experience" ist das Ergebnisziel des Walking Skeleton. Durch die Auflage, den gesamten horizontalen Backbone mit minimalen Stories abzudecken, stellt der Slicing-Mechanismus sicher, dass das erste ausgelieferte Produkt zwar minimal ist, aber den Nutzer funktional von Anfang bis Ende durch die gesamte Reise führen kann1....

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down
Diskutieren, was diese Quellen im Kontext von „Release-Planung (Slicing)“ über „Nachfolgende Releases“ aussagen.

Die nachfolgenden Releases (Subsequent Releases) sind im Kontext des Slicing-Mechanismus die logische Fortsetzung des Minimum Viable Product (MVP) und bilden die gesamte Produkt-Roadmap ab. Sie dienen der inkrementellen Erweiterung des Produkts, das durch den ersten Slice (den Walking Skeleton) geschaffen wurde.
Die Quellen treffen folgende Aussagen über nachfolgende Releases:
1. Definition und Position in der Map
Nachfolgende Releases werden durch die horizontalen Linien (Release-Slices oder Cut-Lines) strukturiert, die unterhalb des MVP-Slices gezogen werden1....
• Repräsentation: Die Stories, die unterhalb des MVP-Slices liegen, sind für nachfolgende Releases vorgesehen2.
• Versionsstruktur: Diese Slices repräsentieren nachfolgende Releases, beispielsweise Version 1.1 oder Version 2.027. Die horizontalen Schnitte legen die gesamte Versions- oder Release-Reihenfolge fest8.
• Zusätzliche Funktionen: Die nachfolgenden Reihen (Slices) enthalten zusätzliche Funktionen über das unbedingt Notwendige hinaus69.
2. Zweck: Die inkrementelle Erweiterung
Der Hauptzweck nachfolgender Releases ist es, dem funktional vollständigen Grundgerüst, das im ersten Slice definiert wurde, mehr Wert und Tiefe hinzuzufügen.
• "Fleisch hinzufügen": Jeder nachfolgende Slice fügt dem "Walking Skeleton" (dem dünnsten, aber funktional vollständigen End-to-End-Weg) mehr "Fleisch" hinzu27.
• Inhalt: Dies geschieht durch die Implementierung von höher priorisierten Alternativen (die in der vertikalen Priorisierung niedriger als die MVP-Lösung lagen) oder durch das Hinzufügen von "Nice-to-have"-Funktionen27.
• Beispiele: Die Quellen liefern konkrete Beispiele dafür, welche Stories in nachfolgenden Releases realisiert werden, wie:
    ◦ Das Hinzufügen von PayPal als zweite Zahlungsoption (als Alternative zur Kreditkarte im MVP)27.
    ◦ Die Realisierung von Funktionen wie Filter (z.B. nach Preis filtern) oder Wunschlisten10....
    ◦ Live-Tracking des Fahrers für einen Lieferdienst oder Bewertungssysteme11.
    ◦ Erweiterte Analysefunktionen (z. B. Gewichtsverlauf-Diagramme anzeigen) oder Synchronisierung mit Smartwatches/Kalendern15....
    ◦ Das Einrichten von Daueraufträgen in einer Banking-App1718.
3. Integration in die strategische Planung
Nachfolgende Releases sind ein wesentlicher Bestandteil der langfristigen Produktstrategie, die durch die Story Map visualisiert wird.
• Roadmap-Funktion: Die gesamte Story Map fungiert nach dem Slicing als eine lebendige, visuelle Produkt-Roadmap, die nicht nur den MVP, sondern auch die geplanten Folgeschritte darstellt27.
• Pattons Prozess: Im fünfstufigen Story Mapping Prozess nach Jeff Patton ist der Schritt Slice Out Viable Releases explizit dazu da, MVP und nachfolgende Releases zu definieren19....
• Detaillierte Strategie: Im weiteren Schritt Slice Out a Development Strategy können diese Releases in Phasen unterteilt werden, die oft als Mid-Game und End-Game bezeichnet werden und zusätzliche Funktionen enthalten19....
4. Messbarkeit und Qualitätsanforderungen
Für nachfolgende Releases gelten spezifische Anforderungen hinsichtlich der Messung ihres Erfolgs und ihrer technischen Qualität.
• Ziele und Metriken: Für jede Release-Slice, einschließlich der nachfolgenden, soll ein Ziel ("Outcome") definiert und es sollen Metriken festgelegt werden, um den Erfolg des jeweiligen Releases zu messen2....
• Testbarkeit: Es wird betont, dass die weiteren Releases weiterhin testbar bleiben sollten21....

keep_pin
In Notiz speichern

copy_all

thumb_up

thumb_down