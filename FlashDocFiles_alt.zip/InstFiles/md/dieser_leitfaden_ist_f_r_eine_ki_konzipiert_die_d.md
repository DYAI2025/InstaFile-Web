Dieser Leitfaden ist für eine KI konzipiert, die die LeanDeep 4.0 Marker-Analyse-Architektur nutzt, um von primitiven Sprachsignalen zu tiefen, systemischen Bedeutungen in der Kommunikation vorzudringen1.... Der Prozess ist hierarchisch und Bottom-up-gesteuert45.

--------------------------------------------------------------------------------
Leitfaden für die Intelligente Anwendung von Markern (LeanDeep 4.0)
Die Freilegung tiefer semantischer Ebenen erfolgt durch eine deterministische Vier-Ebenen-Kaskade (ATO → SEM → CLU → MEMA), die eine schrittweise Verdichtung der Bedeutung sicherstellt2....
1. Ebene: ATO (Atomic Marker) – Die Erfassung der Rohsignale
Die ATO-Ebene ist das Fundament der gesamten Analyse und dient der präzisen und zuverlässigen Erfassung primitiver Signale78.
Strategische Anweisung
Details & Intelligente Anwendung
Quellen
Präzise Erkennung (Token/Regex)
Die KI muss primitive Tokens oder Regex-Muster erfassen, ohne eine Interpretation vorzunehmen89. Beispiele sind ATO_HESITATION, ATO_UNCERTAINTY, oder ATO_DELAY_PHRASE9....8...
Kontextrahmen (RF2.0-Stufe)
Parallel zur ATO-Erkennung ist die dominante Resonance Framework 2.0 (RF2.0)-Stufe zu bestimmen (z. B. L1-STONE für Grundbedürfnisse oder L5-GOLD für Analyse/Messlogik)7.... Diese Stufe muss einen Schwellenwert (z.B. ≥15 Punkte pro 100 Wörter) überschreiten, da sie später die Manifestation der Marker kontextualisiert7....7...
2. Ebene: SEM (Semantic Marker) – Die Qualität durch Komposition
Die SEM-Ebene bildet die erste semantische Verdichtung10. Der intelligente Einsatz der KI auf dieser Ebene wird durch eine strenge Qualitätsregel erzwungen:
Strategische Anweisung
Details & Intelligente Anwendung
Quellen
Einhaltung der Kompositionsregel
Halte die verbindliche SEM-Kompositionsregel strikt ein (gültig seit v3.3): Jeder SEM_ Marker muss sich zwingend aus mindestens zwei (≥2) unterschiedlichen ATO_ Markern zusammensetzen4.... Dies vermeidet die Oberflächlichkeit einfacher Schlagwort-Suchen17.4...
Bildung von Mikromustern
Kombiniere ATOs zu bedeutsamen Mikromustern, die isolierte Signale in ein Kontextmuster überführen10. Beispiele sind SEM_AVOIDANT_BEHAVIOR (aus ATO_DELAY_PHRASE + ATO_AVOIDANCE_PHRASE) oder SEM_UNCERTAINTY_TONING (aus ATO_DOUBT_PHRASE + ATO_HEDGING_VOCAB)7....7...
3. Ebene: CLU (Cluster Marker) – Stabile Muster und Frühwarnung
Die CLU-Ebene transformiert die Analyse von Einzelvorkommnissen (SEMs) zur Identifikation stabiler, wiederkehrender Verhaltensmuster über definierte Nachrichtenfenster (X-of-Y-Regeln)9....
Strategische Anweisung
Details & Intelligente Anwendung
Quellen
Aggregationslogik
Aktiviere CLUs, indem du thematisch verwandte SEMs über ein Fenster aggregierst (z. B. CLU_CONFLICT_CYCLE bei "AT_LEAST 2 IN 5 messages" des entsprechenden SEMs)2021.2021
Intuition als Lern-Hypothese
Nutze CLU_INTUITION_* Marker (z. B. CLU_INTUITION_UNCERTAINTY) als lernfähiges Frühwarnsystem22.... Diese modellieren eine Vorahnung aus der schwachen Aggregation unspezifischer SEMs22.22...
Zustandsdynamik und Fokus
Steuere den dynamischen Lebenszyklus der Intuition (provisional → confirmed → decayed)2325. Wenn der Zustand auf confirmed wechselt (d. h., die Hypothese wird durch ein "hartes" Ziel-SEM bestätigt), wende sofort einen temporären Multiplikator (Score-Boost) (z. B. x1.5 oder x1.8) auf verwandte Marker der Familie an, um den Analysefokus zu schärfen23....23...
Richtungsmarker (Trajektorien)
Erfasse die Entwicklung der Kommunikation mit den Erweiterungen der LD 4.0, insbesondere den Richtungsmarkern (TEND_*), wie z.B. TEND_UNCLARITY_TO_CLARITY, um Bewegungsmuster zu signalisieren2328.2328
4. Ebene: MEMA (Meta-Analysis Marker) – Systemischer Trend und Risiko
Die MEMA-Ebene ist die höchste und abstrakteste Stufe, die systemische Trends und das Gesamtrisiko durch die Analyse des Zusammenspiels mehrerer CLUs bewertet22....
Strategische Anweisung
Details & Intelligente Anwendung
Quellen
Erkennung Systemischer Trends
Aktiviere MEMA_ Marker (z. B. MEMA_INCONSISTENCY_TREND oder MEMA_RELATIONSHIP_STRAIN) durch die Kombination von mindestens zwei Clustern (composed_of [CLU_*])22.... Beispielsweise kann MEMA_RELATIONSHIP_STRAIN durch das Zusammenspiel von CLU_CONFLICT_CYCLE und CLU_REPAIR ausgelöst werden3234.22...
Quantifizierung des Risikos
Kommuniziere das Ergebnis als Akuten Risk Score (ARS) auf der logistischen Skala von 0 bis 524.... Werte wie 2.5/5 (moderates Risiko, Inkonsistenz-Trend) oder 2.8/5.0 (signifikantes Risiko für prozessuale Blockaden) erfordern sofortige Aufmerksamkeit3035.29...
Dynamische Risikoregelung
Stelle sicher, dass der ARS einen Zeitverfall (Decay mit λ-Faktor) unterliegt (z. B. 0.85 / 24 h oder 0.65 / 24 h), um die aktuelle Relevanz abzubilden und das Risiko automatisch zu reduzieren, wenn keine neuen negativen Ereignisse auftreten30....30...
Kontextualisierung der Manifestation
Wende das Resonance Framework 2.0 (RF 2.0) an, um die Bedeutung der gefundenen Marker zu verankern und Doppeldeutigkeiten aufzulösen24.... Verwende die Manifestationsformel: [STUFE] × [MARKER-TYP] × [ZEIT-BEZUG] × [INTENSITÄT] = MANIFESTATION24.... Dies ermöglicht es, denselben Marker je nach dominierender RF-Stufe unterschiedlich zu interpretieren (z. B. L1-STONE ↔ L7-PRISM)3941.24...

--------------------------------------------------------------------------------
Zusammenfassung des intelligenten Markereinsatzes
Die KI nutzt Marker nicht nur zur Identifikation von Schlüsselwörtern, sondern als strukturierte, nachvollziehbare Kaskade3. Die Intelligenz liegt darin, die SEM-Kompositionsregel als Qualitätsmechanismus17 zu verwenden, Intuition-Marker als lernfähige Hypothesen mit temporärem Fokus-Boost zu modellieren25, und die Bedeutung abschließend über das RF2.0 im systemischen Kontext (MEMA) zu verankern3041.
Analogie: Die LeanDeep 4.0 Marker-Analyse funktioniert wie ein spezialisiertes Mikroskop, das nicht nur einzelne Zellen (ATOs) erkennt, sondern deren Zusammenschluss zu Geweben (SEMs), die Stabilität von Organen (CLUs) und schließlich die Diagnose des gesamten Organismus (MEMA), wobei der RF2.0-Kontext die Umgebungstemperatur und den Gesamtzustand liefert, die bestimmen, wie die Teile interagieren.